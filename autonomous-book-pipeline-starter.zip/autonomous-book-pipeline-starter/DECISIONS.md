# Decision Log

Append-only architectural decision log. Every architectural choice not pre-decided in the docs gets an entry here. Future sessions read this file to maintain continuity.

**Format:**

```yaml
date: YYYY-MM-DD
decision_id: DEC-NNN
context: what problem or question this addresses
options_considered:
  - option A: pros/cons
  - option B: pros/cons
choice: option chosen
rationale: why
references:
  - links to ontology sections, papers, prior decisions
revisit_when: condition that would re-open this decision
```

Decisions are append-only. To revise a decision, append a new entry that supersedes the old one and reference its ID. Never edit or delete past entries.

---

## Decisions

(none yet — this section grows as the implementation proceeds)

---

## Standing decisions (pre-locked from architecture)

These are not subject to revision without major architectural rework. Listed here so future sessions don't accidentally re-open them.

```yaml
decision_id: DEC-000-1
fixed: V1 Primary Axes are Author × Genre × Audience × Goal × Sensitivity
rationale: see profile-axis-framework-v2.md §4

decision_id: DEC-000-2
fixed: Conflict precedence default is Constraint > Sensitivity > Goal > Genre > Audience > Author > Universal
rationale: see core-ontology-v3.md Part II

decision_id: DEC-000-3
fixed: No prose retention from external sources
rationale: voice contamination, plagiarism risk, training-data idiosyncrasy bias

decision_id: DEC-000-4
fixed: No human gates in inner loop
rationale: autonomous operation requirement; see core-ontology-v3.md §8

decision_id: DEC-000-5
fixed: Sensitivity Profile thresholds are sacred
rationale: safety-by-architecture; cannot be force-resolved past

decision_id: DEC-000-6
fixed: Reproducibility is first-class; pin seed + model versions + profile versions + registry snapshot
rationale: enables auditing, calibration credibility, reproducible runs

decision_id: DEC-000-7
fixed: Schemas are the contract; every component validates input/output
rationale: prevents silent drift; enables component swap-ability
```
