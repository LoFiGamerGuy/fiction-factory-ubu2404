# Schemas

Schema definitions for every entity in the system. JSON Schema is canonical; pydantic models are generated from these schemas (or hand-written and kept in sync).

## Status

This directory will be populated by Phase 1 and Phase 2 work. As of the starter packet, it contains only this README.

## Organization

```
schemas/
├── universal/          # Universal Core entities (Phase 1)
├── profiles/           # The five V1 primary axes + Project Spec (Phase 2)
└── components/         # Component contract schemas — critic outputs, reader outputs, etc.
```

## Schema authoring conventions

- **Format:** JSON Schema Draft 2020-12.
- **`$id` field:** every schema has a versioned `$id`, e.g. `"https://book-pipeline.local/schemas/universal/voice_axes/v1"`.
- **`$schema` field:** points to the meta-schema.
- **`additionalProperties: false`** on object schemas. Catch typos, prevent silent drift.
- **`required` arrays** explicitly declare required fields.
- **`description`** on every property. The schema is documentation.
- **Custom annotations** (prefix `x-`) for things JSON Schema doesn't capture: units, default-policy, measurement-method.

## Versioning policy

- Backward-compatible changes: bump minor version (v1 → v1.1).
- Breaking changes: bump major version (v1 → v2). Old version preserved.
- Profile data declares which schema version it was authored against.

## Validation

`scripts/validate_schemas.py` validates:
1. Every schema in this directory validates against JSON Schema meta-schema.
2. Every fixture in `tests/fixtures/` validates against its declared schema.
3. Pydantic models in `pipeline/schemas/` round-trip correctly.

Run via `make validate-schemas`.

## Reference for what schemas to author

See `IMPLEMENTATION_PLAN.md`:
- Phase 1 task list — universal core schemas
- Phase 2 task list — profile schemas
- Phase 7+ — component contract schemas

See `docs/core-ontology-v3.md` for the entity definitions each schema implements.
