# Runbooks

Phase-specific operational guidance. Runbooks are populated as phases complete — each runbook captures the *actual* implementation details, gotchas, and operational notes from that phase.

## Why runbooks exist separately from tasks

- **Tasks** are forward-looking specifications: what to build.
- **Runbooks** are backward-looking knowledge: what was built and how to operate it.

When a phase completes, draft the runbook for that phase. Future sessions consult runbooks for "how does this actually work in this codebase" rather than re-deriving from architecture docs.

## Structure

One file per major phase:

- `phase-00-foundation.md` (after Phase 0 completes)
- `phase-01-universal-schemas.md`
- `phase-02-profile-schemas.md`
- ...

Each runbook should include:

- **Overview** — what the phase produced
- **How to operate** — running, debugging, testing
- **Gotchas discovered** — surprises during implementation
- **Schema/contract reference** — paths to the canonical artifacts
- **Decision links** — relevant DECISIONS.md entries
- **Known limitations** — what doesn't work yet, intentional gaps

## When to write a runbook

Right after the phase commit. While the implementation is fresh.
