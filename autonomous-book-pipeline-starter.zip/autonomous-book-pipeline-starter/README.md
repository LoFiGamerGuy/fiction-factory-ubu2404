# Autonomous Book Pipeline — Starter Packet

A self-contained packet for planning and implementing an autonomous book-generation system. Drop this into a fresh directory, initialize git, point a CLI LLM agent (Claude Code or equivalent) at it, and start building.

## What's in here

```
.
├── README.md                  ← you are here
├── CLAUDE.md                  ← agent briefing (read first)
├── QUICK_REFERENCE.md         ← single-page cheat sheet
├── IMPLEMENTATION_PLAN.md     ← phased build plan
├── PROJECT_STRUCTURE.md       ← proposed repo layout
├── DECISIONS.md               ← decision log (starts empty, you'll append)
├── docs/                      ← architecture documents
│   ├── core-ontology-v3.md
│   ├── profile-axis-framework-v2.md
│   ├── ml-opportunity-analysis-v2.md
│   └── references-reading-list.md
├── diagrams/                  ← architecture diagrams
│   ├── architecture-overview-aesthetic.html
│   └── autonomous-book-pipeline-v5.mermaid
├── tasks/                     ← concrete starter tasks
│   ├── README.md
│   ├── task-001-foundation.md
│   ├── task-002-universal-core-schemas.md
│   └── task-003-first-profiles.md
├── runbooks/                  ← phase-by-phase guidance
│   └── README.md
└── schemas/                   ← schema files (mostly empty, you'll author them)
    └── README.md
```

## How to use this packet

1. **Extract** into a fresh directory: `autonomous-book-pipeline/` (or your preferred name).

2. **Initialize git** and make an initial commit:
   ```bash
   cd autonomous-book-pipeline
   git init
   git add -A
   git commit -m "initial: starter packet"
   ```

3. **Open Claude Code** (or your CLI LLM agent) in that directory. Claude Code will automatically read `CLAUDE.md`.

4. **First session prompt** (suggested): *"Read CLAUDE.md, then IMPLEMENTATION_PLAN.md Phase 0 and 1, then begin task-001-foundation. Surface any decisions you make in DECISIONS.md."*

5. **Subsequent sessions:** the agent should pick up where the last left off using the implementation plan and the decision log as continuity. You can also direct it to specific tasks.

## What this is and isn't

**This is:** a thoroughly specified architecture with a phased implementation plan, ready to hand to a competent CLI agent. The architecture has been worked through; the agent's job is execution, not design.

**This isn't:** a code repository. There is no implementation yet. The first phases are about building the foundations (schemas, profiles, knowledge API). Generating an actual book is many phases away.

**Estimated scope:** 4–6 months of focused work for a single engineer with a CLI agent assisting. The implementation plan has 17 phases. Each phase produces something testable.

## Critical reading before you start

If you only have ten minutes, read in this order:

1. `CLAUDE.md` (10 minutes) — orientation
2. `QUICK_REFERENCE.md` (5 minutes) — the highlights

If you have an hour:

3. `IMPLEMENTATION_PLAN.md` (15 minutes) — the build sequence
4. `docs/core-ontology-v3.md` Parts I and II (30 minutes) — the entities you'll be implementing

If you're going to design a profile or component:

5. The relevant section of `docs/core-ontology-v3.md` and the corresponding section of `docs/references-reading-list.md`.

## Hard constraints (non-negotiable)

These are reproduced in `CLAUDE.md` but worth highlighting up front:

1. No prose retention from external sources. Voice extraction is measurement only.
2. No human gates in the inner loop.
3. Sensitivity Profile thresholds are sacred.
4. Reproducibility is a first-class property; pin all versions.
5. Every component declares deterministic / LLM / hybrid.
6. Append-only logs for decisions, calibration, registry, issues.
7. Schemas are the contract.

## Open architectural questions to resolve early

These need decisions in the first few sessions. Log to `DECISIONS.md`.

- **Goal Profile precedence rules: authored YAML or template-generated?** Recommend authored-with-template-defaults.
- **Persistence format for calibration data store.** Recommend SQLite for V1; revisit at Phase 12.
- **Schema language: JSON Schema vs pydantic-only?** Recommend JSON Schema as canonical, pydantic generated from it.
- **Initial threshold values for the V1 pentad.** Conservative defaults; expect to tune over first 5–10 runs.

## Versioning

This packet is the v5 architecture. Architecture deltas after this point should be logged in `DECISIONS.md` and a new packet version cut when a major shift occurs.

## License / attribution

The architecture, ontology, and reading list are part of the project package. Use, modify, and extend freely within the project.
