# Task 001 — Repository Foundation

```
status: not_started
started:
completed:
phase: 0
estimated_hours: 2-4
```

## Goal

A working Python 3.11+ repository with linting, type-checking, testing, and pre-commit hooks configured. The directory structure matches `PROJECT_STRUCTURE.md`. CI passes on a hello-world test.

## Acceptance criteria

- [ ] `pyproject.toml` exists with V1 dependencies declared
- [ ] Directory tree matches `PROJECT_STRUCTURE.md` (empty placeholders OK for directories that won't have content yet)
- [ ] `make test` runs pytest and passes on at least one trivial test
- [ ] `make lint` runs ruff and mypy --strict, both pass on the trivial test
- [ ] `make validate-schemas` exists as a target (can no-op for now since no schemas yet)
- [ ] Pre-commit hooks installed: ruff, mypy, schema validator
- [ ] `.env.example` documents required environment variables
- [ ] `DECISIONS.md` exists with the seven standing decisions documented
- [ ] Initial commit made with message `chore: initial repository scaffolding (task-001)`

## References

- `PROJECT_STRUCTURE.md` — directory layout
- `CLAUDE.md` — working conventions section
- `IMPLEMENTATION_PLAN.md` Phase 0

## Suggested approach

1. Read `PROJECT_STRUCTURE.md` once through.
2. Create the top-level files (`pyproject.toml`, `Makefile`, `.env.example`, `.gitignore`, `ruff.toml`, `mypy.ini`).
3. Create the directory tree with empty `__init__.py` files where needed and `.gitkeep` for empty directories that should be tracked.
4. Add a single trivial test in `tests/unit/test_smoke.py`:
   ```python
   def test_smoke() -> None:
       assert True
   ```
5. Configure `Makefile` targets: `lint`, `test`, `validate-schemas`, `format`, `install-dev`.
6. Set up pre-commit config; run `pre-commit install`.
7. Verify `make lint && make test` passes.
8. Commit.

## Decisions to log (in DECISIONS.md)

If you make any of these choices, log them:

- **Build tooling.** `pyproject.toml` with PEP 621 metadata (recommended) vs alternatives.
- **Schema language.** JSON Schema canonical with pydantic generated (recommended) vs pydantic-only.
- **Lint/format choice.** ruff for both (recommended) vs separate tools.
- **Test runner.** pytest (recommended) vs unittest.
- **CI.** Defer for now; revisit in a later phase.

## Notes

- Don't install heavyweight ML dependencies (`torch`, `transformers`, etc.) yet. They come in Phase 12.
- Don't write any pipeline code in this task — foundation only.
- Don't author any schemas — that's Phase 1 / task-002.
- The trivial smoke test exists only to verify the test runner. Real tests come with real code.

## Out of scope

- CI/CD setup
- Docker/containerization
- Documentation site
- Any pipeline implementation
