# Tasks

Concrete starter tasks to pick up. Each task is sized for a single focused work session (1–4 hours typically). Tasks reference `IMPLEMENTATION_PLAN.md` phases and ontology sections.

## Format

Each task has:

- **Task ID** (sequential)
- **Phase reference** (which IMPLEMENTATION_PLAN phase this belongs to)
- **Goal** (what's delivered)
- **Acceptance** (how to know it's done)
- **References** (which docs to consult)
- **Suggested approach** (a starting-point sketch, not prescriptive)

## Status convention

At the top of each task file, add:

```
status: not_started | in_progress | blocked | done
started: YYYY-MM-DD
completed: YYYY-MM-DD
```

When picking up a task: change to `in_progress` and add `started` date.
When finishing: change to `done` and add `completed` date.
When blocked: change to `blocked` and add a brief blocker description.

## Available tasks (V1)

- `task-001-foundation.md` — Phase 0 — Repository scaffolding + tooling
- `task-002-universal-core-schemas.md` — Phase 1 — First three universal schemas
- `task-003-first-profiles.md` — Phase 3 — Author the V1 profile library

More tasks can be authored as work progresses. New tasks go in this directory with sequential IDs.

## How to pick a task

1. Read `IMPLEMENTATION_PLAN.md` for current phase status.
2. Pick the lowest-numbered task in the current phase that's `not_started`.
3. If a task has open dependencies (unresolved blockers from a prior task), resolve those first.
4. If the natural next task isn't yet authored, author it from the IMPLEMENTATION_PLAN phase tasks.
