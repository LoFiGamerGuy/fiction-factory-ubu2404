# Task 003 — First Profile Library

```
status: not_started
started:
completed:
phase: 3
estimated_hours: 6-10
depends_on: task-002 plus completing remaining Universal Core and Profile schemas
```

## Goal

Author the first set of real profile data: one Author, one Genre, one Audience, three Goals, three Sensitivity profiles. These are the data fixtures that every subsequent phase will exercise.

## Acceptance criteria

- [ ] `profiles/authors/synth_v1.yaml` — synthetic author profile, all voice axes filled, validates against schema
- [ ] `profiles/genres/contemporary_romance_us.yaml` — full genre profile with intensity scales, trope library, pacing template, validates
- [ ] `profiles/audiences/kdp_romance_reader.yaml` — full audience profile, validates
- [ ] `profiles/goals/kdp_high_revenue.yaml` — goal profile with precedence rules and weight overrides, validates
- [ ] `profiles/goals/personal_vanity.yaml` — author voice supreme, validates
- [ ] `profiles/goals/literary_award_target.yaml` — voice and theme priority, validates
- [ ] `profiles/sensitivity/clean.yaml` — restrictive content policy, validates
- [ ] `profiles/sensitivity/mainstream.yaml` — moderate content policy, validates
- [ ] `profiles/sensitivity/unrestricted.yaml` — permissive content policy (still applies sacred rules), validates
- [ ] Composition test: load any combination of the above, run resolver, get valid Project Spec
- [ ] Conflict test: KDP goal + clean sensitivity for romance — verify sensitivity correctly tightens (not loosens)
- [ ] Decision-log entry on the synthetic-author choice

## References

- `docs/core-ontology-v3.md` Part II §9–13 (Genre, Audience, Author, Sensitivity, Goal)
- `docs/references-reading-list.md`:
  - §1 (Voice & Prose Style — for synth author voice axes)
  - §2 (Genre — Pamela Regis, Romancing the Beat by Gwen Hayes for romance specifically)
  - §5 (Audience & Reception)
  - §12 (Sensitivity & Content Policy)
- `docs/profile-axis-framework-v2.md` §3.5 (Sensitivity Profile)

## Suggested approach

### Synthetic Author Profile

**Important.** Use a synthetic identity, not a real-author analog. This sets the precedent that voice profiles in this system are designed, not extracted from real people.

Pick a coherent voice signature:
- Name: something distinctive (placeholder — the human will pick a real pen name later)
- Sentence length mean: 14, std: 7 (modern moderate)
- Sentence opener distribution: noun-first 40%, verb-first 15%, dependent-clause 25%, dialogue 15%, other 5%
- Lexical diversity: moderate (TTR ~0.45)
- Formality register: 0.4 (slightly informal)
- Concrete-noun ratio target: ≥ 0.65 (specificity-priority)
- Sensory token density: medium-high
- Em-dash rate max: 0.5 per Kword (low — anti AI-tell)
- Adverb density: low (per Maass)
- Tonal default: warm
- Whitelisted constructions: 3–5 specific patterns
- Blacklisted constructions: a few patterns (em-dash sandwich, "It wasn't X, it was Y", etc.)

Don't try to make the voice unique on the first pass — make it valid and coherent. Real distinctiveness comes through use.

### Contemporary Romance US Genre Profile

Read Pamela Regis's *A Natural History of the Romance Novel* (or summary; reading list §2).

Key sections to fill:
- Length range: 60K–110K words (typical), tolerance ±10%
- Chapter count range: 25–35 typical for novel-length
- Pacing template: tension curve with romantic-arc midpoint at 0.5, climax at 0.85, declaration of love at 0.9, resolution at 0.97
- Intensity scales:
  - `heat`: 1–5 with anchor definitions (1 = clean, 5 = on-page-explicit)
  - `angst`: 1–5
  - `humor`: 1–5
- Must-haves: meet-cute by chapter 2, defining-conflict by 0.25, dark-moment around 0.7, declaration around 0.9, HEA/HFN ending
- Taboos: cheating without resolution, unhealthy power dynamics presented uncritically, infidelity-as-conflict patterns disliked by genre veterans
- Pacing expectations: chapter hooks required, cliffhanger every 3rd chapter recommended
- Required critics with weights, required readers with weights
- Promise resolution deadlines: emotional_debts by 0.95, romantic_tension at 0.95

### KDP Romance Reader Audience

- Reading lens: emotional satisfaction priority, character investment, romantic fantasy fulfillment
- Tolerance bands: low ambiguity tolerance, medium complexity, low slow-pace tolerance (chapter hooks expected)
- Required satisfactions: HEA, slow-burn-or-instalove-but-not-mid, defining moment of declaration
- Forbidden disappointments: cheating without redemption arc, ambiguous endings, secondary-character-stealing-protagonist's-arc
- DNF triggers: by chapter 3 if no romantic tension, mid-book if HEA seems impossible
- Loyalty triggers: distinctive voice, vivid romantic chemistry, satisfying resolution
- Reader personas: target_demo (KU subscriber), genre_veteran (knows tropes), emotional_probe (tracks affect), detail_reader (continuity)

### Goal Profiles

**`kdp_high_revenue`** — precedence rules:
- voice axes: [genre, audience, author, universal] (genre wins on voice)
- length: [goal, genre, universal]
- pacing curve: [goal, genre, universal]
- weight overrides: critic_weights {convention_critic × 1.5, ai_tell_critic × 1.5}, reader_weights {target_demo × 1.3}
- Sacred thresholds: convention compliance ≥ 0.9, length within tolerance, ai_tell density ≤ 0.5

**`personal_vanity`** — precedence rules:
- voice axes: [author, universal] (author wins absolutely)
- weight overrides: critic_weights {craft_critic × 1.5, voice_fidelity × 2.0}, reader weights flat
- Sacred thresholds: voice fidelity ≥ 0.85
- Force-resolve direction: relax convention before voice

**`literary_award_target`** — precedence rules:
- voice: [author, universal]
- pacing: [author, genre, goal, universal]
- weight overrides: critic_weights {theme_critic × 1.5, voice_fidelity × 1.5}, reader_weights {detail_reader × 1.3}
- Additional metrics: thematic_resonance, interpretive_depth
- Sacred: voice fidelity ≥ 0.9, thematic resonance ≥ 0.75

### Sensitivity Profiles

**`clean`** — for romance: max heat 2 (closed-door), profanity_policy: none, depiction_of_minors: non-sexual_only, violence: allusion_only

**`mainstream`** — for romance: max heat 4, profanity moderate, violence on-page restrained, sexual content on-page

**`unrestricted`** — for romance: max heat 5, profanity unrestricted, violence on-page explicit if genre warrants, BUT universal sacred rules still enforced (no minors in sexual content ever, etc.)

All three include the universal sacred categories at the floor.

### Composition test

After authoring, write a test:

```python
def test_kdp_romance_clean_composition() -> None:
    spec = resolve_profiles(
        author="synth_v1",
        genre="contemporary_romance_us",
        audience="kdp_romance_reader",
        goal="kdp_high_revenue",
        sensitivity="clean",
    )
    assert spec.is_valid()
    # Sensitivity tightens: KDP wants high heat for sales, clean overrides to heat ≤ 2
    assert spec.intensity_max("heat") == 2
    # Voice axes: genre+audience win over author for KDP goal
    assert spec.voice_axes.formality_register == GENRE_TARGET  # not author target
```

## Decisions to log

- Synthetic author choice (recommend: yes for V1).
- Per-axis precedence rule format: ordered list of profile sources (recommend) vs weighted blend (rejected for V1 simplicity).
- How to express "sacred" thresholds: per-threshold flag in profile (recommend) vs separate sacred manifest.
- Whether sensitivity profile's universal sacred rules are inline or referenced (recommend: inline for V1, refactor later).

## Notes

- Don't perfect any single profile. Get all of them valid first, then iterate. Profiles are calibration targets — they'll be tuned.
- This is the first time the schemas get exercised at scale. Expect to find schema gaps and go back to fix them. Log each schema change in DECISIONS.md.
- After this task, you have your first complete profile pentad. The next tasks build the Knowledge API to compose them.

## Out of scope

- More than three goal profiles (later tasks)
- More than three sensitivity profiles (later tasks)
- Multiple genres (later)
- Real-author voice extraction (Phase 13)
- Critic/Reader profile authoring (covered separately in Phase 7/8)
