# Task 002 — Universal Core Schemas (First Three)

```
status: not_started
started:
completed:
phase: 1
estimated_hours: 4-6
depends_on: task-001
```

## Goal

The first three Universal Core schemas authored as JSON Schema with corresponding pydantic models. Validates against fixture data.

## Acceptance criteria

- [ ] `schemas/universal/voice_axes.schema.json` authored, validates against JSON Schema meta-schema
- [ ] `schemas/universal/structural_hierarchy.schema.json` authored, validates
- [ ] `schemas/universal/promise_ledger.schema.json` authored, validates
- [ ] Pydantic models generated or hand-written for each (`pipeline/schemas/universal/`)
- [ ] Round-trip test for each: load valid YAML/JSON → validate via schema → instantiate pydantic model → serialize → re-validate
- [ ] Round-trip test for invalid fixtures: validation correctly rejects
- [ ] `scripts/validate_schemas.py` script that validates all schemas against meta-schema
- [ ] Test fixtures in `tests/fixtures/universal/`: valid + invalid examples for each schema
- [ ] All tests pass with `make test`
- [ ] Commit with message `feat(schemas): universal core schemas voice_axes, structural_hierarchy, promise_ledger (task-002)`

## References

- `docs/core-ontology-v3.md` Part I:
  - §2 (Voice Axes — full axis catalog)
  - §3 (Structural Hierarchy)
  - §5 (Promise Ledger)
- `docs/references-reading-list.md` §1 (Voice & Prose Style — for understanding the axes)

## Suggested approach

### Voice Axes schema

Read `core-ontology-v3.md §2` carefully. Every axis listed there must be a field in the schema with:
- A type (`number`, `string`, `object` for distributions, etc.)
- A unit if applicable (`words_per_sentence`, `per_kword`, etc.)
- A default policy (`required`, `genre_default`, `author_default`)
- A range or enum if applicable

Group fields by category: sentence-level, lexical, structural-prose, punctuation, cadence, modality, POV.

Example field:
```json
"sentence_length_mean": {
  "type": "number",
  "minimum": 1,
  "maximum": 100,
  "description": "Target mean sentence length in words",
  "x-unit": "words"
}
```

Distributions need their own object schemas:
```json
"sentence_length_distribution": {
  "type": "object",
  "properties": {
    "mean": {"type": "number"},
    "std": {"type": "number"},
    "shape": {"type": "string", "enum": ["uniform", "rhythmic_alternation", "fragment_heavy", "..."]}
  }
}
```

### Structural Hierarchy schema

This is recursive — a Unit can contain other Units. Use `$ref` and `allOf` for the inheritance pattern:

```json
"GenericUnit": {
  "type": "object",
  "properties": {
    "id": {"type": "string"},
    "parent_unit_id": {"type": ["string", "null"]},
    "unit_type": {"enum": ["book", "part", "act", "chapter", "scene", "beat"]},
    "target_word_count": {"type": "object", "properties": {"min": {"type": "integer"}, "max": {"type": "integer"}}},
    "actual_word_count": {"type": "integer"},
    "function": {"type": "string"},
    "state": {"enum": ["planned", "drafted", "in_review", "committed", "force_resolved"]}
  }
}
```

Then specialize for Beat, Scene, Chapter, Act/Part with `allOf: [{"$ref": "#/definitions/GenericUnit"}, {...specialized fields...}]`.

### Promise Ledger schema

Define the Promise object and the Ledger collection:

```json
"Promise": {
  "type": "object",
  "required": ["id", "type", "opened_at", "must_resolve_by", "resolution_state"],
  "properties": {
    "id": {"type": "string"},
    "type": {"enum": ["foreshadowing", "chekhov_object", "character_question", "mystery_thread", "emotional_debt", "thematic_setup", "romantic_tension", "world_question"]},
    ...
  }
}
```

### Pydantic models

Two paths:
- **Generate from schema** with `datamodel-code-generator`. Pros: guaranteed consistency. Cons: generated files are awkward.
- **Hand-write pydantic models** that mirror the schema. Pros: more idiomatic. Cons: drift risk.

**Recommendation:** generate for V1, hand-tune later if needed. Log this choice.

```bash
datamodel-codegen \
  --input schemas/universal/voice_axes.schema.json \
  --output pipeline/schemas/universal/voice_axes.py \
  --input-file-type jsonschema \
  --output-model-type pydantic_v2.BaseModel
```

### Validation tests

For each schema, `tests/unit/schemas/test_<schema_name>.py`:

```python
import json
from pathlib import Path
from jsonschema import validate, ValidationError
import pytest

SCHEMA = json.loads(Path("schemas/universal/voice_axes.schema.json").read_text())

def test_valid_fixture_validates() -> None:
    fixture = json.loads(Path("tests/fixtures/universal/voice_axes_valid.json").read_text())
    validate(fixture, SCHEMA)  # raises if invalid

def test_invalid_fixture_rejected() -> None:
    fixture = json.loads(Path("tests/fixtures/universal/voice_axes_invalid.json").read_text())
    with pytest.raises(ValidationError):
        validate(fixture, SCHEMA)

def test_pydantic_round_trip() -> None:
    fixture = json.loads(Path("tests/fixtures/universal/voice_axes_valid.json").read_text())
    from pipeline.schemas.universal.voice_axes import VoiceAxes
    obj = VoiceAxes(**fixture)
    serialized = obj.model_dump()
    validate(serialized, SCHEMA)  # round-trip preserves validity
```

## Decisions to log

- Pydantic generation strategy (recommend: generated).
- Schema versioning approach (recommend: `$id` field with version, e.g. `schemas/universal/voice_axes/v1`).
- Whether to use `additionalProperties: false` strictly (recommend: yes for V1; relaxes can be opt-in later).

## Notes

- Don't try to author all seven Universal Core schemas at once. This task is the first three. Subsequent tasks pick up the rest.
- Focus on correctness of the *schema definitions*, not on authoring example profile data — that comes in task-003.
- Voice Axes is the biggest schema in the project. Take time to get the categories right; they'll be referenced everywhere downstream.

## Out of scope

- Genre/Author/Audience/Goal/Sensitivity schemas (Phase 2)
- Authoring real profile data (Phase 3)
- Knowledge API (Phase 4)
