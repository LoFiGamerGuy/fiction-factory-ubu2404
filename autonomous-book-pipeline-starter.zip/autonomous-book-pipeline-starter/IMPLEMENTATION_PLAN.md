# Implementation Plan

**Audience:** the implementing agent (and the human reviewing).
**Status:** sequential phased plan. Phases are roughly ordered by dependency. Each phase produces something testable.
**Discipline:** complete a phase before starting the next. If you must skip ahead, log the deviation in DECISIONS.md with rationale.

---

## How to use this plan

Each phase has:
- **Goal:** what the phase delivers
- **Tasks:** concrete sub-deliverables
- **Acceptance:** how to know the phase is done
- **References:** which ontology sections to consult

Pick a task. Read references. Implement. Test. Commit. Move on.

---

## Phase 0 — Repository Foundation

**Goal.** Working repo skeleton with conventions, tooling, and CI.

**Tasks.**
- T0.1 — Initialize Python 3.11+ project. `pyproject.toml` with `pydantic`, `pytest`, `mypy`, `ruff`, `pyyaml`, `jsonschema`, `anthropic`.
- T0.2 — Set up directory structure per `PROJECT_STRUCTURE.md`.
- T0.3 — Configure `mypy --strict`, `ruff check`, `ruff format`. Pre-commit hooks.
- T0.4 — Set up `pytest` with coverage; `make test` target.
- T0.5 — Create `DECISIONS.md` at repo root, empty. Document the decision-log format inside it.
- T0.6 — Create `.env.example` with required environment variables (Anthropic API key etc.).
- T0.7 — `Makefile` or `justfile` with: `lint`, `test`, `validate-schemas`, `run-pipeline`.

**Acceptance.** `make lint && make test` passes on a hello-world. Pre-commit hooks fire on commit.

**References.** None for this phase; tooling only.

---

## Phase 1 — Universal Core Schemas

**Goal.** Schema definitions for everything in `core-ontology-v3.md` Part I (Universal Core).

**Tasks.**
- T1.1 — `schemas/universal/voice_axes.schema.json` — all voice axis fields with types, ranges, units. Reference `core-ontology §2`.
- T1.2 — `schemas/universal/structural_hierarchy.schema.json` — Generic Unit, Beat, Scene, Chapter, Act/Part. Reference §3.
- T1.3 — `schemas/universal/continuity_model.schema.json` — Bible entities: Character, Location, Object, Concept, Faction, Timeline. Reference §4.
- T1.4 — `schemas/universal/promise_ledger.schema.json` — Promise object with all promise types. Reference §5.
- T1.5 — `schemas/universal/ai_tell_catalog.schema.json` — pattern entry schema. Reference §6.
- T1.6 — `schemas/universal/specificity_heuristics.schema.json` — metric definitions. Reference §7.
- T1.7 — `schemas/universal/convergence.schema.json` — decision rule schema. Reference §8.
- T1.8 — `pipeline/schemas/__init__.py` — pydantic models generated from schemas. Use `datamodel-code-generator` or hand-write.
- T1.9 — Schema validator script: `scripts/validate_schemas.py`. Validates all schemas against meta-schema and that pydantic models match.

**Acceptance.** All eight schemas validate. Pydantic models exist for each. Round-trip test: load YAML → validate → serialize → re-validate.

**References.** `docs/core-ontology-v3.md` Part I.

---

## Phase 2 — Profile Schemas

**Goal.** Schema definitions for the V1 pentad and Project Spec.

**Tasks.**
- T2.1 — `schemas/profiles/author_profile.schema.json` — uses Voice Axes from Phase 1. Reference §11.
- T2.2 — `schemas/profiles/genre_profile.schema.json` — structural conventions, pacing, intensity scales, trope library, reader contract, pipeline configuration. Reference §9.
- T2.3 — `schemas/profiles/audience_profile.schema.json` — reading lens, tolerances, expectation set, triggers. Reference §10.
- T2.4 — `schemas/profiles/goal_profile.schema.json` — precedence rules, weight overrides, sacred thresholds, success criteria. Reference §13 (renumbered to follow Sensitivity).
- T2.5 — `schemas/profiles/sensitivity_profile.schema.json` — content domain policies, vocabulary restrictions, audience markers. Reference §12. **Sacred status enforced.**
- T2.6 — `schemas/profiles/project_spec.schema.json` — composed result of profile resolution.
- T2.7 — Pydantic models for each.
- T2.8 — Profile schema cross-validation: any value referenced by another profile (e.g., genre intensity scale referenced by sensitivity) validates the cross-link.

**Acceptance.** All six schemas validate. Pydantic models exist. Cross-link validation passes on test fixtures.

**References.** `docs/core-ontology-v3.md` Part II §9–13.

---

## Phase 3 — First Profile Library

**Goal.** Author the first set of real profiles. These are data, not code, but they exercise the schemas and uncover schema problems early.

**Tasks.**
- T3.1 — One Author Profile. Recommend a synthetic author for V1 (avoid real-author analog to keep voice synthetic from the start). `profiles/authors/synth_v1.yaml`.
- T3.2 — One Genre Profile. Recommend `contemporary_romance_us` — well-documented conventions, RWA references available. `profiles/genres/contemporary_romance_us.yaml`.
- T3.3 — One Audience Profile. `profiles/audiences/kdp_romance_reader.yaml`.
- T3.4 — Three Goal Profiles: `kdp_high_revenue`, `personal_vanity`, `literary_award_target`. `profiles/goals/`.
- T3.5 — Three Sensitivity Profiles: `clean`, `mainstream`, `unrestricted`. `profiles/sensitivity/`.
- T3.6 — Profile composition test: load all five for one book; verify resolution and conflict handling.

**Acceptance.** All profiles validate against schemas. Composition resolution test passes for at least three profile combinations.

**References.** `docs/core-ontology-v3.md` Part II. `docs/references-reading-list.md` §2 (Genre) for romance-specific conventions.

---

## Phase 4 — Knowledge API

**Goal.** The typed retrieval boundary between knowledge stores and agents.

**Tasks.**
- T4.1 — Knowledge API contract. Define `KnowledgeAPI` interface with methods: `get_persona`, `get_structure_template`, `get_voice_constraints`, `get_bible_slice`, `get_open_loops`, `get_patterns`, `get_anti_patterns`, `get_examples`, `propose_bible_delta`.
- T4.2 — File-based implementation. Loads from `profiles/`, `schemas/`, `craft/`, `projects/<book>/`.
- T4.3 — Profile composition resolver. Given Author + Genre + Audience + Goal + Sensitivity references, returns resolved Project Spec with conflict resolution applied per Goal precedence rules.
- T4.4 — In-memory cache with version pinning.
- T4.5 — Tests: profile resolution, conflict resolution, cache invalidation on version change.

**Acceptance.** Knowledge API resolves a profile pentad to a Project Spec deterministically. Resolution is tested across three profile combinations. Cache hit/miss verified.

**References.** `docs/core-ontology-v3.md` §17 (Project Spec composition).

---

## Phase 5 — Spec Intake Pipeline

**Goal.** Take any-fidelity human input and produce a validated Project Spec.

**Tasks.**
- T5.1 — Input Parser. Hybrid: rule-based extractor for structured form fields, LLM-backed for freeform text. Extracts genre keywords, author profile reference, comparable titles, character hints, theme cues, scope cues. Output: partial Project Spec with confidence scores.
- T5.2 — Gap Analyzer. Deterministic. Diffs partial spec against required schema fields for the resolved genre. Output: ranked gap list with severity.
- T5.3 — Gap Filler. LLM-backed with profile priors. For each gap: pull priors from profile triad → propose value → coherence-check against already-known fields. Produces filled spec.
- T5.4 — Clarification Gate (optional, configurable). Selects top-N highest-leverage questions to surface to human. If skipped, falls through to Validator.
- T5.5 — Spec Validator. Deterministic. Checks completeness, coherence (no contradictions), tractability (the spec is buildable). Loops back to Filler if invalid.
- T5.6 — End-to-end intake test: "write me a steamy hockey romance" → validated Project Spec with seed determinism.

**Acceptance.** Five-stage pipeline runs end-to-end. Same input + same seed produces same expanded spec across three runs. Three different fidelity inputs (one-line, one-paragraph, full brief) all resolve to valid specs.

**References.** Response thread on Spec Intake.

---

## Phase 6 — Drafter + Single Critic Vertical Slice

**Goal.** End-to-end generation of a single scene with one critic providing feedback.

**Tasks.**
- T6.1 — Drafter component. Stateless. Input: composed context (persona + structure slice + bible context + open loops + voice constraints + anti-patterns + scene plan). LLM call with seed. Output: prose for the scene.
- T6.2 — Universal Craft Critic. Hybrid implementation: deterministic measurements (voice axes computed on draft, AI-tell catalog scan, specificity index) + LLM nuance for qualitative aspects.
- T6.3 — Convergence Controller (minimal). Just GO / REVISE for now. Threshold from Genre Profile.
- T6.4 — Planner (minimal). Picks scene from Project Spec, produces scene plan with goal, conflict, expected outcome.
- T6.5 — Composer. Composes prompt for Drafter from Knowledge API outputs.
- T6.6 — Generate single scene end-to-end. Validate output schema, voice fidelity within bounds, no hard fails.

**Acceptance.** A single scene generates end-to-end with at most one REVISE cycle. Output is valid prose conforming to scene plan. Voice fidelity score logged.

**References.** `docs/core-ontology-v3.md` §14 (Critic), §3 (Structural Hierarchy), §8 (Convergence).

---

## Phase 7 — Critic Ensemble

**Goal.** Full critic suite running in parallel, aggregated by Convergence Controller.

**Tasks.**
- T7.1 — AI-Tell Critic (deterministic). Loads AI-Tell Catalog, scans draft, computes tell density, returns issues.
- T7.2 — Specificity Critic (deterministic). Computes specificity index per scene, compares to genre floor.
- T7.3 — Continuity Critic (hybrid). Deterministic bible diff + LLM nuance for character voice fidelity.
- T7.4 — Setup-Payoff Critic. Reads Promise Ledger, scans draft for opens/closes, updates ledger, flags overdue.
- T7.5 — Theme Critic (LLM). Subjective; LLM rubric scoring.
- T7.6 — Convention Critic (genre-specific). LLM-backed, rubric pulled from Genre Profile.
- T7.7 — Sensitivity Critic. **Sacred enforcement.** Hard fails on policy violations.
- T7.8 — Critic aggregation. Per-genre weights from Genre Profile, modulated by Goal Profile.
- T7.9 — Updated Convergence Controller with full action set: GO / REVISE / RE-PLAN / FORCE-RESOLVE.

**Acceptance.** Seven critics run on a draft scene. Convergence aggregates with correct weights. Sensitivity violation correctly triggers RE-PLAN (not force-resolve).

**References.** `docs/core-ontology-v3.md` §14 (Critic library), §8 (Convergence rules).

---

## Phase 8 — Reception Ensemble

**Goal.** Simulated readers producing affective response.

**Tasks.**
- T8.1 — Reader persona library: target_demo_reader, genre_veteran, emotional_probe, detail_reader. `profiles/readers/`.
- T8.2 — Reader Agent (LLM). Each invocation runs one reader against a draft, produces response per output schema.
- T8.3 — Reception Aggregator. Combines reader outputs per Audience Profile weights.
- T8.4 — Engagement curve composition.
- T8.5 — DNF likelihood and recommendation likelihood aggregation.

**Acceptance.** Four readers run on a chapter. Aggregator produces engagement curve, DNF max, recommendation min, with all signals logged.

**References.** `docs/core-ontology-v3.md` §15 (Reader).

---

## Phase 9 — Continuity Guardians

**Goal.** Bible Steward and Loop Tracker as enforcement layer.

**Tasks.**
- T9.1 — Bible Steward. Operations: propose_delta, validate_delta, commit_delta, query. Contradiction detection covers all six universal types.
- T9.2 — Loop Tracker. Operations: open, close, audit. Genre-defined deadline norms applied.
- T9.3 — Integration with Convergence: bible contradiction → RE-PLAN; loop overdue → REVISE.
- T9.4 — Bible delta granularity decision (logged to DECISIONS.md). Recommend per beat, scene-level commits.

**Acceptance.** Bible Steward correctly blocks contradictions in test fixtures. Loop Tracker correctly flags overdue promises. Integration with Convergence verified.

**References.** `docs/core-ontology-v3.md` §4 (Continuity), §5 (Promise Ledger).

---

## Phase 10 — Full Generation Loop

**Goal.** End-to-end loop generating multiple chapters with all components.

**Tasks.**
- T10.1 — Force-resolve logic. Pick best candidate, log to issue report, advance.
- T10.2 — Issue report data structure. Append-only. Each entry: thresholds relaxed, alternatives considered, objections overruled.
- T10.3 — Loop budget management (max revise per unit, configurable per Goal).
- T10.4 — Multi-unit pipeline driver: iterates through Project Spec's unit hierarchy.
- T10.5 — End-to-end test: generate 3-chapter test piece.

**Acceptance.** Three-chapter generation runs without halting. Issue report populated with at least one entry. All chapters validate.

**References.** `docs/core-ontology-v3.md` §8 (Convergence FORCE-RESOLVE).

---

## Phase 11 — First Full Book

**Goal.** Generate a complete short novel (40–50K words) end-to-end.

**Tasks.**
- T11.1 — Validate full-book pipeline at scale. Identify performance bottlenecks.
- T11.2 — Tune V1 thresholds based on observed convergence behavior. Log all tuning to DECISIONS.md.
- T11.3 — Generate three full books with three different profile combinations.
- T11.4 — Manual human review of outputs. Capture review notes for calibration.

**Acceptance.** Three books complete generation with full output bundle. Each is at least readable; quality is expected to be uneven at this point.

**References.** All preceding phases.

---

## Phase 12 — V1 ML Components

**Goal.** Five V1 ML pieces shipping into the pipeline.

**Tasks.**
- T12.1 — Threshold calibration regression. Bayesian regression on threshold values vs review scores from Phase 11.
- T12.2 — Voice clustering over Author Profile DB. Compute once, store, useful for `blend()` validation.
- T12.3 — Comp title embedding + retrieval. Sentence-BERT over comp title metadata.
- T12.4 — Bayesian gap-fill priors. Weak Beta priors per profile pair.
- T12.5 — Voice drift detection. Z-score baseline implementation; tripwire integration.

**Acceptance.** Five components in production. Calibration regression updates a profile threshold based on Phase 11 data. Drift detection fires on synthetic drift fixture.

**References.** `docs/ml-opportunity-analysis-v2.md`.

---

## Phase 13 — Voice Extraction Pipeline

**Goal.** Offline pipeline for deriving voice profiles from existing prose without retention.

**Tasks.**
- T13.1 — Tokenization and structural parsing.
- T13.2 — Voice axis measurement implementation (every universal voice axis).
- T13.3 — Pattern detection: high-frequency author-distinctive patterns stored as templates, not quotations.
- T13.4 — Source corpus discard verifier. Test that no prose persists after extraction.
- T13.5 — Voice transformation operators: `modernize`, `genre_shift`, `register_shift`, `simplify`, `elaborate`, `blend`.
- T13.6 — Blend coherence validator.

**Acceptance.** Extract voice profile from a synthetic corpus (we cannot use real authors' work as test fixtures). Verify source discard. Apply `modernize` operator and validate coherence.

**References.** `docs/core-ontology-v3.md` §16 (Voice Extraction), Part on Hard Constraints.

---

## Phase 14 — Final Polish + Publication Package

**Goal.** Optional polish layer + complete publication package generator.

**Tasks.**
- T14.1 — Final Polish Layer. Bounded perturbation operators. Goal-controlled intensity.
- T14.2 — Cover prompt generator. Multi-style prompt variants for image gen tools.
- T14.3 — Marketing copy: blurb candidates, hook, log line.
- T14.4 — Author identity package: bio, social copy.
- T14.5 — Metadata: KDP categories, keywords, comp titles, content warnings (derived from Sensitivity Profile).
- T14.6 — Distribution prep: format specs.

**Acceptance.** Complete publication package generated for a test book. All deliverables validate against their schemas.

**References.** `docs/core-ontology-v3.md` §19 (Final Polish), §20 (Publication Package).

---

## Phase 15 — Generation Report

**Goal.** Browseable HTML report bundle as first-class deliverable.

**Tasks.**
- T15.1 — Report data model. Aggregates from logs.
- T15.2 — HTML report generator with linked JSON detail files.
- T15.3 — Per-unit drilldown views.
- T15.4 — Metrics dashboard: convention compliance, AI-tell density, specificity, pacing actual-vs-target, reader engagement, voice consistency variance.
- T15.5 — Continuity audit view.
- T15.6 — Issue report rendering.
- T15.7 — Calibration data extract for feedback loop.

**Acceptance.** Browseable report generated for a test book. All sections populate. Drill-down navigation works.

**References.** `docs/core-ontology-v3.md` §21 (Generation Report).

---

## Phase 16 — Registries

**Goal.** Profile Axis Registry, ML Opportunity Registry, References Registry as baked-in subsystems.

**Tasks.**
- T16.1 — Registry storage layer (versioned, append-only).
- T16.2 — Registry CRUD operations per type.
- T16.3 — Registry snapshot at run start; reference recorded in run metadata.
- T16.4 — Registry-aware report integration.
- T16.5 — Decision log integration: status changes append decision-log entries.

**Acceptance.** Three registries implemented. Snapshot taken on test run. Status change logged. Re-run reproduces because registry version is pinned.

**References.** `docs/core-ontology-v3.md` §23–24 (Registry subsystems).

---

## Phase 17 — Calibration Loop

**Goal.** Continuous improvement loop closing the feedback cycle.

**Tasks.**
- T17.1 — Calibration data store (SQLite recommended for V1).
- T17.2 — Feedback ingestion API. Structured post-run review schema.
- T17.3 — Re-calibration trigger: manual command, scheduled, auto on accumulated runs.
- T17.4 — Regression update of profile thresholds.
- T17.5 — Versioned profile updates (preserves old versions for reproducibility).
- T17.6 — Calibration report generator.

**Acceptance.** Submit synthetic feedback for three runs. Trigger re-calibration. Verify new profile version produced; old preserved; reproducibility test on past run still passes.

**References.** `docs/core-ontology-v3.md` §18 (Calibration Subsystem).

---

## Beyond Phase 17

After V1 ships:
- Promote auxiliary axes (Era, Cultural, Format, Series, Constraint, AI-Author-Identity) as use cases require.
- Add V2 ML opportunities as data accumulates.
- Build out Critic and Reader persona libraries.
- Expand Genre Profile library.
- Tune calibration regression with more data.

These are not part of the V1 plan. Resist scope creep.

---

## Estimated effort

For a single engineer with a CLI agent assisting:
- Phases 0–4: ~3 weeks
- Phases 5–6: ~2 weeks
- Phases 7–9: ~3 weeks
- Phases 10–11: ~2 weeks
- Phases 12–13: ~3 weeks
- Phases 14–15: ~2 weeks
- Phases 16–17: ~2 weeks

Total V1: ~17 weeks, ~4 months. Add buffer for unknowns, integration issues, and prose-quality iteration. Realistic: 5–6 months to ship V1 producing publishable books.

---

## Status tracking

Add a header at the top of this file as you complete phases:

```
## Status

- [x] Phase 0 — Repository Foundation (completed YYYY-MM-DD)
- [x] Phase 1 — Universal Core Schemas (completed YYYY-MM-DD)
- [ ] Phase 2 — Profile Schemas
...
```

Keep the status section accurate. It's the first thing future sessions read.
