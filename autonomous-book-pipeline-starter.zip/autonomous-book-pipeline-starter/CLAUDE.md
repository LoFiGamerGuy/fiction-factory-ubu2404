# CLAUDE.md — Agent Briefing

This document is your standing context for every session in this repo. Read it first. Re-read it when uncertain.

---

## What this project is

An autonomous book-generation pipeline. Input: a book specification at any fidelity (from "write me a steamy hockey romance" to a fully detailed brief). Output: a publishable manuscript with a complete output bundle (report, publication package, calibration data).

The system is **profile-composed** (Author × Genre × Audience × Goal × Sensitivity), **schema-validated**, **deterministic where possible**, and **fully autonomous between two human gates**: pre-run specification and post-run review.

---

## Reading order for context

When starting a fresh session, read in this order:

1. This file (CLAUDE.md) — orientation
2. `README.md` — project overview
3. `QUICK_REFERENCE.md` — single-page cheat sheet
4. `IMPLEMENTATION_PLAN.md` — phased build plan
5. `tasks/` directory — pick up next task
6. `docs/core-ontology-v3.md` — entity definitions (consult per-section as needed)

For deeper questions:
- Architecture topology → `diagrams/architecture-overview-aesthetic.html` or `diagrams/autonomous-book-pipeline-v5.mermaid`
- Adding a profile axis → `docs/profile-axis-framework-v2.md`
- Adding ML → `docs/ml-opportunity-analysis-v2.md`
- Source material for any concept → `docs/references-reading-list.md`

---

## Hard architectural constraints

**These are non-negotiable.** Every implementation must satisfy them.

1. **No prose retention from external sources.** Voice extraction is measurement only — source prose enters memory, voice axes are computed, prose is discarded. No retained quotations, no prose as drafter examples.

2. **No human gates in the inner loop.** The system is fully autonomous between specification and review. Convergence Controller has four actions: GO, REVISE, RE-PLAN, FORCE-RESOLVE. It never halts asking for input.

3. **Sensitivity Profile thresholds are sacred.** Goal Profile can tighten content policy but cannot loosen it. Sensitivity violations cannot be force-resolved — they trigger RE-PLAN.

4. **Reproducibility is a first-class property.** Every run pins: seed value, model versions (LLM and ML), profile versions, registry snapshots. Reproducing a past run = pinning all of these.

5. **Every component declares its implementation class.** Deterministic / LLM / Hybrid. Default to deterministic where rules suffice. Use LLMs where nuance is required.

6. **Append-only logs.** Decision log, calibration log, registry log, issue report. Nothing is destructive; everything is versioned.

7. **Schemas are the contract.** Every profile, every entity, every component output validates against a schema. Schema validation failures auto-retry, then become FORCE-RESOLVE entries with logging.

---

## Working conventions

### Language and stack

- **Orchestration:** Python 3.11+ with strict typing (`mypy --strict`). Use `pydantic` for runtime validation against schemas.
- **LLM calls:** Anthropic SDK. Default models: Sonnet for drafter, Opus for critics requiring nuance, Haiku for cheap mechanical critics.
- **ML:** `scikit-learn` for V1 (regression, clustering); `scipy.stats` for Bayesian work. Avoid heavyweight ML frameworks until V2 opportunities warrant.
- **Embeddings:** `sentence-transformers` for offline embedding work; OpenAI or Cohere embedding APIs for runtime if needed.
- **Schema validation:** JSON Schema for the canonical schema; `pydantic` models generated from schema for runtime use.
- **Storage:** YAML for human-edited profiles, JSON for machine-generated artifacts, Markdown for craft store, SQLite for calibration data store, all git-versioned.

### Code style

- Type hints on every public function. Run `mypy --strict` and `ruff check`.
- Pure functions where possible. Side effects isolated and named.
- Tests for every component contract. Use `pytest`.
- Schemas live in `schemas/`. Generated pydantic models in `pipeline/schemas/`. Don't edit generated files.

### Component contract pattern

Every component has:
- A typed input schema (pydantic model)
- A typed output schema (pydantic model)
- A `run()` method that is the entry point
- An `impl_class` attribute: `"deterministic"`, `"llm"`, or `"hybrid"`
- A `version` string

This makes components swappable. Same contract, different implementation, configured per pipeline instance.

### Determinism discipline

- LLM calls always pass `seed` parameter when supported.
- Random number generation always uses a seeded generator scoped to the run.
- Profile versions are pinned in the project spec; loading a profile pins its version.
- Registry snapshots taken at run start; the run carries the snapshot reference.

### Logging discipline

- Every component logs structured JSON: component_id, version, input_hash, output_hash, duration, impl_class, model_version (if applicable).
- Logs are partitioned per-run for easy retrieval.
- The Generation Report consumes these logs to produce per-unit drilldowns.

---

## What you should and shouldn't do

### You should

- Pick up tasks from `tasks/` or `IMPLEMENTATION_PLAN.md` in order.
- Read the referenced ontology section before designing any component.
- Write tests alongside code; prefer test-first when the contract is clear.
- Update the appropriate registry (Profile Axis, ML Opportunity) when introducing or changing axes/models.
- Add decision-log entries for architectural choices that future sessions need to know about.
- Ask before introducing dependencies. Prefer the standard library plus the listed core dependencies.

### You shouldn't

- Skip schema validation, even for "simple" cases.
- Hardcode profile values into code. Profiles are data; code is the engine.
- Use prose from external sources as drafter examples or training data.
- Add human gates inside the inner generation loop.
- Loosen Sensitivity Profile thresholds programmatically. They are sacred.
- Treat any thresholds as final values. They are calibration targets, conservative at start, tuned over runs.
- Implement components that only support one genre. Even when starting with one genre, the component must read its parameters from the resolved profile pentad.

---

## Decision-log discipline

When you make an architectural choice not pre-decided in the docs, log it. Format:

```yaml
date: YYYY-MM-DD
decision_id: DEC-NNN
context: what problem or question this addresses
options_considered:
  - option A: pros/cons
  - option B: pros/cons
choice: option chosen
rationale: why
references: links to ontology sections, papers, prior decisions
revisit_when: condition that would re-open this decision
```

Append to `DECISIONS.md` at the repo root. Future sessions read this file.

---

## What "done" means for a task

A task is done when:

1. Code passes `mypy --strict` and `ruff check`.
2. All declared tests pass; coverage is reasonable for the component's surface.
3. Schemas are validated against pydantic models in tests.
4. The decision log is updated if architectural choices were made.
5. The relevant runbook section is updated to reflect the actual implementation.
6. A commit is made with a clear message that references the task ID.

---

## Where to start (cold start, first session)

If you've never seen this repo before:

1. Read this file (you're doing it).
2. Read `README.md`.
3. Read `IMPLEMENTATION_PLAN.md` Phase 0 and 1.
4. Open `tasks/task-001-foundation.md`.
5. Begin implementation. Ask the user for clarification only if a constraint is genuinely ambiguous.

---

## Working with the human

The user (Ryan) is a senior systems engineer with deep architectural intent already encoded in the docs. He wants:

- Concrete progress per session
- Honest engineering tradeoffs surfaced
- Decisions logged, not hidden
- Pushback when his suggestion conflicts with the documented architecture (cite the doc and the constraint)
- Tight, scannable updates over verbose narration

He doesn't want:

- Sycophantic agreement
- Hidden complexity
- Decisions made without log entries
- Departures from the architecture without explicit discussion

If a request seems to violate a hard constraint (the seven items above), surface the conflict, cite the constraint, and propose alternatives. Don't silently comply.

---

## A note on scope

This is a multi-month build. Don't try to ship the whole thing in one session. The implementation plan is phased deliberately. Each phase produces something testable. Do not skip ahead because a later component seems more interesting — earlier phases are foundational and unblock everything that follows.

If you finish a task with time and budget remaining, the right move is usually:
1. Improve test coverage on what you just built
2. Document any decisions you made
3. Pick the next task in the plan

Not:
- Jumping ahead to a flashier phase
- Adding speculative features beyond the contract
- Refactoring untouched code without justification
