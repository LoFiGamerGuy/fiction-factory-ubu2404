# Profile Axis Exploration Framework v2

**Purpose.** Methodology for proposing, evaluating, prototyping, and promoting composition axes in the profile stack. This framework is implemented as the **Profile Axis Registry** — a baked-in subsystem (see `core-ontology-v3.md` §23) — not just a design document.

**Status.** Living. Updated as new axes change status.

**Reading list pointer:** see `reading-list.md` §6 (Genre Theory).

---

## 1. Composition Stack Architecture

Three tiers:

**Primary Axes** — first-class profiles with full schema, override rules, conflict-resolution participation.

**Auxiliary Profiles** — optional profiles that layer in when use case requires. Lighter-weight schemas. Promoted to Primary if indispensable.

**Derived Profiles** — computed at runtime; not stored independently.

**Project-Local Parameters** — per-book values; not profiles.

---

## 2. V1 Primary Axes

```
Author × Genre × Audience × Sensitivity × Goal
```

Sensitivity was promoted from auxiliary in this v2 based on the criticality of explicit content policy for autonomous generation. Tier-1 candidates (Era, Cultural/Regional, Format/Medium) remain auxiliary, primed and not forgotten.

---

## 3. Evaluation Criteria

A candidate must satisfy **all five** to be promoted to Primary; **at least three** to remain Auxiliary; otherwise fold or reject.

**C1.** Cross-cuts existing axes
**C2.** Reusable across books
**C3.** Affects multiple downstream components
**C4.** Has identifiable conflicts with other axes
**C5.** Has stable, finite vocabulary

---

## 4. Candidate Registry

Status legend: `proposed`, `evaluating`, `prototyped_auxiliary`, `primary`, `folded`, `rejected`.

### V1 Primary

| Axis | Status | Promoted | Notes |
|------|--------|----------|-------|
| Author | primary | V1 | core-ontology §11 |
| Genre | primary | V1 | §9 |
| Audience | primary | V1 | §10 |
| Goal | primary | V1 | §13 |
| Sensitivity | primary | **V1 (promoted from auxiliary)** | §12; sacred precedence |

### Tier-1 Candidates (primed, not forgotten)

#### 4.1 Era / Period Profile
**Status:** prototyped_auxiliary
**Concept:** Production-era voice and convention norms — "written in 2024" vs "written in 1985."
**Affects:** voice norms, pacing expectations, vocabulary register, cultural reference patterns
**Promotion trigger:** era-shifted voice generation becomes primary use case
📚 *Reading List §1, §2*

#### 4.2 Cultural / Regional Profile
**Status:** prototyped_auxiliary
**Concept:** Market-specific conventions — US KDP romance vs UK romance vs translated-from-Japanese light novel.
**Affects:** length norms, dialogue conventions, idiom and reference patterns, taboos
**Promotion trigger:** international or translation-aware authoring routine
📚 *Reading List §6, §7*

#### 4.3 Format / Medium Profile
**Status:** prototyped_auxiliary
**Concept:** Print novel vs ebook vs serial vs audiobook-first vs Vella vs interactive fiction.
**Affects:** chapter length, scene boundaries, paragraph density, dialogue rhythm, cliffhanger discipline
**Promotion trigger:** authoring across formats becomes routine
📚 *Reading List §14, §11*

### Tier-2 Candidates (auxiliary when use case appears)

#### 4.4 Series Position Profile
**Status:** prototyped_auxiliary
**Concept:** Standalone vs series-opener vs middle vs finale vs spin-off vs prequel.
**Affects:** assumed reader knowledge, callback density, setup/payoff balance, ending finality
**Promotion trigger:** series support enters scope
📚 *Reading List §9*

#### 4.5 Constraint Profile
**Status:** evaluating
**Concept:** Externally-imposed hard limits. Distinct from goal (intent-driven).
**Affects:** length limits, content restrictions, format requirements
**Promotion trigger:** contract-driven authoring enters scope
📚 *Reading List §11*

#### 4.6 AI-Author-Identity Profile
**Status:** evaluating
**Concept:** Public persona of AI author as distinct from author voice.
**Affects:** bio, author-photo prompt, social copy, branding consistency, marketing
**Promotion trigger:** AI-author publication enters scope
📚 *Reading List §11, §12*

### Tier-3 Candidates (auxiliary, specialized)

#### 4.7 Theme / Symbolic-System Profile
**Status:** proposed — recommend Auxiliary
📚 *Reading List §4.2, §15*

#### 4.8 Translation-Awareness Profile
**Status:** proposed — recommend Auxiliary

#### 4.9 Narrator-Reliability Profile
**Status:** proposed — recommend Auxiliary if pursuing complex narrators
📚 *Reading List §2*

### Folded into Existing Profiles

| Candidate | Folded into | Rationale |
|-----------|-------------|-----------|
| Trope-Specific Mastery | Genre | Tropes live in genre's trope library |
| Linguistic/Rhetorical | Author Voice | Whitelisted/blacklisted constructions |
| Reading-Mode | Format | Sub-dimension of format |
| Marketing-Channel | Goal + Audience | Marketing is intent + audience |
| Authorial-Stance | Goal | Stance is part of intent |
| Adaptation-Target | Goal | Adaptation-readiness is intent |
| Pacing-Density | Goal + Author | Pacing intent + author signature |
| Emotional-Tone | Goal | Tonal intent is goal |
| Worldbuilding-Density | Genre | Existing density parameters cover |

### Rejected as Primary

| Candidate | Reason |
|-----------|--------|
| POV-Character Voice (book-internal) | Project-local; lives in bible's character objects |

---

## 5. Conflict Resolution Implications

V1 (5 primary axes) → 10 pairwise conflict surfaces per parameter type. Manageable.

If all Tier-1 promoted (8 primary) → 28 surfaces. Still manageable.

If all Tier-2 also promoted (10 primary) → 45 surfaces. Approaching unwieldy.

**Default precedence (V1):**
```
Sensitivity > Constraint > Goal > Genre > Audience > Author
```

Sensitivity is *always* sacred. Goal-specific overrides shift the rest per use case.

---

## 6. Proposal Process

**Step 1.** Submit via `propose_axis()` API (core-ontology §23).

**Step 2.** Evaluate C1–C5; document verdicts.

**Step 3.** Determine status:
- All five satisfied → eligible Primary; start Auxiliary
- Three or four → Auxiliary
- Two or fewer → fold or reject

**Step 4.** Auxiliary prototype: ≥3 books. Measure value, manual override frequency, productive conflicts.

**Step 5.** Promotion review.

**Step 6.** Update registry; commit to decision log.

### Proposal Template

```yaml
proposal_id: [unique]
title: [name]
status: proposed
proposer: [who]
date: [when]
concept: [1-paragraph]
examples: [3-5 values]
affects: [downstream components]
evaluation:
  c1_cross_cuts: {verdict, rationale}
  c2_reusable: {verdict, rationale}
  c3_multi_component: {verdict, rationale}
  c4_conflicts: {verdict, rationale}
  c5_finite_vocabulary: {verdict, rationale}
recommendation: [primary | auxiliary | fold | reject]
rationale: [paragraph]
fold_target: [if folded]
reading_refs: [reading-list sections]
```

---

## 7. Decision Log Format

Append-only entries committed to the Profile Axis Registry on every status change:

```yaml
date: [when]
axis_id: [which]
old_status: [from]
new_status: [to]
rationale: [why]
evidence: [data refs if applicable]
authored_by: [who]
```

---

## 8. Registry Subsystem Integration

The Profile Axis Registry is a **baked-in subsystem** (core-ontology §23).

**Read API:** `query_axes(filter)`, `snapshot()` (in every Generation Report)

**Write API:** `propose_axis`, `evaluate_axis`, `update_status`

**Audit:** decision log append-only and versioned; every status change timestamped + attributed; Generation Reports include registry snapshot at run time.

This document is the human-readable view; the registry is source of truth.

---

## 9. Promotion Roadmap

**V1 promoted:** Sensitivity (joins Author, Genre, Audience, Goal).

**Promote when scope warrants:** Era/Period, Cultural/Regional, Format/Medium.

**Promote when use case appears:** Series Position, Constraint, AI-Author-Identity.

**Auxiliary only:** Theme, Translation-Awareness, Narrator-Reliability.

Realistic primary set growth: 5 → 7–8 over time.

---

## 10. Open Meta-Questions

1. Are five criteria right? Could expand to authoring/validation cost.
2. Demotion path from Primary to Auxiliary? Yes — if rarely used or systematically folded.
3. Migration when an axis is promoted? Backfill: defaults applied; pre-promotion books flagged.
4. Hierarchical axis relationships? Currently fold-based composition; could be explicit.
5. Registry review cadence? Quarterly + on-demand when conflict patterns emerge.
6. Promotion governance? Prototype-evidence threshold + review by architecture stakeholders.
