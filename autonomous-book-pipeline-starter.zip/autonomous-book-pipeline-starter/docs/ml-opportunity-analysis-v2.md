# ML Opportunity Analysis v2

**Purpose.** Map opportunities for machine learning beyond LLM calls across the pipeline. This analysis is implemented as the **ML Opportunity Registry** — a baked-in subsystem (see `core-ontology-v3.md` §24) — not just a design document.

**Status.** Living. Opportunities move through proposed → prototyped → in_production → retired as data accumulates and use cases shift.

**Reading list pointer:** see `reading-list.md` §3 (Computational Stylistics), §12 (AI in Creative Writing), §15 for technical references per surface.

---

## 1. Why ML Beyond LLMs

LLMs are powerful but have specific costs and weaknesses. ML opportunities exist where:

- **Cost dominates** — high-frequency operations make per-call cost matter.
- **Reproducibility matters** — deterministic models give bit-identical outputs.
- **Specificity beats generality** — task-trained classifiers outperform general LLMs on narrow tasks.
- **Calibration improves over time** — models get better as data accumulates.
- **Interpretability is required** — regression coefficients are inspectable.
- **Tripwires need to be silent** — anomaly detection wants low cost on every check.

Pattern: **rules + classical ML for the structured/measurable layer, LLMs for the nuanced/creative layer.**

---

## 2. ML Approach Catalog

- **REG** — supervised regression (continuous outputs)
- **CLS** — classification (discrete labels)
- **CLU** — clustering / unsupervised
- **EMB** — embeddings / retrieval
- **PROB** — Bayesian / probabilistic
- **BAND** — bandit / reinforcement learning
- **ANOM** — anomaly detection
- **SEQ** — time-series / sequence modeling
- **CAUS** — causal inference

---

## 3. Opportunity Map by Pipeline Surface

### 3.1 Spec Intake Pipeline

**O1. Bayesian gap-filling priors [PROB]** — propose values with credible intervals; LLM only invoked when prior is wide. **Tier: V1**
📚 *§3, §6, §11*

**O2. Spec coherence scoring [CLS / REG]** — model scores spec coherence; flags incoherent specs cheaply. **Tier: V2**

**O3. Genre embedding for cross-genre weighting [EMB]** — continuous space for blended genre specification. **Tier: V2**
📚 *§6*

### 3.2 Generation Loop

**O4. Engagement curve prediction [SEQ / REG]** — pre-reception precognition; skip cheap readers if predicted healthy. **Tier: V2**
📚 *§8, §14*

**O5. Voice drift anomaly detection [ANOM]** — z-score baseline (V1); ML upgrade later. **Tier: V1**
📚 *§3, §15.4*

**O6. Bible coherence drift detection [ANOM / EMB]** — embedding-based subtle continuity drift. **Tier: V3**
📚 *§10*

**O7. Causal attribution of revisions [CAUS]** — attribute slow-converging units to causes (planning, profiles, prompts). **Tier: V3**

### 3.3 Critic Implementations

**O8. Trope detection NLP [CLS / EMB]** — classifier over labeled trope corpus. **Tier: V2**
📚 *§7*

**O9. AI-tell pattern discovery [CLU]** — cluster analysis to discover novel AI tells. **Tier: V2**
📚 *§15.5*

**O10. Specificity metric learning [REG]** — context-aware specificity scoring. **Tier: V3**
📚 *§15.1*

**O11. Setup-payoff matching [CLS / EMB]** — coreference + semantic similarity for promise tracking. **Tier: V2**
📚 *§4.2*

**O12. Dialogue voice fidelity per character [REG / EMB]** — per-character voice embeddings. **Tier: V2**
📚 *§15.3*

### 3.4 Reception Ensemble

**O13. Reader persona learning from review data [CLU]** — discover reader types in real review data. **Tier: V2**
📚 *§8, §16*

**O14. DNF likelihood prediction [CLS / REG]** — fast pre-screen. **Tier: V2**
📚 *§8*

**O15. Recommendation likelihood prediction [CLS]** — trained on review data. **Tier: V2**

**O16. Audience clustering for profile authoring [CLU]** — derive Audience Profile values from review patterns. **Tier: V3**

### 3.5 Convergence and Calibration

**O17. Threshold calibration regression [REG / PROB]** — Bayesian regression on threshold values vs review scores. **Tier: V1** (already in architecture)
📚 *Engineering literature on Bayesian calibration*

**O18. Critic weight learning [REG / BAND]** — learn which critics actually predicted quality. **Tier: V2**

**O19. Reader weight learning [REG / BAND]** — same for reader personas. **Tier: V2**

**O20. Voice fidelity distance function learning [REG]** — learn weights over voice axes from labeled data. **Tier: V2**
📚 *§3, §15.4*

**O21. Convergence threshold per profile pair [PROB]** — hierarchical Bayesian model. **Tier: V3**

### 3.6 Knowledge Layer

**O22. Voice clustering for blend operations [CLU / EMB]** — cluster authors in voice-axis space; validate blend coherence. **Tier: V1**
📚 *§3, §15.4*

**O23. Comp title embedding and retrieval [EMB]** — feature-space embedding of comp titles. **Tier: V1**
📚 *§11*

**O24. Genre boundary modeling [PROB / CLS]** — probabilistic genre membership. **Tier: V2**
📚 *§6*

**O25. Profile similarity search [EMB]** — embed profiles for nearest-neighbor queries. **Tier: V2**

### 3.7 Publication Package

**O26. Cover prompt optimization [BAND]** — bandit over prompts vs KDP click-through. **Tier: V3**
📚 *§11*

**O27. Title selection prediction [CLS / REG]** — predict best-performing title. **Tier: V3**

**O28. Blurb A/B prediction [CLS]** — same for blurb candidates. **Tier: V3**

**O29. Keyword optimization [BAND]** — keyword sets vs discoverability. **Tier: V3**

### 3.8 Voice Extraction

**O30. Confidence scoring per voice axis [REG]** — predict extraction confidence from corpus features. **Tier: V2**
📚 *§3, §15.4*

**O31. Voice signature uniqueness [CLU]** — detect highly distinctive vs generic voices. **Tier: V3**

---

## 4. Prioritization Framework

**Scoring criteria (1–5 each):**
- **S1.** Value (quality / cost impact)
- **S2.** Data availability
- **S3.** Implementation complexity (inverted; high = easy)
- **S4.** Reproducibility preservation
- **S5.** Replaceability (inverted; high = unique value vs deterministic alternative)

**Total = sum (max 25). Tier mapping:**
- ≥ 18: V1
- 13–17: V2
- 8–12: V3
- < 8: skip

### Priority Tier Summary

**V1 essentials:** O1, O5, O17, O22, O23
**V2 high-value:** O2, O3, O4, O8, O11, O12, O13, O14, O15, O18, O19, O20, O24, O25, O30
**V3 exploratory:** O6, O7, O10, O16, O21, O26, O27, O28, O29, O31

---

## 5. Cross-Cutting ML Infrastructure

To support these opportunities the architecture needs (matures with V2):

- **Feature Store** — versioned features extracted during runs
- **Model Registry** — versioned model artifacts with training-data hashes
- **Training Pipeline** — scheduled retraining
- **Online Inference Service** — low-latency runtime predictions
- **Experiment Tracker** — proposal/training/eval/decision log
- **Labeling Workflow** — structured human-labeling for supervised opportunities

V1 ML pieces are simple enough to implement as scripts against existing data; full infrastructure is justified at V2 onset.

---

## 6. Registry Subsystem Integration

The ML Opportunity Registry is a **baked-in subsystem** (core-ontology §24).

**Data model:**
```yaml
opportunity:
  id, name, surface, approach_tags
  current_status: enum[proposed, prototyped, in_production, retired]
  priority_tier: enum[V1, V2, V3, skip]
  scoring: {s1..s5, total}
  training_data_ref
  model_versions:
    - version, trained_at, training_data_hash, eval_metrics, promoted
  decision_log: [append-only]
```

**API:** `propose_opportunity`, `update_status`, `register_model_version`, `promote_model`, `query_opportunities`, `snapshot()`.

**Reproducibility:** every Generation Report snapshots which model versions were active for the run. Reproducing a past run = pinning model versions + seed + profile versions.

This document is the human-readable view; the registry is source of truth.

---

## 7. Cost-Benefit Analysis

**High-leverage early wins:**
- O1 — every spec hits this; even weak priors save tokens
- O17 — every run informs every future run; compounding value
- O22 — cheap one-time computation; makes voice blending coherent
- O23 — replaces an expensive LLM task with embedding retrieval

**Compound-interest opportunities:**
- O18, O19, O20 — improve with every book and every author profile

**Wait-and-see:**
- O26–O29 — only valuable once published-book performance data exists

---

## 8. Determinism vs Learnability Tradeoff

ML adds learnability but often costs reproducibility. Pure determinism is reproducible but doesn't improve.

**Policy:**
- **Inner-loop runtime components** (drafter, critics, readers): bias toward determinism + LLM. ML auxiliaries are optional fast-path predictions.
- **Calibration / configuration**: ML appropriate; reproducibility via versioning.
- **Knowledge layer** (profile DBs): ML for clustering/embedding/retrieval; underlying data remains source of truth.

**Versioning discipline:** any run records model versions used; reproducing a past run = pin all versions + seed.

---

## 9. Open Questions

1. Cold-start labels — bootstrap from meta-discussion analysis; mark as low-confidence; refine over reviews.
2. Right model class per opportunity — prototype phase compares alternatives.
3. ML model evaluation — held-out test sets per opportunity, significance testing.
4. When LLM replaces classical ML — periodic re-evaluation as LLM costs drop.
5. Model drift — periodic re-evaluation; alert on accuracy degradation; retrain or fallback.
6. ML hyperparameter calibration — calibration subsystem extends to ML hyperparameters.
7. Data privacy posture — no prose persisted; review/feedback may be PII-adjacent; explicit retention policy needed.

---

## 10. Recommended V1 Implementation Sequence

If building today, ML pieces in order:

1. **O17 — Threshold calibration regression** (already specified)
2. **O5 — Voice drift anomaly detection** (z-score baseline; trivial)
3. **O22 — Voice clustering** (one-time computation over Author Profile DB)
4. **O23 — Comp title embedding + retrieval** (well-understood tech)
5. **O1 — Bayesian gap-filling priors** (start with weak Beta priors)

Total V1 ML scope: 5 opportunities, all bounded. Roughly equivalent to one ML engineer-month of work plus ongoing calibration tuning. The remaining 26 opportunities accumulate as data and use cases warrant.
