# Core Ontology v3 — Autonomous Book Pipeline

**Purpose.** Define every major component as a parameterized entity with quantifiable axes, organized into a Universal Core that applies to all writing and a Layered Specialization system (Genre → Audience → Author → Sensitivity → Goal → Project) that overrides and extends the core. Every component implements a typed contract that can be swapped between deterministic, LLM-driven, and hybrid implementations. The Profile Axis Registry, ML Opportunity Registry, and Reading List are first-class subsystems alongside the Calibration Subsystem.

**Design principles.**
- **Universal where possible, specific where necessary.** Most of the system is shared; variance lives in profiles.
- **Described, not sampled.** No definition derives from prose retention.
- **Measurable on output.** Voice and craft are numeric distances, not vibes.
- **Deterministic by default, swappable at the contract.**
- **Goal drives conflict resolution.**
- **Reproducible.** Same inputs + seed = same outputs.
- **Self-evolving with provenance.** Every meta-decision is versioned and logged.

**Profile composition stack (V1):**

```
Universal Core
    ↓ overridden/extended by
Genre Profile
    ↓ overridden/extended by
Audience Profile
    ↓ overridden/extended by
Author Profile
    ↓ overridden/extended by
Sensitivity Profile ★ V1 PRIMARY
    ↓ overridden/extended by
Goal Profile (decides conflicts)
    ↓ overridden/extended by
Project Spec
```

**Auxiliary profiles primed:** Era · Cultural/Regional · Format/Medium · Series Position · Constraint · AI-Author-Identity. See `profile-axis-framework-v2.md`.

---

# PART I — UNIVERSAL CORE

## 1. Book

A hierarchical narrative artifact composed under a profile stack, with all opened promises closed.

**Identity:** `id`, `title`, `seed_value`, `profile_refs` (author, genre, audience, sensitivity, goal IDs), `concept_seed`.

**Validity criteria:** Word count within target ± tolerance; all units committed; Promise Ledger zero overdue; Bible zero unresolved contradictions; Convergence Controller no pending REVISE/RE-PLAN; Whole-manuscript pass zero hard failures; **Sensitivity Profile compliance verified**.

**State refs:** `bible_ref`, `promise_ledger_ref`, `manuscript_ref`, `decision_log_ref`, `issue_report_ref`, `calibration_log_ref`, `axis_registry_snapshot_ref`, `ml_registry_snapshot_ref`.

📚 *Reading List §4, §6*

## 2. Voice Axes

Every author has a voice; every voice is described by the same axes. Values vary by author profile; axes themselves are universal and measurable on any prose.

**Sentence-level:** `sentence_length_mean/std/distribution`, `sentence_opener_distribution`, `sentence_opener_entropy_min`, `sentence_mood_distribution`.

**Lexical:** `lexical_diversity_target` (TTR/MTLD), `formality_register`, `rare_word_frequency`, `concrete_noun_ratio`, `sensory_token_density` (per modality).

**Structural prose:** `dialogue_to_narration_ratio`, `internal_monologue_share`, `figurative_language_frequency`.

**Punctuation signature:** `em_dash_rate_max`, `semicolon_rate`, `ellipsis_rate`, `parenthetical_rate`, `comma_density`.

**Cadence:** `short_long_alternation_index`, `paragraph_length_mean/distribution`.

**Modality and stance:** `modal_hedge_frequency`, `adverb_density`, `adjective_stacking_max`.

**POV craft:** `pov_distance_default`, `narrator_intrusion_frequency`, `time_of_narration`.

**Validation:** A draft passes voice fidelity when all axes are within tolerance bands of the author profile's spec, no blacklisted constructions are detected, whitelisted constructions appear at expected frequency, aggregate voice distance ≤ threshold.

📚 *Reading List §1, §2, §3, §15.2, §15.4*

## 3. Structural Hierarchy

The unit tree of any book.

**Generic Unit:** `id`, `parent_unit_id`, `position`, `unit_type` (book/part/act/chapter/scene/beat), `target_word_count`, `actual_word_count`, `function`, `entry_state`, `exit_state`, `state`.

**Beat:** `function`, `intensity`, `pov_character_id`, `location_id`, `time_marker`, `characters_present`, `expected_reader_response`, `setup_for`, `payoff_of`, `cause_of`, `caused_by`.

**Scene:** `goal`, `conflict`, `outcome`, `state_delta`, `beats`.

**Chapter:** `hook`, `cliffhanger_required`, `pov_character_id`, `scenes`.

**Act/Part:** `arc_function`, `chapters`.

📚 *Reading List §4.1, §4.2*

## 4. Continuity Model

Canonical truth. Every prose assertion must be derivable from or consistent with the bible.

**Top-level entities:** `characters`, `locations`, `objects`, `concepts`, `factions`, `timeline`, `relationships`.

**Character object:** `id`, `name`, `aliases`, `physical`, `psychological`, `voice`, `arc`, `relationships`, `backstory`, `taboos`.

**Operations:** `propose_delta`, `validate_delta`, `commit_delta`, `query`.

**Contradiction types:** type-mismatch, timeline-violation, spatial-violation, capability-violation, voice-violation, taboo-violation.

📚 *Reading List §10, §5*

## 5. Promise Ledger

Append-only log of narrative promises.

**Promise object:** `id`, `type`, `opened_at/by`, `must_resolve_by`, `resolution_state`, `resolved_at/by`, `priority`, `description`, `acceptable_resolutions`.

**Promise types:** foreshadowing, chekhov_object, character_question, mystery_thread, emotional_debt, thematic_setup, romantic_tension, world_question.

**Convergence rule:** no GO at chapter level if any promises are overdue.

📚 *Reading List §4.2, §4.1*

## 6. AI-Tell Catalog

Genre-agnostic patterns flagging LLM-generated prose.

**Pattern entry:** `pattern_id`, `regex_or_rule`, `severity` (1–5), `context_required`, `suggested_replacement_strategy`.

**Categories:** punctuation tells, construction tells, hedge tells, cliché tells, abstract-noun stacking, predictable openers, rhythm tells, closing-summary patterns, bestseller-bot voice markers.

📚 *Reading List §15.5, §3*

## 7. Specificity Heuristics

**Metrics:** `concrete_noun_count_per_scene`, `proper_noun_density`, `sensory_anchor_frequency` (by modality), `cultural_specificity_index`, `temporal_anchoring`, `spatial_anchoring`.

📚 *Reading List §15.1, §1*

## 8. Convergence Function

Deterministic decision rule.

**Decision rule (in order):**
1. **Hard fails → RE-PLAN:** Bible contradiction, must-have absent, taboo violation, **sensitivity violation (HARD)**, DNF likelihood > goal-defined ceiling.
2. **REVISE:** weighted critic score < threshold; weighted reader satisfaction < threshold; voice fidelity distance > threshold; AI-tell density > ceiling; specificity index < floor; engagement floor < threshold; promise ledger overdue.
3. **FORCE-RESOLVE (after max revise):** highest-scoring candidate, log relaxed thresholds, append issue report, commit and continue.
4. **GO:** commit.

**Universal property:** never halts.

📚 *Reading List §13; engineering literature on Bayesian calibration*

---

# PART II — SPECIALIZATION LAYERS (V1 Primary)

## 9. Genre Profile

**Structural conventions:** length range, chapter ranges, scene ranges, allowed structure templates.

**Pacing template:** tension curve, climax position, subplot weave, reveal cadence.

**Tonal range — intensity scales (genre-defined):** each axis has anchors, defaults, ranges, measurement heuristics.

**Trope library:** `must_haves`, `commonly_loved`, `taboos`, `fresh_twist_hotspots`.

**Voice norms:** POV distribution, tense distribution, register range, prose density range.

**Reader contract:** DNF triggers, loyalty triggers, required emotional beats, pacing expectations.

**Pipeline configuration:** required critics with weights, required readers, convergence thresholds, max revise attempts, promise resolution deadlines.

**Comp basis:** comp titles (metadata only), convention sources.

📚 *Reading List §6, §7 (relevant subsection)*

## 10. Audience Profile

**Reading lens:** attention anchors, engagement pattern, reading velocity.

**Tolerance bands:** complexity, ambiguity, slow-pace, darkness, experimentation.

**Expectation set:** required satisfactions, forbidden disappointments.

**Trigger sets:** DNF, loyalty, recommendation.

**Reader instantiation:** reader personas with weights, default reader count.

**Provenance:** derivation sources.

📚 *Reading List §8, §14, §16*

## 11. Author Profile

**Identity:** `id`, name (pen name), bio, lineage (descriptions, not citations).

**Voice axis values:** specific values for every Universal Voice Axis (§2), within tolerance bands.

**Qualitative anchors:** tonal default, thematic obsessions, taboos, whitelisted constructions, blacklisted constructions, rhythmic preferences.

📚 *Reading List §1, §2, §3*

## 12. Sensitivity Profile ★ V1 PRIMARY

Content sensitivity policy. **Required for autonomous content generation.** Implicit handling means content decisions get made based on whatever happens to be in other profiles, which is dangerous. The Sensitivity Profile makes content policy explicit, auditable, and goal-immune (Goal Profile cannot loosen Sensitivity sacred thresholds).

**Identity:** `id`, `name`, `description`.

**Content rating:**
- `content_rating` (enum: family_friendly, ya_safe, new_adult, adult_unrestricted, custom)
- `age_floor`

**Intensity ceilings (per genre's intensity scales):**
- `ceiling_overrides` (map<intensity_axis, max_value>)

**Topic policies:**
- `topic_handling` (map<topic, policy>): `forbidden`, `permitted`, `required_warning`, `required_thoughtful`
- Topics: substance use, sexual content, violence, self-harm, suicide, sexual assault, child harm, animal harm, racism, ableism, religious content, political content, etc.

**Marginalized-group depiction policies:**
- `representation_policy`
- `language_restrictions`
- `authenticity_requirements`

**Content warnings:**
- `auto_warnings`, `warning_format`

**Validation hooks:**
- `pre_draft_check` — applied to plan before drafting
- `post_draft_check` — sensitivity-aware critic
- `final_audit` — whole-manuscript scan

**Sensitivity Critic (special):** instantiated for any book with this profile; HARD VETO authority on sensitivity-violation hard fails.

**Starter library:**
- `family_friendly`, `ya_safe`, `new_adult`, `adult_unrestricted`, `trigger_aware_thoughtful`, `clean_christian`, `educational_safe`

**Sacred status:** Sensitivity Profile thresholds are *always* sacred. Goal profiles can tighten sensitivity but cannot loosen it.

📚 *Reading List: SCBWI sensitivity reader guidance, RWA depiction guidance, professional sensitivity readers' published work; §7 for genre-aware considerations*

## 13. Goal Profile

The intent-specific overlay that **governs conflict resolution** when other profiles disagree, and tunes convergence to the goal of this particular book.

**Conflict resolution rules:**
- `precedence_per_axis` (map<axis_name, ordered list of profile sources>)
- **Note:** Sensitivity always wins on sensitivity-related axes; not negotiable.

**Convergence weight overrides:** `critic_weight_modifiers`, `reader_weight_modifiers`, `metric_priority`.

**Sacred vs flexible thresholds:**
- `sacred_thresholds` (cannot be relaxed even on FORCE-RESOLVE; Sensitivity always sacred)
- `flexible_thresholds`

**Goal-specific metrics:** chapter_hook_strength (serial), thematic_resonance (literary), comp_title_alignment (KDP), etc.

**Force-resolve policy:** `force_resolve_direction`.

**Success criteria:** `success_metrics`, `acceptance_thresholds`.

**Starter library:** `kdp_high_revenue`, `patreon_serial`, `literary_award_target`, `experimental_unique`, `personal_vanity`, `educational`, `series_continuation`.

📚 *Reading List §11, §6*

## 14. Project Spec

Per-book final values. Output of Spec Intake Pipeline.

---

# PART III — AGENTS AND SUBSYSTEMS

## 15. Critic

Persona-driven evaluator producing structured critique.

**Universal critic types:**
- `craft_critic`, `ai_tell_critic`, `specificity_critic`, `continuity_critic`, `setup_payoff_critic`, `theme_critic`
- **`sensitivity_critic`** ★ — hard-veto authority on sensitivity violations

**Genre-specific critics:** instantiated per genre profile.

**Output schema:** critic_id, unit_id, scores, aggregate_score, verdict, issues, specific_callouts.

📚 *Reading List §13, §1, §2*

## 16. Reader

Persona-driven simulated reader producing affective response.

**Universal reader personas:** target_demo_reader, genre_veteran, emotional_probe, detail_reader, skim_reader, audiobook_listener, first_chapter_grader, last_chapter_grader.

**Output schema:** engagement_curve, emotional_responses, expectation_violations/satisfactions, dnf_likelihood, recommendation_likelihood, verbatim_reactions, overall_satisfaction.

📚 *Reading List §8, §14*

## 17. Voice Extraction Pipeline

Offline subsystem deriving voice profiles without prose retention.

**Process:** tokenize → measure axes → distribution shapes → pattern detection (templates, not quotations) → qualitative anchors from meta-discussion → emit YAML → discard source.

**Voice transformations:** `modernize`, `genre_shift`, `register_shift`, `cadence_adjust`, `simplify`, `elaborate`.

**Voice blending:** `blend(profile_a, profile_b, weight)`.

📚 *Reading List §3, §15.4*

## 18. Spec Intake Pipeline

Five stages: Input Parser → Gap Analyzer → Gap Filler → Clarification Gate → Spec Validator. Deterministic given input + seed.

📚 *Reading List §1, §6, §7*

## 19. Calibration Subsystem

Continuous tuning of thresholds and weights from feedback.

**Modes:** cold-start, continuous, re-calibration trigger.

**Process:** pull feedback → regress threshold/weight values → propose with credible intervals → calibration report → apply (auto or human-approved) → version profiles.

📚 *Engineering literature on Bayesian calibration*

## 20. Final Polish Layer (optional)

Reactive de-AI-ification: rhythm variation injection, idiosyncratic substitutions, structural variation, strategic imperfection. Goal-controlled intensity. Re-validates against Universal Core.

📚 *Reading List §15.5*

## 21. Publication Package Generator

Outputs: cover prompts + post-process chain, marketing copy (blurb, hook, log line, query, back-cover), author identity package, metadata (categories, keywords, comp titles, **content warnings derived from Sensitivity Profile**), distribution prep, launch package.

📚 *Reading List §11*

## 22. Generation Report

Sections: top-level summary, spec expansion log, per-unit drilldown, aggregate metrics, continuity audit, issue report, calibration data, **registry snapshots** (axis statuses + ML model versions for this run).

**Format:** HTML + linked JSON detail.

---

# PART IV — META-ARCHITECTURE SUBSYSTEMS

These subsystems track and govern system evolution. Baked-in alongside Calibration.

## 23. Profile Axis Registry ★ NEW

Tracks all profile axes with status, decision history, prototype evidence.

**Data model:**
```yaml
axis:
  id, name
  current_status: enum[proposed, evaluating, prototyped_auxiliary, primary, folded, rejected]
  evaluation: {c1..c5: verdict + rationale}
  schema_ref: [if Auxiliary or Primary]
  fold_target: [if Folded]
  prototype_evidence:
    books_run, value_added, conflicts_observed
  decision_log: [append-only]
```

**API:** `propose_axis`, `evaluate_axis`, `update_status`, `query_axes`, `snapshot()` (referenced by every Generation Report).

**Status lifecycle:** proposed → evaluating → prototyped_auxiliary → primary (or → folded / rejected).

**Decision log entry:** `{date, axis_id, old_status, new_status, rationale, evidence, authored_by}`.

**V1 state:**

| Axis | Status |
|------|--------|
| Author | primary |
| Genre | primary |
| Audience | primary |
| Goal | primary |
| Sensitivity | primary (promoted) |
| Era | prototyped_auxiliary |
| Cultural/Regional | prototyped_auxiliary |
| Format/Medium | prototyped_auxiliary |
| Series Position | prototyped_auxiliary |
| Constraint | prototyped_auxiliary |
| AI-Author-Identity | prototyped_auxiliary |
| Theme/Symbolic-System | proposed |
| Translation-Awareness | proposed |
| Narrator-Reliability | proposed |
| (others) | folded/rejected |

**Integration:** every Generation Report includes a snapshot. Backward reproducibility relies on the snapshot.

📚 *profile-axis-framework-v2.md; Reading List §6*

## 24. ML Opportunity Registry ★ NEW

Tracks ML opportunities with status, training data refs, model versions, eval results.

**Data model:**
```yaml
opportunity:
  id, name, surface
  approach_tags: [REG, CLS, CLU, EMB, PROB, BAND, ANOM, SEQ, CAUS]
  current_status: enum[proposed, prototyped, in_production, retired]
  priority_tier: enum[V1, V2, V3, skip]
  scoring: {s1_value, s2_data_availability, s3_complexity, s4_reproducibility, s5_replaceability, total}
  training_data_ref
  model_versions:
    - version, trained_at, training_data_hash, eval_metrics, promoted
  decision_log: [append-only]
```

**API:** `propose_opportunity`, `update_status`, `register_model_version`, `promote_model`, `query_opportunities`, `snapshot()`.

**Cross-cutting infrastructure:** Feature Store, Model Registry, Training Pipeline, Online Inference Service, Experiment Tracker, Labeling Workflow.

**V1 state:**

| Opportunity | Status |
|-------------|--------|
| O17 — Threshold calibration regression | in_production (V1) |
| O5 — Voice drift anomaly (z-score) | in_production (V1) |
| O22 — Voice clustering | in_production (V1) |
| O23 — Comp title embedding/retrieval | in_production (V1) |
| O1 — Bayesian gap-filling priors | in_production (V1) |
| (V2 opportunities) | prototyped |
| (V3 opportunities) | proposed |

**Integration:** Generation Report snapshot. Reproducing past runs pins model versions.

📚 *ml-opportunity-analysis-v2.md*

## 25. Reading List Subsystem ★ NEW

The reading list (`reading-list.md`) is itself a managed subsystem.

**Data model:**
```yaml
entry:
  id, title, author, year, type
  url, section, status: enum[verified, unverified, disputed]
  informs_components: [list]
  annotation, added_at, added_by
```

**API:** `add_entry`, `update_status`, `query_for_component(id)`, `query_by_section(section)`.

**Integration:** every component declares `📚 informs:` pointers. New components require declaring their reading-list informs.

📚 *reading-list.md (self-referential)*

---

# PART V — COMPONENT INTERFACE CATALOG

## 26. Implementation Classes

- **Deterministic** — algorithm-based, no LLM calls.
- **LLM-driven** — model call against a prompt.
- **Hybrid** — deterministic shell + LLM for nuance.

## 27. Component Contracts (selected)

| Component | Default | Rationale | Swap to |
|-----------|---------|-----------|---------|
| Spec Validator | Deterministic | Schema-checkable | LLM nuance |
| Gap Analyzer | Deterministic | Schema diff | LLM ambiguity |
| Gap Filler | Hybrid | LLM + Bayesian priors | — |
| Voice Axis Measurement | Deterministic | Statistical | — |
| AI-Tell Detection | Deterministic | Pattern catalog | LLM novel patterns |
| Specificity Index | Deterministic | Count/ratio | LLM concept-level |
| Bible Contradiction | Hybrid | Rules + LLM | — |
| Promise Ledger | Deterministic | Deadline arithmetic | — |
| Convergence Decision | Deterministic | Threshold compare | — |
| Drafter | LLM | Generation | — |
| Critic (subjective) | LLM | Nuance | Hybrid prefilter |
| Critic (mechanical) | Deterministic | Rule-checkable | — |
| Sensitivity Critic | Hybrid | Rules + LLM | — |
| Reader | LLM | Affect simulation | — |
| Voice Extraction | Hybrid | Stats + meta | — |
| Voice Transformation | Deterministic | Vector math | — |
| Voice Drift Detection | Deterministic | Z-score baseline | ML model V2+ |
| Calibration Update | Deterministic | Regression | LLM qualitative synthesis |
| Final Polish | LLM | Generation | Deterministic perturbations |
| Publication Package | LLM | Generation | — |
| Profile Axis Registry | Deterministic | CRUD + log | — |
| ML Opportunity Registry | Deterministic | CRUD + log | — |
| Reading List Subsystem | Deterministic | CRUD | — |

---

# PART VI — VALIDATION & OPEN QUESTIONS

## 28. Validation Stack

Schema enforcement at every boundary. Failures trigger automatic retries; after N retries become FORCE-RESOLVE entries.

## 29. Open Questions

1. Threshold cold-start values.
2. Voice distance function (weighted Euclidean default; ML O20 will learn).
3. Genre profile authoring process.
4. Persistence format (YAML profiles, JSON outputs, Markdown craft, git-versioned).
5. Bible delta granularity.
6. Series continuity (out of V1 scope).
7. Multi-author profiles.
8. Voice extraction confidence per axis (ML O30).
9. Goal profile authoring.
10. Cross-genre books.
11. **Sensitivity Profile authoring without bias** — collaborative authoring with sensitivity readers; evidence-base from professional literature.
12. **Registry change governance** — promotion votes, prototype evidence threshold.
13. **Reading list verification cadence** — quarterly, prioritized by current work.
