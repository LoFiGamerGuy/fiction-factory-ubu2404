# References & Reading List

**Purpose.** Provide a curated, organized set of source materials grounding every component, axis, parameter, and concept in the autonomous book pipeline. Sources span academic scholarship, practitioner craft, computational analysis, and industry/market literature. Each entry includes a brief note on what it specifically contributes.

**Status of this document.** Living. Add sources as they're discovered or read; mark critical reads; deprecate when superseded.

**Organization.** Mirrors the ontology structure: Universal Core → Specialization Axes → Subsystems → Cross-cutting concerns. Within each section: foundational works first, then analytical/academic, then practitioner/craft, then online resources.

**Annotation legend:** ★ critical read · ◆ academic/scholarly · ◇ practitioner craft · ▣ computational/empirical · ◐ industry/market · ☉ free online

---

# PART I — UNIVERSAL CORE

## 1.1 Voice Axes (prose, style, sentence-level craft)

What we're defining: measurable parameters of authorial signature — sentence length distributions, opener entropy, lexical register, punctuation signature, cadence, etc.

### Foundational

★ ◇ **Stanley Fish, *How to Write a Sentence: And How to Read One*** (2011). The sentence as primary unit of style; close-reading approach to sentence architecture.

★ ◇ **Steven Pinker, *The Sense of Style*** (2014). Linguistically-grounded approach to prose; explicit about cognitive/grammatical underpinnings of clarity.

◇ **Verlyn Klinkenborg, *Several Short Sentences About Writing*** (2012). Argues for the sentence as primary unit; aphoristic but parameterizable.

◇ **Constance Hale, *Sin and Syntax*** (2nd ed., 2013). Grammar and rhythm intertwined; useful for cadence and sentence-mood parameters.

◇ **Francine Prose, *Reading Like a Writer*** (2007). Close-reading discipline; useful for understanding what voice axes show up in practice.

◇ **Ursula K. Le Guin, *Steering the Craft*** (1998, rev. 2015). Sentence-level exercises; explicit treatment of POV distance and rhythm.

### Analytical / Academic

◆ **Mary Oliver, *A Poetry Handbook*** (1994). Sound, rhythm, and meter; transfers directly to prose cadence parameters.

◆ **Geoffrey Pullum & Rodney Huddleston, *The Cambridge Grammar of the English Language*** (2002). Reference for parameterizing sentence-mood and structural distributions.

### Stylometry & Computational Style ▣

★ ▣ **Patrick Juola, *Authorship Attribution*** (2008). Foundational survey; parameterized approaches to identifying authors by measurable features.

▣ **John F. Burrows, "'Delta': a Measure of Stylistic Difference and a Guide to Likely Authorship"**, *Literary and Linguistic Computing*, 2002. The "Burrows' Delta" method — directly applicable as a voice-distance baseline.

▣ **Mosteller & Wallace, *Inference and Disputed Authorship: The Federalist*** (1964, rev. 2007). Foundational stylometric work.

▣ **Matthew Jockers, *Macroanalysis: Digital Methods and Literary History*** (2013). Computational analysis at scale; relevant for voice extraction at corpus level.

▣ **Hugh Craig & Arthur F. Kinney (eds.), *Shakespeare, Computers, and the Mystery of Authorship*** (2009). Case study in computational voice fingerprinting.

▣ **Franco Moretti, *Distant Reading*** (2013). Argues for computational approaches to literary analysis at scale.

### Online Resources ☉

☉ **Language Log** (languagelog.ldc.upenn.edu). Mark Liberman et al.; ongoing work on linguistic features, sentence-level analysis.

---

## 1.2 Structural Hierarchy (book / part / act / chapter / scene / beat)

What we're defining: the universal unit tree for any book, with parameters per level.

### Foundational

★ ◆ **Aristotle, *Poetics*** (~335 BCE). The original parameterization of dramatic structure (beginning/middle/end, complication/unraveling, peripeteia, anagnorisis). Read in any modern translation (Heath's Penguin or Janko's Hackett).

◆ **Vladimir Propp, *Morphology of the Folktale*** (1928, English 1968). 31 narrative functions; early structural parameterization.

◆ **Gérard Genette, *Narrative Discourse: An Essay in Method*** (1980). Foundational narratology; time, mood, voice as analytical axes.

◆ **Mieke Bal, *Narratology: Introduction to the Theory of Narrative*** (4th ed., 2017). Comprehensive narratological framework.

◆ **Seymour Chatman, *Story and Discourse: Narrative Structure in Fiction and Film*** (1978). Story vs discourse split; useful for separating bible from manuscript.

### Practitioner / Craft

◇ **Robert McKee, *Story: Substance, Structure, Style and the Principles of Screenwriting*** (1997). Despite the screenwriting frame, the structural parameterization is novel-applicable.

◇ **John Truby, *The Anatomy of Story: 22 Steps to Becoming a Master Storyteller*** (2007). 22-beat structure with explicit parameters.

◇ **Joseph Campbell, *The Hero with a Thousand Faces*** (1949). Hero's journey — used so widely it's a structural template parameter even when criticized.

◇ **Christopher Vogler, *The Writer's Journey: Mythic Structure for Writers*** (3rd ed., 2007). Operationalizes Campbell for narrative use.

◇ **Blake Snyder, *Save the Cat!*** (2005) and **Jessica Brody, *Save the Cat! Writes a Novel*** (2018). 15-beat structural template; widely adopted as a genre baseline especially in romance/commercial fiction.

◇ **K.M. Weiland, *Structuring Your Novel*** (2013). Practical structural craft; multiple template comparisons.

◇ **Larry Brooks, *Story Engineering*** (2011). Systematic approach to structural parameters.

◇ **Lajos Egri, *The Art of Dramatic Writing*** (1946). Premise-driven structure; foundational craft text.

◇ **Jane Alison, *Meander, Spiral, Explode: Design and Pattern in Narrative*** (2019). Critical of standard arc; alternative structural patterns essential for literary/experimental goals.

### Online ☉

☉ **K.M. Weiland's *Helping Writers Become Authors*** (helpingwritersbecomeauthors.com). Extensive structural breakdowns.

---

## 1.3 Continuity Model (bible, characters, world)

What we're defining: canonical truth model for any book — entities, relationships, timeline, taboos.

### Foundational

★ ◇ **E.M. Forster, *Aspects of the Novel*** (1927). Round vs flat characters; foundational character parameterization.

◆ **Mikhail Bakhtin, *The Dialogic Imagination*** (1981, essays from 1930s). Polyphony of voices, chronotope (time-space integration); useful for multi-POV continuity and timeline.

◇ **John Gardner, *The Art of Fiction*** (1984). Vivid characterization; continuity through detail consistency.

### Practitioner

◇ **Patricia C. Wrede, "Fantasy Worldbuilding Questions"** (essay, widely circulated). Structured questions for building consistent worlds; directly applicable as bible-seeding template.

◇ **Holly Lisle, "Create-A-Character Clinic"** and other craft materials at hollylisle.com. Practical character-bible approaches.

◇ **Brandon Sanderson, "Sanderson's Laws of Magic"** (writing essays, sandersonia.com / archives). Magic systems as continuity rules with promise-payoff.

◇ **Ursula K. Le Guin, *The Language of the Night*** (1979) and *Words Are My Matter* (2016). Worldbuilding as cultural anthropology; high-fidelity continuity.

### TV Writing — Series Bible Practice

◇ **Pamela Douglas, *Writing the TV Drama Series*** (3rd ed., 2011). Bible practice from television; transfers to series novels.

◇ Various **showrunner bibles** that have leaked publicly (Battlestar Galactica, The Wire, Lost). Examples of continuity-management discipline.

---

## 1.4 Promise Ledger (foreshadowing, payoff, Chekhov's gun)

What we're defining: the contract between book and reader — every promise opened must be closed (or deliberately subverted) by deadline.

### Foundational

★ ◆ **Gérard Genette, *Narrative Discourse*** — section on prolepsis and analepsis. Formal treatment of narrative time and promise structure.

### Practitioner

★ ◇ **Brandon Sanderson, "Three Laws of Magic"** and **"Promise/Progress/Payoff"** lectures (free on YouTube; BYU Eng 318R lectures). Sanderson's framework is the most parameterized treatment of promise discipline in modern craft writing.

◇ **John Truby, *The Anatomy of Story*** — "moral argument" and "ghost" sections. Long-arc payoff structure.

◇ **James Scott Bell, *Plot & Structure*** (2004) and *Conflict & Suspense* (2011). Setup/payoff at scene level.

◇ **Sol Stein, *Stein on Writing*** (1995). Tension and release mechanics.

---

## 1.5 AI-Tell Catalog (LLM detection patterns)

What we're defining: the genre-agnostic catalog of patterns that mark prose as LLM-generated.

### Recent (the field is young)

▣ **Various papers on AI text detection** — see arxiv.org/list/cs.CL/recent for ongoing work. Specific recent: Gehrmann et al., "GLTR: Statistical Detection and Visualization of Generated Text" (2019); Mitchell et al., "DetectGPT" (2023).

▣ **Janelle Shane's blog, AI Weirdness** (aiweirdness.com). Practitioner observations of recurring AI output patterns; useful for catalog seeding.

▣ **Various BookTok / writing community posts** identifying AI-tells. Ephemeral but valuable as ground-truth on what readers detect.

### Adjacent (corpus comparison)

▣ **Andrew Piper, *Enumerations: Data and Literary Study*** (2018). Computational methods for corpus comparison; transferable to AI vs human prose discrimination.

---

## 1.6 Specificity Heuristics (concrete vs abstract, sensory anchoring)

What we're defining: quantifiable measures of concrete, sensory, culturally-anchored detail vs abstract/generic prose.

### Foundational

★ ◇ **John Gardner, *The Art of Fiction*** (1984). "The vivid and continuous fictive dream" — articulates why specificity matters.

★ ◇ **Janet Burroway, *Writing Fiction: A Guide to Narrative Craft*** (10th ed., 2019). Sensory detail and concrete imagery as foundational craft.

◇ **Rebecca McClanahan, *Word Painting: The Fine Art of Writing Descriptively*** (rev. 2014). Detailed treatment of sensory specificity.

◇ **Peter Turchi, *Maps of the Imagination: The Writer as Cartographer*** (2007). Spatial specificity in prose.

### Cognitive / Linguistic

◆ **Mark Turner, *The Literary Mind*** (1996). Cognitive basis for why concrete imagery matters in narrative.

◆ **George Lakoff & Mark Johnson, *Metaphors We Live By*** (1980). Embodied cognition; useful for understanding why sensory specificity registers as "real."

### Exemplar texts (for measurement, not stylistic copying)

◇ **Patrick Süskind, *Perfume*** (1985). Exemplar of olfactory specificity at extreme density.

◇ **Annie Dillard, *Pilgrim at Tinker Creek*** (1974). Exemplar of visual/natural specificity.

---

# PART II — SPECIALIZATION AXES

## 2.1 Genre Profile

What we're defining: structural conventions, intensity scales, trope libraries, reader contracts per genre.

### Foundational Genre Theory ◆

★ ◆ **John Frow, *Genre*** (Routledge New Critical Idiom, 2nd ed., 2014). The current best general treatment of genre theory.

◆ **Tzvetan Todorov, *The Fantastic: A Structural Approach to a Literary Genre*** (1970, English 1973). Foundational structural treatment of genre boundaries.

◆ **Northrop Frye, *Anatomy of Criticism*** (1957). Foundational schematic; mythoi and modes.

◆ **John G. Cawelti, *Adventure, Mystery, and Romance: Formula Stories as Art and Popular Culture*** (1976). Formula stories analyzed as genre conventions.

◆ **Heather Dubrow, *Genre*** (Critical Idiom series, 1982). Brief but thorough academic intro.

### Genre-Specific

**Romance:**
- ◆ **Pamela Regis, *A Natural History of the Romance Novel*** (2003). Eight essential elements; the canonical structural analysis.
- ◆ **Janice Radway, *Reading the Romance: Women, Patriarchy, and Popular Literature*** (1984, rev. 1991). Ethnographic study of romance readers.
- ◇ **Sarah MacLean's craft essays** at sarahmaclean.net. Practitioner-analyst on romance conventions.
- ☉ **RWA (Romance Writers of America)** materials and Smart Bitches Trashy Books archive (smartbitchestrashybooks.com).

**Mystery / Detective:**
- ◇ **P.D. James, *Talking About Detective Fiction*** (2009). Practitioner-analyst on the form.
- ◆ **Carolyn Heilbrun, *Sweet Death, Kind Death*** essays. Mystery genre analysis.
- ◇ **John Dickson Carr, "The Grandest Game in the World"** (essay, 1963). Locked-room mystery conventions.

**Science Fiction:**
- ◆ **Darko Suvin, *Metamorphoses of Science Fiction*** (1979). Cognitive estrangement; foundational SF theory.
- ◇ **Damon Knight, *In Search of Wonder*** (1956, rev. 1996). Practitioner-critic essays.
- ◇ **Ursula K. Le Guin, essays in *The Language of the Night*** and *Words Are My Matter*. SF as a literature of ideas.

**Fantasy:**
- ◆ **Brian Attebery, *Strategies of Fantasy*** (1992). Fuzzy-set genre theory applied to fantasy.
- ◇ **Tolkien, "On Fairy-Stories"** (1947 essay, in *Tree and Leaf*). Foundational reflection by a foundational author.

**Horror:**
- ◇ **Stephen King, *Danse Macabre*** (1981). Practitioner survey of the form.
- ◆ **Noël Carroll, *The Philosophy of Horror, or Paradoxes of the Heart*** (1990). Analytical philosophy of horror.

**Thriller:**
- ◇ **David Morrell, *The Successful Novelist*** (2008). Practitioner on thriller mechanics.
- ◇ **Lee Child, various interviews and essays** on thriller pacing.

**Literary:**
- ◇ **James Wood, *How Fiction Works*** (2008). Critical close-reading; voice and free indirect discourse.
- ◇ **Milan Kundera, *The Art of the Novel*** (1986). Practitioner on the literary novel.

### Genre Markets ◐

◐ **Publishers Weekly** (publishersweekly.com); **Publishers Marketplace** (publishersmarketplace.com). Industry data on genre boundaries and trends.

◐ **The Hot Sheet** by Jane Friedman & Porter Anderson. Market intelligence on publishing.

---

## 2.2 Audience Profile

What we're defining: reader expectations, tolerances, triggers, lenses.

### Reader-Response Theory ◆

★ ◆ **Wolfgang Iser, *The Implied Reader*** (1974) and *The Act of Reading* (1978). Foundational reader-response theory.

◆ **Stanley Fish, *Is There a Text in This Class? The Authority of Interpretive Communities*** (1980). Interpretive communities as audience clusters.

◆ **Hans Robert Jauss, *Toward an Aesthetic of Reception*** (1982). Horizon of expectations; foundational reception theory.

◆ **Norman Holland, *5 Readers Reading*** (1975). Empirical reader-response study.

### Cognitive / Empirical

◆ **Lisa Zunshine, *Why We Read Fiction: Theory of Mind and the Novel*** (2006). Cognitive basis for reader engagement.

◆ **Keith Oatley, *Such Stuff as Dreams: The Psychology of Fiction*** (2011). Empirical psychology of reading.

### Ethnographic / Sociological

★ ◆ **Janice Radway, *Reading the Romance*** (1984). Interview-based study of romance readers; methodologically applicable to other genres.

◆ **Wendy Griswold, *Bearing Witness: Readers, Writers, and the Novel in Nigeria*** (2000). Sociology of reading.

### Online

☉ **Goodreads reviews / Amazon reviews** as primary data (meta-text only, per data ingestion policy).

☉ **Reddit subs**: r/romance, r/Fantasy, r/horrorlit, r/literature, etc. Reader discourse on expectations and DNF triggers.

☉ **BookTok / BookTube** content. Ephemeral but rich source of reader reactions.

---

## 2.3 Author Profile (Voice)

See §1.1 (Voice Axes) for foundational voice references. This section adds author-as-signature material.

### Foundational

★ ◇ **George Saunders, *A Swim in a Pond in the Rain: In Which Four Russians Give a Master Class on Writing, Reading, and Life*** (2021). Close analysis of voice in Chekhov, Turgenev, Tolstoy, Gogol.

◇ **John Gardner, *On Becoming a Novelist*** (1983) and *The Art of Fiction* (1984). Authorial voice as cultivated identity.

◇ **Annie Dillard, *Living by Fiction*** (1982) and *The Writing Life* (1989). Voice as world-stance.

### Style and Identity

◇ **Strunk & White, *The Elements of Style*** (4th ed., 2000). Use with caveats — many of its rules are overstated, but it's foundational shared reference.

◇ **William Zinsser, *On Writing Well*** (30th anniv. ed., 2006). Plain-style nonfiction, but voice principles transfer.

◆ **Jonathan Culler, *Literary Theory: A Very Short Introduction*** (2nd ed., 2011). Useful overview for situating "voice" in critical theory.

### Practitioner Reflections

◇ **Toni Morrison, *The Source of Self-Regard*** (2019). Essays on voice and authorship.

◇ **David Foster Wallace, *A Supposedly Fun Thing I'll Never Do Again*** (1997) — particularly the title essay and the essays on television and irony. Voice as cultural diagnostic.

◇ **Ursula K. Le Guin, *Steering the Craft*** (rev. 2015). Author voice exercises.

◇ **Cormac McCarthy interviews** (rare; see archive at Vanity Fair, NYT). Distinctive voice as deliberate craft.

---

## 2.4 Goal Profile

What we're defining: intent-driven conflict resolution and convergence weighting per book purpose.

### Publishing Economics ◐

★ ◆ **Pierre Bourdieu, *The Field of Cultural Production*** (1993). Literary economy and consecration; useful theoretical frame for goal-driven distinctions.

◐ **John B. Thompson, *Merchants of Culture: The Publishing Business in the Twenty-First Century*** (2nd ed., 2012). Industry structure.

### Self-Publishing / Indie

◐ **Joanna Penn, *The Successful Author Mindset*** and other titles at thecreativepenn.com. Practitioner-business advice.

◐ **Kristine Kathryn Rusch, "Business Musings"** (kriswrites.com — long-running blog series). Indie publishing economics, contracts, careers.

◐ **Jane Friedman, *The Business of Being a Writer*** (2018). Comprehensive business overview.

◐ **David Gaughran, *Strangers to Superfans*** (2018). Reader-acquisition framework; useful for "high revenue KDP" goal profile parameters.

### Serial / Patreon Economics

☉ **Royal Road**, **Wattpad**, **Webnovel** community resources on serial conventions. Rapidly evolving; check current state.

☉ **Patreon Author Resources**. Creator-side economics.

### Literary / Award Goals

◆ **James English, *The Economy of Prestige: Prizes, Awards, and the Circulation of Cultural Value*** (2005). Award/prestige economy.

◇ Various **shortlist analyses** (Booker, Pulitzer, NBA) — published in Granta, LRB, etc.

### Educational / Pedagogical

◇ **Various textbook authoring guides** from Pearson, Cengage author guidelines. Pedagogical structure conventions.

---

## 2.5 Sensitivity Profile (NEW PRIMARY AXIS)

What we're defining: content sensitivity policies, depiction guidelines, trigger handling, age-appropriateness.

### Foundational

◇ **Nisi Shawl & Cynthia Ward, *Writing the Other: A Practical Approach*** (2005, with online course). Foundational craft text for cross-cultural depiction.

◇ **Patrice Williams Marks, *The Sensitivity Reader Handbook*** and related materials. Practitioner-side sensitivity reading.

### Industry

◐ **ALA's Office for Intellectual Freedom** materials (ala.org/advocacy/intfreedom). Intellectual freedom side; useful counterweight.

◐ **Various publisher sensitivity guidelines** (publicly available; Penguin Random House, Scholastic, etc., have published portions).

### Trauma-Informed

◆ **Bessel van der Kolk, *The Body Keeps the Score*** (2014). Trauma neuroscience; foundational for understanding reader trauma responses.

◇ **Jamie Marich, *Trauma and the 12 Steps*** (rev. 2020). Trauma-informed practice; transferable principles.

### Content Rating Systems

◐ **MPAA, ESRB, IARC** rating frameworks (various sites). Content classification frameworks.

◐ **Bookishly's content warning labels** and similar reader-side content classification sites. Reader-driven taxonomy.

### Age-Appropriateness

◐ **SCBWI (Society of Children's Book Writers and Illustrators)** resources on age-grade conventions.

◐ **Common Sense Media** ratings rationale (commonsensemedia.org). How content is classified by age.

### Difficult Content Specifically

◇ **Various craft essays** on writing violence, sex, and other sensitive content — search Writer's Digest, Lithub archives. Practitioner-level treatment.

---

# PART III — AUXILIARY AND CANDIDATE AXES

## 3.1 Era / Period Profile (production-era voice norms)

◆ **John Brewer, *The Pleasures of the Imagination: English Culture in the Eighteenth Century*** (1997). Period-cultural context.

▣ **Matthew Jockers, *Macroanalysis*** — corpus analysis across historical periods.

◇ **Various "year-in-prose" essays** in LRB, Lithub, etc. Practitioner observation of period drift.

---

## 3.2 Cultural / Regional Profile (market-specific conventions)

◆ **Pascale Casanova, *The World Republic of Letters*** (English 2004). Translational and cultural circulation of literature.

◆ **Rebecca Walkowitz, *Born Translated: The Contemporary Novel in an Age of World Literature*** (2015). Writing for translation.

◐ Country/regional **publisher style guides** (publicly available; various). UK vs US vs ANZ conventions.

---

## 3.3 Format / Medium Profile

### Ebook / Print

◐ **Smashwords Style Guide** (smashwords.com — free). Detailed ebook formatting conventions.

◐ **KDP Help** (kdp.amazon.com/help). Format conventions for Kindle.

### Audiobook

◐ **ACX guidance** (acx.com) and **APA (Audio Publishers Association)** materials. Audiobook conventions.

◇ **Karen Commins's blog** (karencommins.com). Audiobook narration craft and conventions.

### Serial / Web Fiction

☉ **Royal Road, Wattpad, Webnovel** craft resources (community-authored). Serial conventions.

☉ **Worm**, **Mother of Learning**, and other notable web serials — examples of long-form serial structure.

### Interactive Fiction

☉ **Choice of Games style guide** (choiceofgames.com/make-your-own-games). Interactive narrative conventions.

◇ **Emily Short's blog** (emshort.blog). Foundational IF craft writing.

---

## 3.4 Series Position Profile

### Practitioner

◇ **Various craft essays from working series authors** — Sanderson, Lynch, Jemisin have all written on series planning.

◇ **Robert Jordan / Brandon Sanderson conversations on completing Wheel of Time**. Series-finale challenges in practice.

### TV Series Bibles (analogous problem)

◇ **Pamela Douglas, *Writing the TV Drama Series*** (3rd ed., 2011). Series-bible discipline.

◇ **Various leaked showrunner bibles** (Battlestar Galactica, Fargo, etc.). Reference examples.

---

## 3.5 Theme / Symbolic-System Profile

◆ **Northrop Frye, *Anatomy of Criticism*** (1957). Archetypal symbolic systems.

◆ **Carl Jung, *The Archetypes and the Collective Unconscious*** (1959, English 1969). Foundational symbolic system source (use with academic caution).

◇ **Joseph Campbell, *The Power of Myth*** (1988). Conversational treatment of symbolic systems.

◇ **John Truby, *The Anatomy of Genre*** (2022). Genre-specific thematic structures.

---

# PART IV — SUBSYSTEMS

## 4.1 Voice Extraction Pipeline

See §1.1 stylometry references. Specifically:

★ ▣ **John F. Burrows, "Delta" papers** — directly applicable as extraction baseline.

▣ **Maciej Eder, Jan Rybicki, Mike Kestemont — *Stylometry with R*** (2016, R package and papers). Practical stylometric toolkit.

▣ **Patrick Juola, *Authorship Attribution*** — comprehensive methods.

---

## 4.2 Spec Intake Pipeline (gap-filling)

### Bayesian Methods

◆ **Andrew Gelman et al., *Bayesian Data Analysis*** (3rd ed., 2013). Foundational Bayesian methods for prior-based gap filling.

◆ **Kevin Murphy, *Probabilistic Machine Learning: An Introduction*** (2022). Modern probabilistic ML reference.

### Conversational Spec Elicitation

◆ Various **HCI and requirements engineering** papers on partial specification handling. Search ACM CHI proceedings.

---

## 4.3 Convergence Controller

### Decision Theory

◆ **Michael Trick, "An Introduction to Decision Theory"** (in various textbooks). Threshold-based decision rules.

### Multi-Criteria Optimization

◆ **Kaisa Miettinen, *Nonlinear Multiobjective Optimization*** (1999). Multi-criteria evaluation; relevant to weighted critic/reader aggregation.

---

## 4.4 Calibration Subsystem

### Bayesian Calibration

◆ **Marc Kennedy & Anthony O'Hagan, "Bayesian Calibration of Computer Models"**, *Journal of the Royal Statistical Society*, 2001. Foundational Bayesian calibration methods.

### Online Learning / Bandits

◆ **Tor Lattimore & Csaba Szepesvári, *Bandit Algorithms*** (2020, free at tor-lattimore.com/downloads/book/book.pdf). Foundational bandit theory; relevant to critic/reader weight learning.

### Active Learning

◆ **Burr Settles, *Active Learning*** (Morgan & Claypool, 2012). Sample-efficient labeling for calibration.

---

## 4.5 Final Polish Layer (de-AI-ification)

### AI Detection

▣ **Various recent papers on AI text detection** (Mitchell et al.'s "DetectGPT", Su et al.'s "DetectLLM", etc.). The detector side informs the obfuscation side.

### Style Transfer / Perturbation

▣ **Various NLP papers on style transfer** — search ACL, EMNLP recent proceedings.

### Practitioner

☉ **Various BookTok / writing community discussions** on AI-tells in published prose. Ephemeral but current.

---

## 4.6 Publication Package Generator

### Cover Design

◐ **The Book Cover Designer (thebookcoverdesigner.com)**. Industry pricing and conventions.

◐ **Joel Friedlander's *The Book Designer*** archives (thebookdesigner.com). Cover and book design craft.

### Blurb / Marketing Copy

◐ **Bryan Cohen, *How to Write a Sizzling Synopsis*** (2016). KDP-focused blurb craft.

◐ **Libbie Hawker, *Gotta Read It! Five Simple Steps to a Fiction Pitch That Sells*** (2014). Pitch and blurb craft.

### KDP Categories / Keywords

◐ **Dave Chesson, Kindlepreneur (kindlepreneur.com)**. KDP optimization.

◐ **K-lytics reports** (k-lytics.com). Genre/category analysis for KDP.

---

# PART V — COMPUTATIONAL & ML

## 5.1 NLP Foundations

★ ◆ **Daniel Jurafsky & James H. Martin, *Speech and Language Processing*** (3rd ed. draft online at web.stanford.edu/~jurafsky/slp3). The standard reference.

◆ **Yoav Goldberg, *Neural Network Methods for Natural Language Processing*** (2017). Neural NLP foundations.

---

## 5.2 ML Fundamentals

★ ◆ **Kevin Murphy, *Probabilistic Machine Learning*** (2 vols., 2022–2023). Comprehensive modern ML.

◆ **Christopher Bishop, *Pattern Recognition and Machine Learning*** (2006). Foundational reference.

◆ **Trevor Hastie, Robert Tibshirani, Jerome Friedman, *The Elements of Statistical Learning*** (2nd ed., 2009; free at hastie.su.domains/ElemStatLearn). Classical ML reference.

---

## 5.3 Computational Literary Studies

★ ▣ **Matthew Jockers, *Macroanalysis: Digital Methods and Literary History*** (2013). Foundational computational literary analysis.

▣ **Stephen Ramsay, *Reading Machines: Toward an Algorithmic Criticism*** (2011). Methodological argument for computational literary analysis.

▣ **Andrew Piper, *Enumerations: Data and Literary Study*** (2018). Quantitative methods applied to literary corpora.

▣ **Ted Underwood, *Distant Horizons: Digital Evidence and Literary Change*** (2019). Long-arc literary trends via computation.

---

## 5.4 Generative Models / LLMs

▣ **Ashish Vaswani et al., "Attention Is All You Need"** (2017). Transformer foundation.

▣ **Various recent papers on LLM evaluation, RLHF, alignment** — search arXiv cs.CL.

▣ **Ethan Mollick, *Co-Intelligence: Living and Working with AI*** (2024). Practical framework for AI collaboration.

---

# PART VI — META / CROSS-CUTTING

## 6.1 Narrative Theory (general)

★ ◆ **Gérard Genette, *Narrative Discourse*** (1980). Foundational narratology.

◆ **Mieke Bal, *Narratology*** (4th ed., 2017). Comprehensive intro.

◆ **Wayne Booth, *The Rhetoric of Fiction*** (1961, rev. 1983). Implied author, reliable/unreliable narrator.

◆ **Roland Barthes, "Introduction to the Structural Analysis of Narratives"** (1966) and *S/Z* (1970). Structuralist narratology.

---

## 6.2 Cognitive Narrative

◆ **Lisa Cron, *Wired for Story*** (2012). Neuroscience of narrative engagement; practitioner-accessible.

◆ **Brian Boyd, *On the Origin of Stories: Evolution, Cognition, and Fiction*** (2009). Evolutionary basis for narrative.

◆ **Jonathan Gottschall, *The Storytelling Animal*** (2012). Cognitive science of stories.

---

## 6.3 Writing Process / Method

◇ **Stephen King, *On Writing: A Memoir of the Craft*** (2000). Practitioner perspective; useful for general process even if not parameterized.

◇ **Anne Lamott, *Bird by Bird*** (1994). Process and revision discipline.

◇ **Annie Dillard, *The Writing Life*** (1989). Writing as practice.

◇ **Natalie Goldberg, *Writing Down the Bones*** (1986). Generative practice.

---

## 6.4 Co-Authorship with AI / Synthetic Authorship

▣ **K Allado-McDowell, *Pharmako-AI*** (2020). Practitioner-experimental AI co-writing.

▣ **Janelle Shane, *You Look Like a Thing and I Love You*** (2019). AI capabilities and limits in generative work.

▣ **Various recent academic papers on AI authorship and authorial identity** — search arXiv, MLA convention papers.

▣ **Mollick (op. cit.) — *Co-Intelligence*** — primary current framework for human-AI collaboration.

---

## 6.5 Publishing Business / Industry

◐ **Jane Friedman's blog** (janefriedman.com). Authoritative industry intelligence.

◐ **Publishers Weekly, Publishers Lunch / Marketplace, The Bookseller (UK)**. Trade publications.

◐ **Joanna Penn, *Successful Self-Publishing*** (2019, free updates). Practitioner guide.

◐ **Kristine Kathryn Rusch's "Business Musings"** archives.

---

# PART VII — RECOMMENDED READING SEQUENCE

If starting from scratch, this is a sensible reading order to ground the architecture work:

**Week 1 — Foundations:**
1. Pinker, *The Sense of Style* (voice/prose)
2. McKee, *Story* (structure)
3. Frow, *Genre* (genre theory)

**Week 2 — Computational:**
4. Juola, *Authorship Attribution* (stylometry)
5. Jurafsky & Martin chapters on NLP fundamentals
6. Jockers, *Macroanalysis* (computational literary studies)

**Week 3 — Genre depth (pick 2 in your target genres):**
7. Regis, *Natural History of the Romance Novel* (if doing romance)
8. James, *Talking About Detective Fiction* (if doing mystery)
9. Suvin, *Metamorphoses of Science Fiction* (if doing SF)
10. King, *Danse Macabre* (if doing horror)

**Week 4 — Reader/Audience:**
11. Iser, *The Implied Reader* OR Fish, *Is There a Text in This Class?*
12. Radway, *Reading the Romance* (methodologically transferable)

**Week 5 — Craft depth:**
13. Saunders, *A Swim in a Pond in the Rain* (close-reading discipline)
14. Sanderson's Promise/Progress/Payoff lectures (free, YouTube)
15. Maass, *The Emotional Craft of Fiction*

**Ongoing:**
- Janelle Shane (AI tells)
- Friedman / Penn / Rusch (industry)
- Lithub / LRB / NYRB for ongoing critical context

---

# Appendix A — Annotation Tracking

For each source actually read, maintain notes on:
- What this contributes to the architecture
- Specific parameters or definitions extracted
- Conflicts with other sources
- Cross-references to ontology entries
- Status: read / skimmed / referenced / superseded

This metadata feeds back into the ontology as evidence supporting parameter choices.

---

# Appendix B — Open Source Corpus Notes

Per the data ingestion policy, **prose is never persisted** even from public-domain or open sources. However, the following corpora are valuable for **structural and metadata extraction** (in-memory analysis, then discarded):

- **Project Gutenberg** (gutenberg.org). Out-of-copyright texts; structural-analysis use only.
- **Standard Ebooks** (standardebooks.org). Curated public-domain editions.
- **HathiTrust** (hathitrust.org). Large-scale digitized text.
- **Open Library** (openlibrary.org). Metadata, some full-text.

For **review and reception data** (fully usable as meta-text):

- **Goodreads, Amazon, BookBub** review streams.
- **Reddit** book communities.
- **Academic review databases** (JSTOR, Project MUSE) for analytical reviews.
- **Trade reviews** (PW, Kirkus, Booklist) — partial paywall.

For **genre/craft meta-discussion** (fully usable):

- **Lithub, LRB, NYRB, Granta** for literary discussion.
- **Genre-specific publications** (Locus for SF/F, Mystery Scene, RT Book Reviews — or successors).
- **Author interview archives** (Paris Review's "The Art of Fiction" series; bombmagazine.org; etc.).
