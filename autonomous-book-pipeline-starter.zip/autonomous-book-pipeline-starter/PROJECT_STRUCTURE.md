# Project Structure

Proposed directory layout for the implementation. This is recommendation, not gospel — adjust as the implementation reveals better organization, but log significant deviations to `DECISIONS.md`.

```
autonomous-book-pipeline/
│
├── README.md                          # Project entry
├── CLAUDE.md                          # Agent briefing (do not modify casually)
├── QUICK_REFERENCE.md                 # Cheat sheet
├── IMPLEMENTATION_PLAN.md             # Phased plan with status header
├── DECISIONS.md                       # Append-only architectural decisions
├── PROJECT_STRUCTURE.md               # This file
│
├── pyproject.toml                     # Python project + dependencies
├── Makefile                           # Common commands
├── .env.example                       # Required env vars (Anthropic key, etc.)
├── .pre-commit-config.yaml            # Lint/format/typecheck hooks
├── ruff.toml                          # Lint config
├── mypy.ini                           # Type-check config
│
├── docs/                              # Architecture documents (read-only)
│   ├── core-ontology-v3.md
│   ├── profile-axis-framework-v2.md
│   ├── ml-opportunity-analysis-v2.md
│   ├── references-reading-list.md
│   └── architecture-overview-aesthetic.html
│
├── diagrams/                          # Architecture diagrams
│   ├── architecture-overview-aesthetic.html
│   └── autonomous-book-pipeline-v5.mermaid
│
├── tasks/                             # Concrete task definitions
│   ├── README.md
│   ├── task-001-foundation.md
│   ├── task-002-universal-core-schemas.md
│   └── task-003-first-profiles.md
│
├── runbooks/                          # Phase-specific guidance
│   └── README.md
│
├── schemas/                           # Schema definitions (JSON Schema)
│   ├── universal/                     # Universal Core schemas
│   │   ├── voice_axes.schema.json
│   │   ├── structural_hierarchy.schema.json
│   │   ├── continuity_model.schema.json
│   │   ├── promise_ledger.schema.json
│   │   ├── ai_tell_catalog.schema.json
│   │   ├── specificity_heuristics.schema.json
│   │   └── convergence.schema.json
│   ├── profiles/                      # Profile schemas
│   │   ├── author_profile.schema.json
│   │   ├── genre_profile.schema.json
│   │   ├── audience_profile.schema.json
│   │   ├── goal_profile.schema.json
│   │   ├── sensitivity_profile.schema.json
│   │   └── project_spec.schema.json
│   └── components/                    # Component contract schemas
│       ├── critic_output.schema.json
│       ├── reader_output.schema.json
│       └── ...
│
├── profiles/                          # Authored profile data (YAML)
│   ├── authors/
│   │   └── synth_v1.yaml
│   ├── genres/
│   │   └── contemporary_romance_us.yaml
│   ├── audiences/
│   │   └── kdp_romance_reader.yaml
│   ├── goals/
│   │   ├── kdp_high_revenue.yaml
│   │   ├── personal_vanity.yaml
│   │   └── literary_award_target.yaml
│   ├── sensitivity/
│   │   ├── clean.yaml
│   │   ├── mainstream.yaml
│   │   └── unrestricted.yaml
│   ├── critics/                       # Critic personas + rubrics
│   │   └── ...
│   └── readers/                       # Reader personas
│       └── ...
│
├── craft/                             # Craft Store (universal craft knowledge)
│   ├── ai_tell_catalog.md
│   ├── specificity_heuristics.md
│   ├── voice_anatomy.md
│   └── patterns/
│       └── ...
│
├── projects/                          # Per-book working state
│   └── <book_id>/
│       ├── project_spec.yaml
│       ├── bible.yaml
│       ├── promise_ledger.yaml
│       ├── manuscript/
│       │   ├── chapter_01.md
│       │   ├── chapter_02.md
│       │   └── ...
│       ├── decision_log.yaml
│       ├── issue_report.yaml
│       └── runs/
│           └── <run_id>/
│               ├── metadata.yaml      # seed, model versions, profile versions, registry snapshot
│               ├── critic_outputs/
│               ├── reader_outputs/
│               └── generation_report.html
│
├── pipeline/                          # The implementation
│   ├── __init__.py
│   ├── schemas/                       # Pydantic models (generated from schemas/)
│   ├── intake/                        # Spec Intake Pipeline
│   │   ├── parser.py
│   │   ├── gap_analyzer.py
│   │   ├── gap_filler.py
│   │   ├── clarification.py
│   │   └── validator.py
│   ├── knowledge/                     # Knowledge API
│   │   ├── api.py
│   │   ├── resolver.py
│   │   └── cache.py
│   ├── orchestration/                 # Generation Loop
│   │   ├── planner.py
│   │   ├── composer.py
│   │   └── convergence.py
│   ├── agents/                        # LLM-backed agents
│   │   ├── drafter.py
│   │   ├── critic.py
│   │   └── reader.py
│   ├── critics/                       # Critic implementations
│   │   ├── universal/
│   │   │   ├── craft.py
│   │   │   ├── ai_tell.py
│   │   │   ├── specificity.py
│   │   │   └── ...
│   │   └── genre_specific/
│   ├── readers/                       # Reader implementations
│   ├── guardians/                     # Continuity Guardians
│   │   ├── bible_steward.py
│   │   └── loop_tracker.py
│   ├── voice_extraction/              # Offline voice extraction
│   │   ├── tokenize.py
│   │   ├── measure.py
│   │   ├── transform.py
│   │   └── discard.py
│   ├── calibration/                   # Calibration Subsystem
│   │   ├── data_store.py
│   │   ├── regression.py
│   │   └── trigger.py
│   ├── registries/                    # Three registries
│   │   ├── profile_axis.py
│   │   ├── ml_opportunity.py
│   │   └── references.py
│   ├── output/                        # Finalization + Output
│   │   ├── polish.py
│   │   ├── manuscript_pass.py
│   │   ├── publication_package.py
│   │   └── report.py
│   ├── ml/                            # ML components (V1+)
│   │   ├── voice_clustering.py
│   │   ├── comp_embedding.py
│   │   ├── gap_priors.py
│   │   ├── drift_detection.py
│   │   └── threshold_calibration.py
│   └── cli.py                         # CLI entry point
│
├── tests/                             # Pytest suites
│   ├── conftest.py
│   ├── unit/
│   ├── integration/
│   └── fixtures/
│
├── scripts/                           # Operational scripts
│   ├── validate_schemas.py
│   ├── run_pipeline.py
│   ├── recalibrate.py
│   └── extract_voice.py
│
└── data/                              # Calibration & ML data
    ├── calibration.db                 # SQLite
    ├── feature_store/
    └── models/                        # Versioned ML model artifacts
```

## Key conventions

**`profiles/` vs `pipeline/profiles/`** — `profiles/` holds *authored data* (YAML you edit). `pipeline/schemas/` holds *generated pydantic models* you don't edit.

**`projects/<book_id>/`** — Each book gets its own subdirectory. State accumulates here. Manuscript and bible are versioned within. Runs are append-only subdirectories.

**`docs/` is read-only** — Architecture documents are versioned with the codebase. Don't modify casually. New decisions go to `DECISIONS.md`. New axes go through the registry.

**`craft/` is human-curated knowledge** — Markdown. Edit freely. References are tracked but lifecycle is gentle compared to schemas.

**`data/` is generated** — Never check raw calibration data into git. Use `.gitignore` for `data/calibration.db` and the feature store. Versioned model artifacts may be checked in or stored externally depending on size.

## What goes in `pyproject.toml` (V1 dependencies)

```toml
[project]
dependencies = [
    "anthropic >= 0.40.0",
    "pydantic >= 2.0",
    "pyyaml >= 6.0",
    "jsonschema >= 4.0",
    "datamodel-code-generator >= 0.25",
    "scikit-learn >= 1.3",
    "scipy >= 1.10",
    "sentence-transformers >= 2.5",
    "numpy >= 1.24",
]

[project.optional-dependencies]
dev = [
    "pytest >= 7.0",
    "pytest-cov >= 4.0",
    "mypy >= 1.7",
    "ruff >= 0.5",
    "pre-commit >= 3.0",
]
```

Add dependencies as phases require. Document each new dependency addition in DECISIONS.md.

## What goes in `.gitignore`

```
# Python
__pycache__/
*.pyc
.venv/
.env

# Generated
pipeline/schemas/_generated/

# Data
data/calibration.db
data/feature_store/
projects/*/runs/*/critic_outputs/
projects/*/runs/*/reader_outputs/

# IDE
.vscode/
.idea/

# OS
.DS_Store
```
