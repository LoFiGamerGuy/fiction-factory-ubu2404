# Quick Reference

A single-page cheat sheet. Print and keep open.

## The system in one sentence

A profile-composed, schema-validated, fully autonomous pipeline that takes a book specification and produces a publishable manuscript with output bundle.

## The pentad (V1 primary axes)

```
  Author × Genre × Audience × Goal × Sensitivity
  ─────────────────────────────────────────────
  voice    convention  reception  intent   policy
```

Plus: Universal Core (foundations) underneath, Project Spec (per-book) on top.

## Conflict precedence (default)

```
Constraint > Sensitivity > Goal > Genre > Audience > Author > Universal
```

Goal Profile defines per-axis precedence rules that may override this default.

## The four convergence actions

| Action | When | Effect |
|---|---|---|
| GO | All thresholds passed | Commit unit, advance |
| REVISE | Soft thresholds failed, budget remains | Re-draft same plan |
| RE-PLAN | Hard fail (bible contradiction, must-have absent, sensitivity violation, taboo) | New plan |
| FORCE-RESOLVE | Revise budget exhausted on soft fails | Pick best candidate, log compromise, advance |

The Convergence Controller never halts. It always finds a forward path.

## Component implementation classes

| Class | When to use | Examples |
|---|---|---|
| Deterministic | Rules suffice | Specificity index, AI-tell pattern detection, schema validation |
| LLM | Generation or nuanced judgment | Drafter, theme critic, gap filler |
| Hybrid | Rules cover 80%, LLM handles edges | Bible contradiction (rules + LLM nuance), trope detection |

Default to deterministic. Use LLMs where nuance is genuinely required. Cost matters at runtime frequency.

## V1 ML scope (5 pieces)

1. Threshold calibration regression
2. Voice clustering over Author Profile DB
3. Comp title embedding + retrieval
4. Bayesian gap-fill priors (weak, strengthen over runs)
5. Voice drift z-score detection (anomaly tripwire)

## V1 implementation sequence (phases)

```
0  Repo foundation
1  Universal core schemas
2  Profile schemas
3  First profiles authored
4  Knowledge API
5  Spec intake pipeline
6  Drafter + single critic vertical slice
7  Critic ensemble
8  Reception ensemble
9  Continuity guardians
10 Full generation loop
11 First full book
12 V1 ML
13 Voice extraction pipeline
14 Final polish + publication package
15 Generation report
16 Registries
17 Calibration loop
```

Each phase is testable. Don't skip ahead.

## Universal voice axes (categories)

- Sentence-level: length, opener distribution, mood distribution
- Lexical: diversity, formality, rare-word frequency, concrete-noun ratio, sensory density
- Structural prose: dialogue-to-narration ratio, internal monologue share, figurative language frequency
- Punctuation signature: em-dash rate, semicolon rate, ellipsis rate, parenthetical rate
- Cadence: short-long alternation, paragraph length
- Modality: hedge frequency, adverb density, adjective stacking
- POV craft: distance, intrusion frequency, time of narration

All measurable on output. Voice fidelity = numeric distance to spec.

## Promise types (universal vocabulary)

`foreshadowing` · `chekhov_object` · `character_question` · `mystery_thread` · `emotional_debt` · `thematic_setup` · `romantic_tension` · `world_question`

Each has a `must_resolve_by` deadline (genre-defined). No chapter ships with overdue unresolved promises.

## Hard constraints (memorize)

1. No prose retention from external sources
2. No human gates in the inner loop
3. Sensitivity thresholds are sacred (cannot be force-resolved past)
4. Reproducibility: pin seed + model versions + profile versions + registry snapshot
5. Component implementation class is declared
6. Append-only logs for decisions, calibration, registry, issues
7. Schemas are the contract

## When to consult which doc

| Question | Doc |
|---|---|
| What's the entity definition? | `docs/core-ontology-v3.md` |
| Is this axis worth being primary? | `docs/profile-axis-framework-v2.md` |
| Should this use ML? | `docs/ml-opportunity-analysis-v2.md` |
| Source material for this concept? | `docs/references-reading-list.md` |
| What's the topology? | `diagrams/architecture-overview-aesthetic.html` |
| Full topology with every wire? | `diagrams/autonomous-book-pipeline-v5.mermaid` |
| What am I building this session? | `IMPLEMENTATION_PLAN.md` and `tasks/` |
| Has a decision already been made? | `DECISIONS.md` |
| What were the working conventions? | `CLAUDE.md` |

## Anti-patterns to avoid

- Hardcoding profile values into code
- Treating thresholds as final values
- Implementing components for one genre only
- Adding human gates inside the inner loop
- Loosening Sensitivity Profile programmatically
- Using LLM where rules suffice (cost)
- Using rules where LLM is required (quality)
- Skipping schema validation for "simple" cases
- Modifying decision-log entries (append only)
