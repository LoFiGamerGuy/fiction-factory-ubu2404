# Bunko Architecture — First Draft

**Document:** BUNKO-ARCH-001
**Version:** v0.1
**Date:** 2026-05-12
**Status:** First Draft — open for revision
**Codename:** Bunko (文庫) — library/imprint

---

## 0. Scope and Constraints

**Goal:** Architecture for automated writing and publication of multi-book novel series at quality indistinguishable from human-authored work, with measurable resistance to "AI slop" failure modes.

**Constraint:** Built exclusively from researched open-source / commercial tooling. No prior in-house architecture is incorporated.

**Definition of success:** A series produced under this architecture, given to genre-literate readers without disclosure, is not identified as AI-generated at a rate above chance. Critical reception aligns with comparable human-authored series in the same genre/tier.

**Out of scope for v0.1:** Audio production, cover art, marketing automation, reader-feedback ingestion, platform compliance monitoring, publication operations beyond format/upload. These are deferred (see §13).

---

## 1. Thesis: AI Slop is a Mean-Prose Problem

Single-model prose regresses to the model's defaults: hedge-prone, cliché-dense, sensory-thin, subtext-poor, and character-voice-flat. Famous series do the opposite — they have a *recognizable voice*, a *compounding world*, and *characters that don't sound like each other*.

Bunko is built around four anti-slop principles:

1. **Voice as a codified artifact**, not a vibe in a prompt
2. **Ensemble drafting** across heterogeneous models, with a strong adversarial editor
3. **Series-level skill accumulation** — book N draws on N-1's slop-kill library
4. **Multiple independent taste evaluators** before any prose ships

The compounding effect across (1)–(4) is what separates a series from a one-off. The architecture is designed for the series as the unit, not the book.

---

## 2. The Three Planes

```
CONTROL PLANE        Paperclip
                     1 company per series → natural isolation,
                     budgets, approval gates, heartbeats,
                     activity ledger, audit trail

COLLABORATION PLANE  WUPHF
                     wiki = series bible (versioned in git),
                     notebooks = per-agent working state,
                     channels = production rooms,
                     fresh-session-per-turn discipline

EXECUTION PLANE      ROMA
                     recursive decomposition matches narrative
                     structure: series → book → act → chapter
                     → scene → beat → paragraph → sentence
```

**Plane contract:**
- Governance does not know about scenes
- Scenes do not know about budgets
- Wiki does not know about model selection
- Models do not know about disclosure policy

Seams are explicit and enforced by capability-gated MCP.

---

## 3. Agent Roster

### Strategy Tier
- **World Architect** — owns the wiki bible. Append-mostly. Queryable by all.
- **Series Director** — series arc, character arcs, thematic spine, book sequencing
- **Outliner** — beat-sheet, scene list, chapter map for the current book

### Production Tier
- **Drafter Ensemble** — four parallel drafters with heterogeneous model families (see §4)
- **Aggregator** — selects or composes the winning version per scene
- **Voice Keeper** — enforces the codified voice profile sentence-by-sentence
- **Character Voice Validator** — distinct linguistic fingerprint per POV character
- **Continuity Watchkeeper** — queries wiki for every named entity, rule, and timeline reference

### Structural Tier (Gap 9 Fill — see §9)
- **Developmental Editor** — full-draft structural critic operating on completed first drafts

### Adversarial Tier (the slop killers)
- **Editorial Critic** — strongest model, prompted on slop patterns and series-specific cliché registry
- **Beta Reader Council** (K=5 personas):
  - Genre superfan (trope-literate, demands fresh execution)
  - Lit-fic reader (prose craft, theme)
  - Target-demo reader (matches series ICP)
  - DNF-prone skeptic (bails at first hedge or cliché)
  - Industry reviewer (Kirkus voice)
- **Voice Discriminator** — local classifier scoring "human vs AI" on every paragraph

### Polish & Ship Tier
- **Line Editor** — sentence rhythm, word choice, cadence
- **Proofreader** — copyedit, typos, formatting
- **Cover/Blurb** — title, jacket copy, comp titles, cover brief
- **Legal/Compliance** — plagiarism scan (cross-model), defamation, trademark, platform policy
- **Publication Operator** — EPUB/PDF formatting, metadata, KDP/IngramSpark upload

---

## 4. Model Assignment

Ensemble drafting is the core anti-slop mechanism. Heterogeneous model families produce heterogeneous prose signatures; averaging across them with a strong selector breaks any single model's fingerprint.

| Role | Model | Rationale |
|------|-------|-----------|
| World Architect | Gemini 2.5 Pro | 1M+ context holds whole series bible |
| Series Director | Opus 4.7 | strategic nuance, arc judgment |
| Outliner | Opus 4.7 | structural rigor |
| Drafter A | Sonnet 4.6 | literary default, strong prose baseline |
| Drafter B | GPT-5 | different rhythm, breaks Anthropic signature |
| Drafter C | Gemini 2.5 Pro | bible-saturated, continuity-aware |
| **Drafter D** | **Fine-tuned local (see §6)** | **series-voice native** |
| Aggregator | Opus 4.7 | nuanced selection, hybrid composition |
| Voice Keeper | Opus 4.7 | style judgment requires the best model |
| Character Voice | Sonnet 4.6 | per-character — cheaper at scale |
| Continuity | Gemini 2.5 Pro | 1M context = whole prior series |
| **Developmental Editor** | **Opus 4.7 + Gemini 2.5 Pro** | **structural critique needs both judgment and full-book context** |
| Editorial Critic | Opus 4.7 | slop detection requires subtext awareness |
| Beta personas | Mix: Opus, GPT-5, Gemini, Grok, Sonnet | diversity of perspective is the point |
| Voice Discriminator | Local fine-tuned classifier | fast, cheap, scoped task |
| Line Editor | Opus 4.7 | sentence-level taste |
| Proofreader | Haiku 4.5 | mechanical, cheap |
| Cover/Blurb | Sonnet 4.6 | commercial copy |
| Legal scan | GPT-5 + local | independence required for plagiarism |
| Research | Manus + OpenDeepSearch | autonomous browse + structured search |
| Market pulse | Grok | live X / BookTok signal |

LiteLLM is the canonical model gateway. Routing policy is encoded in YAML and resolved per role + context.

---

## 5. Anti-Slop Machinery

### 5.1 Voice Profile (codified)

Before book 1, ingest 5–10 inspiration novels via OpenDeepSearch + Gemini long-context. Extract and store in WUPHF wiki under `voice/{author-name}.yaml`:

- Sentence length distribution (target histogram)
- POS-ngram patterns
- Metaphor families used / forbidden
- Dialogue tag distribution (% "said" vs alternatives)
- Sensory register ratios (sight/sound/touch/smell/taste/proprioception)
- Pacing per scene type (action/dialogue/interiority/transition word counts)
- Subtext density (target gap between literal dialogue and intended meaning)
- Filter-word ceiling ("felt", "saw", "heard", "noticed", "realized")
- Cadence fingerprint (stress patterns, rhythm signatures)

Voice Keeper enforces conformance per scene. Drift triggers intervention.

### 5.2 Cliché Registry

WUPHF wiki article `editorial/clichés.md`, growing with every book via EvoSkill:
- Genre-agnostic AI tells ("a shiver ran down her spine" class)
- Hedge constructions ("it was as if...", "couldn't help but...")
- Filter words in narration
- Em-dash overuse, triple-listing tics
- Genre-specific tropes the series is choosing to subvert

Every REJECT from Editorial Critic feeds a new pattern. The registry compounds across books.

### 5.3 Voice Discriminator

Small local classifier (Qwen 2.5 7B base, fine-tuned on a labeled corpus of human vs AI-generated prose in genre). Scores every paragraph 0–1. Above-threshold paragraphs bounce back to drafters with the discriminator's reasoning attached.

### 5.4 Beta Reader Council

K=5 personas reading the chapter independently in WUPHF channels, leaving margin notes. Editorial Critic aggregates with weights tuned to the series ICP. This is ROMA's K-way proposal pattern applied to *criticism* rather than drafting.

### 5.5 EvoSkill Series Memory

Every REVISE or REJECT trace from Editorial Critic, Voice Keeper, Continuity Watchkeeper, and Developmental Editor feeds EvoSkill. Discovered patterns become skills in `skills/series-{name}/`. Book 2 starts with book 1's accumulated library. By book 5 the system has a deeply series-specific editorial intelligence.

### 5.6 harbor Eval Suite

Held-out test sets, ratcheting:
- Known-slop paragraphs (from prior failed AI drafts, AI publishing scandals)
- Known-good paragraphs (from comp titles, with fair-use boundary work)
- Voice-matching probes (does this read like the target author?)
- Continuity probes (planted contradictions the Watchkeeper should catch)
- Structural probes (broken acts, weak protagonist wants — for Developmental Editor)

Every drafter candidate runs through harbor before promotion. Skills are gated by harbor pass-rate before merging.

---

## 6. Voice-Native Fine-Tuning Pipeline (Gap 1 Fill)

Drafter D is the long-term anti-slop weapon: a local model fine-tuned on the series voice. It is the only drafter whose prose defaults match the target author. Drafters A/B/C provide variety; Drafter D provides anchor.

### 6.1 Tooling Stack

- **Base models** (choice depends on budget and quality target):
  - Qwen 2.5 32B Instruct — strong prose baseline, permissive license, fits on a single A100/H100
  - Llama 3.3 70B Instruct — higher quality ceiling, requires multi-GPU or quantization
  - Mistral Large or DeepSeek 67B as alternates
- **Fine-tuning frameworks**:
  - **Unsloth** — 2× faster LoRA SFT, lower VRAM, best for iteration speed
  - **Axolotl** — full-featured FT pipeline, broader algorithm support (DPO, ORPO, KTO)
  - **Together AI** — managed fine-tuning fallback if local GPU is bottleneck
- **Inference**:
  - **vLLM** on the AWS GPU node for hosted serving
  - LoRA adapters hot-swappable per series (one base, many voices)
  - LiteLLM routes Drafter D calls through the vLLM endpoint
- **Evaluation**:
  - harbor voice probes as primary acceptance gate
  - Voice Discriminator score threshold as secondary gate

### 6.2 Training Pipeline (Three Phases)

**Phase 1 — Supervised Fine-Tuning (SFT)**
- Corpus: paragraph-level snippets from inspirations + synthetic instruction-wrapped reformulations
- Synthetic voice transfer: Opus 4.7 rewrites inspiration paragraphs in target voice (navigate fair-use boundaries carefully — see §11.3 on legal layer)
- ~10–50k paragraph examples, 1–3 epochs LoRA
- Acceptance: Voice Discriminator score above baseline, harbor voice probes >70%

**Phase 2 — Preference Learning (DPO or ORPO)**
- Source: (Editorial Critic GO, Editorial Critic REJECT) pairs collected during Book 1 production
- Each pair is a same-prompt, same-context preference signal
- KL penalty anchors to Phase 1 checkpoint to prevent mode collapse
- ~1k–5k preference pairs per training round

**Phase 3 — Continuous Improvement**
- Every book's production run generates new preference pairs
- Periodic DPO refresh (monthly or per-book completion)
- Negative corpus: known-slop paragraphs as additional rejects
- Regression eval: full harbor suite must not regress on broad capabilities

### 6.3 Risks and Mitigations

| Risk | Mitigation |
|------|------------|
| Overfitting to inspirations → derivative prose, plagiarism risk | Diverse base corpus across genre subspaces; periodic similarity scan against source inspirations |
| Catastrophic forgetting → quality regression on novel scenes | KL penalty in DPO; broad held-out eval, not just voice probes |
| Mode collapse → samey output across drafts | Temperature/top-p variation across drafter calls; periodic novelty probes |
| Fair-use exposure on training data | Stick to public domain + clearly licensed inspirations; document the training corpus per series as a discovery artifact |

### 6.4 Hosting Topology

```
Edgewalker (dev)
  └── Unsloth training jobs, small experiments
AWS GPU node (production)
  ├── vLLM serving Drafter D inference
  ├── LoRA adapter store: one per series
  └── Confidential workloads route through Sentient-Enclaves
Together AI (overflow)
  └── Larger fine-tuning runs when local GPU saturated
```

---

## 7. Voice Authenticity Layer (Gap 7 Fill)

Reframe: not primarily about disclosure compliance. About ensuring every shipped paragraph is *verifiably authentic* to the codified voice, defensibly attributable, and reconstructible from its provenance.

This raises produced writing quality directly because:
1. Per-paragraph provenance gives real-time quality telemetry
2. The authenticity audit log is the highest-quality training corpus for Drafter D
3. Defensible voice identity is the prerequisite for licensing and commercialization

### 7.1 Provenance Manifest (per paragraph)

Every shipped paragraph carries a structured record:

```yaml
paragraph_id: ch04-s07-p12
drafter: D
model: qwen2.5-32b-lora-series-alpha-v3
skill_state_hash: 8a3f1c...
voice_discriminator_score: 0.94
voice_keeper_score: 0.91
character_voice_score: 0.88
aggregator_rationale: "Drafter D selected over A/B/C for sensory register match and dialogue tag distribution conformance"
revision_count: 2
gates_passed: [voice_keeper, character_voice, continuity, editorial_critic, beta_council]
```

Stored alongside the manuscript in WUPHF activity stream. Manifests are MCP-queryable.

### 7.2 Authorship Attestation

- **Sigstore / cosign** for cryptographic signing of:
  - Manuscript hash
  - Voice profile fingerprint
  - Skill registry state at time of writing
  - Wiki bible commit hash
- Public verification possible without exposing the model weights
- Signed manifest stored alongside published work

### 7.3 Audit Log

Every chapter has a complete reconstruction trail in WUPHF activity:
- From outline through final shipped text
- Every gate decision, every revise loop, every skill applied
- Replayable for any disputed authorship claim or quality investigation
- Becomes the training corpus for Drafter D's preference learning

### 7.4 Disclosure Switchboard

YAML config mapping `(platform, jurisdiction) → required disclosure`:
- Automatically generates copyright page, KDP description text, EU AI Act disclosure where required
- Kept current by a compliance-monitoring agent (Manus + Grok on weekly cadence)
- Per-platform compilation of EPUB/PDF metadata at publication time

**Tooling additions:**
- Sigstore / cosign (cryptographic signing)
- TUF (The Update Framework) metadata patterns for signed releases
- Custom Provenance Manifest schema (YAML, JSON-LD)
- WUPHF activity stream as canonical audit log

---

## 8. OML Fingerprinting Integration (Gap 8 Fill)

OML-1.0-Fingerprinting (Sentient) was designed for LLM weight fingerprinting — proving provenance of a model. Apply to series production at three levels:

### 8.1 Model Fingerprinting

- Inject OML fingerprints into Drafter D during fine-tuning per Sentient's library
- Each series has a unique fingerprint embedded in the LoRA adapter
- Proves any output traceable to your model
- Survives model export, partial reuse, distillation attempts

### 8.2 Skill Library Fingerprinting

- Each skill in the EvoSkill registry carries provenance metadata:
  - Which trace produced it
  - Timestamp + author agent
  - Eval suite it passed
  - Cryptographic signature
- Skills become licensable IP units, not just config

### 8.3 Manuscript Watermarking

Steganographic watermarking at the text level using established research:
- **MarkLLM** (open-source watermarking toolkit) as the primary library
- Aaronson-style watermarking scheme (statistical, undetectable to readers, detectable with key)
- Christ et al. cryptographic watermarking as alternative
- Embedded fingerprint survives copy-paste, partial quotation, and most reformatting
- Detectable via secret key the publisher controls

### 8.4 Provenance Graph

Every published manuscript ships with a manifest pointing to:
- Model fingerprints used (with version)
- Skill set commit hash
- Wiki bible commit hash at time of writing
- Eval suite version
- Author voice profile version

The manifest is signed (Sigstore) and stored alongside the published file. A reader cannot see it; an auditor with the public key can.

### 8.5 Why This Raises Quality

- **Defensible IP** if the series voice is commercialized or licensed
- **Reverse-plagiarism detection** — if your prose is scraped for someone else's model, watermark may surface
- **Reproducibility** — any chapter can be exactly reproduced from its provenance graph, which makes regression debugging tractable
- **Licensing infrastructure** ready if you license the voice to other authors or platforms

**Tooling additions:**
- OML-1.0-Fingerprinting library (Sentient)
- MarkLLM or equivalent text watermarking
- Signed manifest format extending the §7.2 attestation

---

## 9. Developmental Editor (Gap 9 Fill)

The Editorial Critic catches sentence-level slop. The Beta Council catches reader-experience slop. Neither catches *structural* failures: "the protagonist has no want," "act two has no rising action," "the midpoint reversal doesn't reverse anything," "promises made on page 1 are never paid off."

Without a structural critic, the architecture can produce mechanically clean prose that has no story underneath. This is the single largest remaining quality risk.

### 9.1 The Developmental Editor

- **Model:** Opus 4.7 + Gemini 2.5 Pro (used in tandem — Opus for judgment, Gemini for full-book context)
- **Position:** runs after first complete draft assembly, BEFORE line editing
- **Purpose:** structural audit of the entire manuscript before polish

Polishing a structurally broken book produces only better-polished slop. The Developmental Editor is the gate that prevents that.

### 9.2 Encoded Frameworks

The agent is prompted with explicit story-structure frameworks:
- **Save the Cat** (Snyder) — 15-beat breakdown
- **Story Grid** (Coyne) — genre-obligatory scenes and conventions
- **Robert McKee** — classical three-act, controlling idea, inciting incident
- **Brandon Sanderson** — Promises / Progress / Payoffs
- **John Yorke** (*Into the Woods*) — 5-act inside 3-act, rising action geometry
- **Lisa Cron** (*Story Genius*) — internal arc primacy

Frameworks are not dogma — they are diagnostic lenses. The Developmental Editor reports against all of them and the Series Director arbitrates.

### 9.3 Audit Dimensions

1. **Protagonist want vs need** — clearly established in act 1, complicated in act 2, resolved or transformed in act 3
2. **Try-fail cycles** — escalating stakes, increasing cost
3. **Act break execution** — inciting incident, midpoint reversal, all-is-lost moment, climax
4. **Subplot resolution** — every subplot opened has a payoff or deliberate dangle
5. **Theme delivery** — earned through story events, not lectured by characters
6. **Character arc completion** — internal change earned through external events
7. **Promises kept** — every reader-promise from opening pages has a corresponding payoff
8. **Sagging middle** — midpoint reversal lands with sufficient force
9. **Setup/payoff balance** — Chekhov audit on planted details
10. **Reader-emotion curve** — emotional intensity actually rises across the book

### 9.4 Decision Routing

When the Developmental Editor returns issues:

| Issue class | Routing |
|-------------|---------|
| Structural — broken act, weak want, no theme | → Series Director / Outliner for replanning |
| Beat-level — sagging middle, missed payoff | → Outliner for scene-level revision |
| Execution — beat is correct but scene fails it | → Drafters with specific revision guidance |
| Polish-acceptable | → Line Editor (proceed) |

### 9.5 Eval

harbor eval suite extended with **structural probes** — manuscripts with planted structural flaws (broken acts, weak protagonists, unpaid promises). Developmental Editor must catch them at >85% rate before deployment.

**Tooling additions:**
- New agent definition + system prompt set encoding frameworks
- Structural probe set for harbor
- WUPHF channel `#story-room-structural` for the Developmental Editor + Series Director dialogue

---

## 10. Production Flow

```
Series concept
  → Series Director plans N-book arc
    → ROMA: Series → Book 1
      → Outliner generates beat sheet
        → Atomizer: each beat atomic or further plan?
          → Planner: chapter → scenes (MECE dependency graph)
            → Scenes execute in parallel:
              [Drafter A | B | C | D] → 4 candidates
              → Aggregator selects / composes
              → Voice Keeper sentence audit
              → Character Voice validator
              → Editorial Critic + Beta Council
              → Voice Discriminator score
              → if fail: revise (counts toward EvoSkill trace)
              → if pass: continuity check
              → if pass: promote to scene-shippable
            → Aggregator rolls scenes into chapter
            → Continuity Watchkeeper full-chapter pass
          → Chapter promoted, wiki bible updated
        → Book draft assembled (first complete draft)
      → ** Developmental Editor full-draft structural audit **
        → if structural fail: route back per §9.4
        → if pass: proceed
      → Line Edit pass
      → Proofread pass
      → Legal / Compliance gate (HUMAN approval required)
      → Provenance Manifest finalized + signed (Sigstore)
      → Watermark embedded (MarkLLM)
      → Cover / Blurb produced
      → Publication Operator ships
    → Audit log archived to WUPHF wiki
    → EvoSkill processes traces from this book
    → Drafter D preference data appended
    → Series Director adjusts Book 2 plan
```

Paperclip approval gates at: outline lock, first-draft accept, **structural audit pass**, line-edit accept, legal clearance, publication. Human-in-loop at gates where taste is irreplaceable.

---

## 11. Build Order

1. Pilot series concept + 10-novel inspiration corpus assembled
2. Voice profile extraction → wiki `voice/`
3. Paperclip company stood up, agents seeded
4. WUPHF wired, wiki skeleton in place
5. harbor eval suite assembled (slop + voice + structural probes)
6. Voice Discriminator fine-tuned (local, ~1 day on GPU)
7. **Drafter D Phase 1 SFT** (Unsloth, ~1 week including data prep)
8. **Developmental Editor agent stood up and validated against structural probes**
9. ROMA runtime for one chapter end-to-end (smoke test)
10. **Provenance Manifest schema + Sigstore signing wired**
11. **OML fingerprint injection during Drafter D training**
12. Book 1 with heavy human gating
13. EvoSkill loop processes Book 1 traces
14. **Drafter D Phase 2 DPO** on Book 1 preference pairs
15. Book 2 with reduced human gating
16. By Book 3–4, approaching craft autonomy; human only at strategic + legal gates

---

## 12. Tooling Inventory

**Control / Collaboration / Execution planes:**
- Paperclip (control plane, MCP server, approvals)
- WUPHF (wiki, notebooks, channels, fresh-session discipline)
- ROMA (recursive task decomposition)

**Model & runtime:**
- LiteLLM (gateway)
- Anthropic Opus 4.7 / Sonnet 4.6 / Haiku 4.5
- OpenAI GPT-5
- Google Gemini 2.5 Pro
- xAI Grok
- Manus (autonomous browse)
- Qwen 2.5 / Llama 3.3 (local base models for Drafter D and Voice Discriminator)
- vLLM (local inference serving)

**Fine-tuning (Gap 1):**
- Unsloth
- Axolotl
- Together AI (managed fallback)

**Skill evolution & evaluation:**
- EvoSkill (skill discovery from traces)
- harbor (eval framework)
- Voice Discriminator (custom local classifier)

**Authenticity & provenance (Gaps 7, 8):**
- Sigstore / cosign
- TUF metadata
- OML-1.0-Fingerprinting (Sentient)
- MarkLLM (text watermarking)
- Custom Provenance Manifest schema

**Research & search:**
- OpenDeepSearch (structured search)
- Manus (long-running browse)

**Infrastructure:**
- Sentient-Enclaves (confidential workloads where required)
- AWS GPU node (Drafter D hosting, fine-tuning)
- Edgewalker (dev, light training)

---

## 13. Deferred Gaps

Tracked for v0.2+ but not architecturally blocking quality of produced writing:

| # | Gap | Deferral rationale |
|---|-----|--------------------|
| 2 | Audio narration (ElevenLabs, Play.ht) | Distribution channel, not quality |
| 3 | Cover art (Midjourney, Flux, Ideogram) | Commercial wrap, separable concern |
| 4 | Marketing automation | Distribution, not production |
| 5 | Reader-feedback ingestion loop | High-value for series cadence but downstream of v0.1 production |
| 6 | Real-time KDP/IS policy monitor | Operational, not architectural |
| 10 | The "famous" gap (market dynamics, discoverability) | Outside architecture's control surface |

Note: Gap 5 (reader-feedback) is the highest-value deferred item and should be the first v0.2 addition. It closes the outer loop on series-level learning.

---

## 14. Open Questions for v0.2

1. **Drafter D base model selection** — Qwen 2.5 32B vs Llama 3.3 70B vs Mistral Large. Decision depends on AWS GPU capacity and quality target. Run a bake-off.
2. **DPO vs ORPO vs KTO** for Drafter D Phase 2. Empirical question — test on a held-out preference set.
3. **Watermarking robustness budget** — how much quality degradation is acceptable from MarkLLM watermark injection? Run a/b eval.
4. **Synthetic voice transfer fair-use boundary** — formal opinion needed on using Opus to reformulate inspiration paragraphs as training data. Legal gate before Phase 1 SFT.
5. **Developmental Editor framework weighting** — Save the Cat and McKee disagree on inciting incident placement. Series-specific calibration needed.
6. **OML fingerprint conflict with KDP / Amazon scanning** — verify fingerprint and watermark do not trigger platform anti-AI detection systems in ways that would be commercially harmful.
7. **Cross-series voice contamination** — if Drafter D is fine-tuned on Series Alpha and then re-fine-tuned for Series Beta, can residual voice leak? Probably yes. Mitigation: separate base + LoRA per series, never re-tune on top of a tuned model.
8. **Beta Reader Council weighting** — by genre, by ICP, by book? Likely per-series configuration.

---

## 15. Non-Goals (Explicit)

- Bunko does not attempt to predict commercial success
- Bunko does not attempt to game discovery algorithms
- Bunko does not produce content outside its codified voice profile (cross-genre work requires a new series instance)
- Bunko does not operate without human approval gates at legal clearance and publication
- Bunko does not generate disclosed real-person fiction or licensed-IP fan fiction

---

*End of v0.1 first draft. Submit revisions as BUNKO-ARCH-001-v0.2 with delta annotations.*
