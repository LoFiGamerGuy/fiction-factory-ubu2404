# Bunko Architecture — Second Draft

**Document:** BUNKO-ARCH-001
**Version:** v0.2
**Date:** 2026-05-12
**Status:** Second Draft — supersedes v0.1
**Codename:** Bunko (文庫) — library/imprint
**Delta from v0.1:** Reception Tier added (Gap 5 fill). New §11 Reader Feedback Ingestion Loop. Two new agents (Reception Analyst, Reader Cohort Modeler). Beta Reader Council weights now reception-calibrated. Production flow gets a post-publication branch feeding back into Series Director, EvoSkill, and Voice Profile updates.

---

## 0. Scope and Constraints

**Goal:** Architecture for automated writing and publication of multi-book novel series at quality indistinguishable from human-authored work, with measurable resistance to "AI slop" failure modes and a closed outer loop on series-level audience learning.

**Constraint:** Built exclusively from researched open-source / commercial tooling. No prior in-house architecture is incorporated.

**Definition of success:** A series produced under this architecture, given to genre-literate readers without disclosure, is not identified as AI-generated at a rate above chance. Critical reception aligns with comparable human-authored series in the same genre/tier. Book N+1 demonstrably learns from Book N's audience response.

**Out of scope for v0.2:** Audio production, cover art, marketing automation, real-time platform policy monitoring, the "famous" problem (market dynamics). These are deferred to v0.3+.

---

## 1. Thesis: AI Slop is a Mean-Prose Problem

Single-model prose regresses to the model's defaults: hedge-prone, cliché-dense, sensory-thin, subtext-poor, and character-voice-flat. Famous series do the opposite — they have a *recognizable voice*, a *compounding world*, *characters that don't sound like each other*, and *a reader base whose response shapes future books*.

Bunko is built around five anti-slop principles:

1. **Voice as a codified artifact**, not a vibe in a prompt (see companion spec: BUNKO-VOICE-PROFILE-SCHEMA-v0.1)
2. **Ensemble drafting** across heterogeneous models, with a strong adversarial editor
3. **Series-level skill accumulation** — book N draws on N-1's slop-kill library
4. **Multiple independent taste evaluators** before any prose ships
5. **Closed outer loop** on reader reception — Beta Council is calibrated against actual reader behavior, not just simulated personas

The compounding effect across (1)–(5) is what separates a one-off from a phenomenon.

---

## 2. The Three Planes

```
CONTROL PLANE        Paperclip
                     1 company per series → natural isolation,
                     budgets, approval gates, heartbeats,
                     activity ledger, audit trail

COLLABORATION PLANE  WUPHF
                     wiki = series bible (versioned in git),
                     notebooks = per-agent working state,
                     channels = production rooms,
                     fresh-session-per-turn discipline

EXECUTION PLANE      ROMA
                     recursive decomposition matches narrative
                     structure: series → book → act → chapter
                     → scene → beat → paragraph → sentence
```

**Plane contract:**
- Governance does not know about scenes
- Scenes do not know about budgets
- Wiki does not know about model selection
- Models do not know about disclosure policy
- Reception data does not directly modify prose — it modifies the agents and skills that produce prose

Seams are explicit and enforced by capability-gated MCP.

---

## 3. Agent Roster

### Strategy Tier
- **World Architect** — owns the wiki bible. Append-mostly. Queryable by all.
- **Series Director** — series arc, character arcs, thematic spine, book sequencing. *In v0.2: receives reception briefs from Reception Analyst before planning each book.*
- **Outliner** — beat-sheet, scene list, chapter map for the current book

### Production Tier
- **Drafter Ensemble** — four parallel drafters with heterogeneous model families (see §4)
- **Aggregator** — selects or composes the winning version per scene
- **Voice Keeper** — enforces the codified voice profile sentence-by-sentence
- **Character Voice Validator** — distinct linguistic fingerprint per POV character
- **Continuity Watchkeeper** — queries wiki for every named entity, rule, and timeline reference

### Structural Tier
- **Developmental Editor** — full-draft structural critic operating on completed first drafts

### Adversarial Tier (the slop killers)
- **Editorial Critic** — strongest model, prompted on slop patterns and series-specific cliché registry
- **Beta Reader Council** (K=5 personas):
  - Genre superfan (trope-literate, demands fresh execution)
  - Lit-fic reader (prose craft, theme)
  - Target-demo reader (matches series ICP)
  - DNF-prone skeptic (bails at first hedge or cliché)
  - Industry reviewer (Kirkus voice)
  - *In v0.2: persona weights are calibrated by Reader Cohort Modeler against actual reception data*
- **Voice Discriminator** — local classifier scoring "human vs AI" on every paragraph

### Reception Tier (NEW in v0.2)
- **Reception Analyst** — ingests reviews, classifies sentiment and theme, extracts complaint/praise typologies, routes signals to other agents
- **Reader Cohort Modeler** — builds typologies of reader segments from review behavior, recalibrates Beta Council persona weights, identifies which cohorts the series is winning or losing

### Polish & Ship Tier
- **Line Editor** — sentence rhythm, word choice, cadence
- **Proofreader** — copyedit, typos, formatting
- **Cover/Blurb** — title, jacket copy, comp titles, cover brief
- **Legal/Compliance** — plagiarism scan (cross-model), defamation, trademark, platform policy
- **Publication Operator** — EPUB/PDF formatting, metadata, KDP/IngramSpark upload

---

## 4. Model Assignment

Ensemble drafting is the core anti-slop mechanism. Heterogeneous model families produce heterogeneous prose signatures; averaging across them with a strong selector breaks any single model's fingerprint.

| Role | Model | Rationale |
|------|-------|-----------|
| World Architect | Gemini 2.5 Pro | 1M+ context holds whole series bible |
| Series Director | Opus 4.7 | strategic nuance, arc judgment |
| Outliner | Opus 4.7 | structural rigor |
| Drafter A | Sonnet 4.6 | literary default, strong prose baseline |
| Drafter B | GPT-5 | different rhythm, breaks Anthropic signature |
| Drafter C | Gemini 2.5 Pro | bible-saturated, continuity-aware |
| Drafter D | Fine-tuned local | series-voice native (see §6) |
| Aggregator | Opus 4.7 | nuanced selection, hybrid composition |
| Voice Keeper | Opus 4.7 | style judgment requires the best model |
| Character Voice | Sonnet 4.6 | per-character — cheaper at scale |
| Continuity | Gemini 2.5 Pro | 1M context = whole prior series |
| Developmental Editor | Opus 4.7 + Gemini 2.5 Pro | judgment + full-book context |
| Editorial Critic | Opus 4.7 | slop detection requires subtext awareness |
| Beta personas | Mix: Opus, GPT-5, Gemini, Grok, Sonnet | diversity of perspective is the point |
| Voice Discriminator | Local fine-tuned classifier | fast, cheap, scoped task |
| **Reception Analyst** | **Sonnet 4.6** | **mid-tier reasoning at scale across many reviews** |
| **Reader Cohort Modeler** | **Opus 4.7** | **typological judgment, low-volume / high-stakes** |
| Line Editor | Opus 4.7 | sentence-level taste |
| Proofreader | Haiku 4.5 | mechanical, cheap |
| Cover/Blurb | Sonnet 4.6 | commercial copy |
| Legal scan | GPT-5 + local | independence required for plagiarism |
| Research | Manus + OpenDeepSearch | autonomous browse + structured search |
| Market pulse | Grok | live X / BookTok signal |

LiteLLM is the canonical model gateway. Routing policy is encoded in YAML and resolved per role + context.

---

## 5. Anti-Slop Machinery

### 5.1 Voice Profile (codified)

See companion spec: **BUNKO-VOICE-PROFILE-SCHEMA-v0.1.yaml**

Voice Keeper enforces conformance per scene. Drift triggers intervention.

### 5.2 Cliché Registry

WUPHF wiki article `editorial/clichés.md`, growing with every book via EvoSkill. *In v0.2: also growing from reader-complaint patterns ingested by Reception Analyst.*

### 5.3 Voice Discriminator

Small local classifier (Qwen 2.5 7B base, fine-tuned on a labeled corpus of human vs AI-generated prose in genre). Scores every paragraph 0–1. Above-threshold paragraphs bounce back to drafters with the discriminator's reasoning attached.

### 5.4 Beta Reader Council (now reception-calibrated)

K=5 personas reading the chapter independently. Editorial Critic aggregates with weights tuned by Reader Cohort Modeler against the series' actual reception data. By book 3+, the Council is not simulating generic personas — it is simulating *this series' actual reader base*.

### 5.5 EvoSkill Series Memory

Every REVISE or REJECT trace from Editorial Critic, Voice Keeper, Continuity Watchkeeper, and Developmental Editor feeds EvoSkill. *In v0.2: Reception Analyst also produces post-publication skill candidates from review patterns.* Skills accumulate per series.

### 5.6 harbor Eval Suite

Held-out test sets, ratcheting:
- Known-slop paragraphs
- Known-good paragraphs
- Voice-matching probes
- Continuity probes
- Structural probes
- **Reception probes (NEW)** — past reviews used as eval ground truth: given a passage, can the system predict reader response? Calibration target for Beta Council.

---

## 6. Voice-Native Fine-Tuning Pipeline (Gap 1 Fill)

[Unchanged from v0.1. See §6 of BUNKO-ARCH-001-v0.1 for full detail.]

Summary: Drafter D is a fine-tuned local model (Qwen 2.5 32B or Llama 3.3 70B base, LoRA adapter). Three-phase training:
1. SFT on inspiration corpus + synthetic voice transfer
2. DPO/ORPO on (Editorial Critic GO, Editorial Critic REJECT) pairs
3. Continuous DPO updates per book

Tooling: Unsloth, Axolotl, Together AI fallback, vLLM serving, LoRA adapters hot-swappable per series.

*In v0.2:* Phase 3 preference pairs are augmented with reception-derived signals — reader-cited praise → preferred, reader-cited complaint → rejected.

---

## 7. Voice Authenticity Layer (Gap 7 Fill)

[Unchanged from v0.1. See §7 of BUNKO-ARCH-001-v0.1 for full detail.]

Summary: Per-paragraph Provenance Manifest, Sigstore/cosign authorship attestation, full audit log in WUPHF activity, disclosure switchboard YAML.

---

## 8. OML Fingerprinting Integration (Gap 8 Fill)

[Unchanged from v0.1. See §8 of BUNKO-ARCH-001-v0.1 for full detail.]

Summary: OML fingerprints in Drafter D LoRA, MarkLLM text watermarking, skill library signed provenance, manuscript provenance graph signed via Sigstore.

---

## 9. Developmental Editor (Gap 9 Fill)

[Unchanged from v0.1. See §9 of BUNKO-ARCH-001-v0.1 for full detail.]

Summary: Structural-tier agent (Opus 4.7 + Gemini 2.5 Pro) running after first complete draft, before line editing. Encoded frameworks: Save the Cat, Story Grid, McKee, Sanderson promises/progress/payoffs, Yorke, Cron. Ten audit dimensions, four-way decision routing.

---

## 10. (Reserved — was §10 Production Flow, now §12 to keep gap-fill sections contiguous)

---

## 11. Reader Feedback Ingestion Loop (Gap 5 Fill)

The architecture without this section produces high-quality prose that never learns from its audience. Reception ingestion closes the outer loop — Beta Council stops being a guess about reader response and becomes a calibrated model of *this series'* reader response.

### 11.1 Ingestion Sources

| Source | Method | Tooling | Cadence |
|--------|--------|---------|---------|
| Amazon reviews | API (no public review API — scrape via Manus or Apify) | Manus autonomous browse + custom MCP wrapper | Daily |
| Goodreads reviews | Scrape (no API access since 2020) | Manus + custom MCP | Daily |
| StoryGraph | Scrape | Manus + custom MCP | Daily |
| BookTok | TikTok hashtag/account search | Manus + custom MCP | 3×/week |
| Reddit (r/books, r/fantasy, r/romance, etc.) | Reddit API or PRAW | Custom MCP | Daily |
| Blog reviews | RSS / RSS aggregators + targeted search | OpenDeepSearch | Weekly |
| Twitter/X mentions | X API (paid) | Grok native access | Real-time |
| Newsletter mentions (Substack, etc.) | Targeted search | OpenDeepSearch | Weekly |
| Direct reader email (if newsletter is set up) | IMAP / Gmail MCP | Composio Gmail | Daily |

All ingested reviews land in WUPHF channel `#reviews-incoming` as structured records.

### 11.2 Normalization

Every review, regardless of source, is normalized to a common schema:

```yaml
review_id: rev-<platform>-<external-id>
platform: amazon | goodreads | storygraph | booktok | reddit | blog | x | newsletter | email
book_id: <series-alpha-book-1>
collected_at: <iso8601>
posted_at: <iso8601-best-effort>
reviewer:
  platform_handle: <string>
  cohort_tags: []  # filled by Reader Cohort Modeler
  prior_reviews_count: <int>
  trust_score: <0-1>  # paid-review and brigading detection
rating: <1-5 or null>
title: <string>
body: <string>
attached_quotes: []  # passages reader quoted
recommendation_signal: explicit_recommend | implicit_recommend | neutral | implicit_warn | explicit_warn
dnf_signal: did_finish | dnf_unspecified | dnf_chapter_<n>
```

### 11.3 Classification (Reception Analyst)

For each normalized review, the Reception Analyst produces:

**Sentiment dimensions** (scored 0-1):
- Overall sentiment
- Voice/prose sentiment (do they comment on the prose? in what terms?)
- Plot/structure sentiment
- Character sentiment
- World/setting sentiment
- Pacing sentiment
- Emotional payoff sentiment

**Cited praise** — explicit positive callouts, structured:
- Topic (voice/plot/char/world/pacing/theme/payoff)
- Quote (if reader quoted prose)
- Specificity (vague/specific/scene-level)

**Cited complaints** — explicit negative callouts, same structure

**Comparison anchors** — what other books/authors did they compare it to?

**DNF analysis** — if did-not-finish, where and why

**Voice perception** — do they perceive it as AI? Do they comment on "feeling off"? Even adjacent terms ("flat", "generic", "by-the-numbers") get flagged.

**Trust filtering:**
- Brigading detection (sudden burst of similar-sentiment reviews)
- Paid-review heuristics (reviewer history, generic praise patterns)
- Friend/family bias detection (early reviews, low reviewer history)
- Bot detection (writing patterns, posting cadence)

Untrusted reviews are ingested but downweighted in aggregation.

### 11.4 Cohort Modeling (Reader Cohort Modeler)

Once enough reviews accumulate (~50-100 trusted reviews), the Cohort Modeler clusters reviewers into typologies:

- **Genre superfans** (prior reviews show deep genre engagement)
- **Genre tourists** (this is their first or one of few in this genre)
- **Voice-focused readers** (their reviews emphasize prose)
- **Plot-focused readers** (their reviews emphasize story mechanics)
- **Character-focused readers** (their reviews emphasize character arcs)
- **Theme-focused readers** (their reviews emphasize meaning/payoff)
- **Skeptics** (low average ratings, demanding)
- **Boosters** (high average ratings, generous)

Each Beta Council persona gets re-weighted based on which cohorts the series is actually attracting. If "voice-focused readers" are 40% of trusted reviewers, the lit-fic-reader persona's vote gets weighted up correspondingly.

### 11.5 Signal Routing

| Signal | Routes to | Effect |
|--------|-----------|--------|
| Voice complaint cluster | Voice Keeper + Drafter D preference data | Voice Profile YAML update; rejected examples added to DPO corpus |
| Voice praise cluster | Drafter D preference data | Preferred examples added to DPO corpus |
| Pacing complaint cluster | Outliner + Series Director | Scene-length distribution adjusted in next book outline |
| Character-voice complaint | Character Voice Validator + skill registry | New skill candidate via EvoSkill |
| Continuity complaint | Continuity Watchkeeper + wiki | Wiki audit; eval probe added to harbor |
| Structural complaint | Developmental Editor + Series Director | Framework calibration; new structural probe in harbor |
| Theme/payoff complaint | Series Director + Developmental Editor | Arc replanning in next book |
| AI-detection adjacent | Voice Discriminator + Drafter D | Discriminator retrained; LoRA Phase 3 update |
| DNF-at-chapter-N pattern | Series Director + Outliner | Chapter pacing rework; new probe |
| Comparison anchor (positive) | Voice Profile inspiration set | Possible new calibration source |
| Comparison anchor (negative) | Voice Profile differentiation set | Forbidden-construction candidate |

All routing decisions are logged in WUPHF activity for audit.

### 11.6 New WUPHF Channels

- `#reviews-incoming` — raw ingested reviews
- `#reception-analysis` — Reception Analyst classifications + aggregations
- `#cohort-modeling` — Reader Cohort Modeler clusterings and persona weight changes
- `#reception-routing` — signal routing decisions and their downstream effects

### 11.7 New harbor Probes

- **Reception probes** — past reviews + the prose they critiqued; system must predict reader response
- **Trust filtering probes** — labeled reviews (brigading / paid / friend-bias) for classifier eval
- **Cohort probes** — held-out reviewers for cohort assignment validation

### 11.8 Skill Registry Additions

New paths under `skills/`:
- `skills/series-{name}/reception/voice-complaints/` — patterns extracted from voice complaints
- `skills/series-{name}/reception/pacing-fixes/` — patterns from pacing complaints
- `skills/series-{name}/reception/character-distinguishers/` — patterns from character-voice issues
- `skills/series-{name}/reception/cohort-aware-prose/` — patterns that win specific cohorts

### 11.9 Time Decay and Stability

- New reviews are weighted higher (recent signal > old signal)
- A signal becomes actionable only after appearing across N independent reviewers (typically N=5)
- Series Director receives a "Reception Brief" before planning each book — the aggregated, decayed, cohort-weighted summary of audience response to date
- Single bad reviews never trigger architectural changes; only patterns do

### 11.10 Honest Limitations

- Reception data is biased toward readers willing to review (~5-10% of readers)
- Negative voice signals may surface late (readers who DNF often don't review)
- Platform-specific behaviors warp the signal (Amazon vs Goodreads have different review cultures)
- Mitigation: weight DNF-pattern detection heavily, ingest from many platforms, build cohort filter to detect reader-type imbalance

### 11.11 Tooling Inventory for Reception Tier

- Manus (autonomous browse, primary scraping)
- Custom MCP wrappers per platform (Amazon, Goodreads, StoryGraph, BookTok, Reddit)
- Reddit API / PRAW
- Grok (X/Twitter signal)
- OpenDeepSearch (blog and newsletter discovery)
- Composio Gmail (direct reader email if newsletter exists)
- Apify (commercial scraping fallback when in-house scrapers blocked)

---

## 12. Production Flow

```
Series concept
  → Reception Brief from prior book (if not Book 1)
  → Series Director plans N-book arc
    → ROMA: Series → Book 1
      → Outliner generates beat sheet
        → Atomizer: each beat atomic or further plan?
          → Planner: chapter → scenes (MECE dependency graph)
            → Scenes execute in parallel:
              [Drafter A | B | C | D] → 4 candidates
              → Aggregator selects / composes
              → Voice Keeper sentence audit
              → Character Voice validator
              → Editorial Critic + Beta Council (reception-weighted)
              → Voice Discriminator score
              → if fail: revise (counts toward EvoSkill trace)
              → if pass: continuity check
              → if pass: promote to scene-shippable
            → Aggregator rolls scenes into chapter
            → Continuity Watchkeeper full-chapter pass
          → Chapter promoted, wiki bible updated
        → Book draft assembled (first complete draft)
      → Developmental Editor full-draft structural audit
        → if structural fail: route back per §9.4
        → if pass: proceed
      → Line Edit pass
      → Proofread pass
      → Legal / Compliance gate (HUMAN approval required)
      → Provenance Manifest finalized + signed (Sigstore)
      → Watermark embedded (MarkLLM)
      → Cover / Blurb produced
      → Publication Operator ships
    → ** Reception Tier active **
      → Reviews scraped daily across all platforms
      → Reception Analyst classifies, routes signals
      → Reader Cohort Modeler updates persona weights
      → Skill registry updated with reception-derived patterns
      → Drafter D Phase 3 DPO refresh with new preference data
      → harbor reception probes expanded
    → Reception Brief assembled for next book
    → Audit log archived to WUPHF wiki
    → Series Director adjusts Book 2 plan with Reception Brief
```

Paperclip approval gates: outline lock, first-draft accept, structural audit pass, line-edit accept, legal clearance, publication.

---

## 13. Build Order

1. Pilot series concept + 10-novel inspiration corpus
2. Voice Profile extraction → wiki `voice/` (per BUNKO-VOICE-PROFILE-SCHEMA)
3. Paperclip company stood up, agents seeded
4. WUPHF wired, wiki skeleton in place
5. harbor eval suite assembled (slop + voice + structural + reception probes)
6. Voice Discriminator fine-tuned
7. Drafter D Phase 1 SFT
8. Developmental Editor agent stood up and validated
9. ROMA runtime for one chapter end-to-end (smoke test)
10. Provenance Manifest schema + Sigstore signing wired
11. OML fingerprint injection during Drafter D training
12. Book 1 with heavy human gating
13. EvoSkill loop processes Book 1 traces
14. Drafter D Phase 2 DPO
15. **Publication of Book 1 (whatever form: KDP, free download, beta readers)**
16. **Reception Tier activated — scrapers, Reception Analyst, Cohort Modeler**
17. **Reception Brief produced after ~30-60 days of review data**
18. **Drafter D Phase 3 DPO with reception-augmented preference data**
19. **Beta Council persona weights recalibrated**
20. Book 2 planning with Reception Brief
21. Book 2 with reduced human gating
22. By Book 3-4, approaching craft autonomy; human only at strategic + legal gates

---

## 14. Tooling Inventory

**Control / Collaboration / Execution planes:**
- Paperclip, WUPHF, ROMA

**Model & runtime:**
- LiteLLM gateway
- Anthropic Opus 4.7 / Sonnet 4.6 / Haiku 4.5
- OpenAI GPT-5
- Google Gemini 2.5 Pro
- xAI Grok
- Manus
- Qwen 2.5 / Llama 3.3 (local base models)
- vLLM (local inference serving)

**Fine-tuning:**
- Unsloth, Axolotl, Together AI

**Skill evolution & evaluation:**
- EvoSkill, harbor, Voice Discriminator

**Authenticity & provenance:**
- Sigstore / cosign, TUF, OML-1.0-Fingerprinting, MarkLLM, custom Provenance Manifest schema

**Research & search:**
- OpenDeepSearch, Manus

**Reception (NEW in v0.2):**
- Manus (primary scraper)
- Custom MCP wrappers (Amazon, Goodreads, StoryGraph, BookTok, Reddit)
- Reddit API / PRAW
- Grok (X)
- Composio Gmail
- Apify (commercial fallback)

**Infrastructure:**
- Sentient-Enclaves (confidential workloads)
- AWS GPU node (Drafter D hosting, fine-tuning)
- Edgewalker (dev, light training)

---

## 15. Deferred Gaps (revised)

| # | Gap | Deferral rationale |
|---|-----|--------------------|
| 2 | Audio narration | Distribution channel, separable |
| 3 | Cover art | Commercial wrap, separable |
| 4 | Marketing automation | Distribution, separable from production |
| 6 | Real-time platform policy monitor | Operational, not architectural |
| 10 | The "famous" gap (market dynamics) | Outside architecture's control surface |

Gap 5 (reader-feedback) is no longer deferred — addressed in §11.

---

## 16. Open Questions for v0.3

1. **Drafter D base model selection** — Qwen 2.5 32B vs Llama 3.3 70B vs Mistral Large. Bake-off on AWS GPU node.
2. **DPO vs ORPO vs KTO** for Drafter D Phase 2.
3. **Watermarking robustness budget** vs quality degradation.
4. **Synthetic voice transfer fair-use boundary** — legal opinion needed before Phase 1 SFT.
5. **Developmental Editor framework weighting** — Save the Cat vs McKee disagreement on inciting incident placement.
6. **OML fingerprint × platform anti-AI-detection interaction** — verify no commercial harm.
7. **Cross-series voice contamination** — separate LoRA per series, never re-tune.
8. **Beta Council weighting** by genre, ICP, book — likely per-series configuration.
9. **Scraper TOS exposure** — Amazon and Goodreads aggressively block. Apify or Bright Data as commercial fallback; consider whether scraping is sustainable or whether reception data ingestion needs a different model entirely (e.g., paid Goodreads partner data if available, or pivot to email/newsletter as primary reader-feedback channel).
10. **Reception data quality vs reader-base size** — for a new series, the first 100 reviews are noisy. When does the Reception Brief actually start carrying signal? Probably book 2 onwards.
11. **Cohort overfitting** — if the series attracts a narrow cohort, recalibrating Beta Council to that cohort risks losing broader appeal. Need a cohort-diversification check.

---

## 17. Non-Goals (Explicit)

- Bunko does not attempt to predict commercial success
- Bunko does not attempt to game discovery algorithms
- Bunko does not produce content outside its codified voice profile (cross-genre work requires a new series instance)
- Bunko does not operate without human approval gates at legal clearance and publication
- Bunko does not generate disclosed real-person fiction or licensed-IP fan fiction
- Bunko does not respond to individual reviews — reception is aggregate signal only
- Bunko does not engage with reviewers, reply on platforms, or attempt reputation management

---

*End of v0.2 second draft. Companion spec: BUNKO-VOICE-PROFILE-SCHEMA-v0.1.yaml*
