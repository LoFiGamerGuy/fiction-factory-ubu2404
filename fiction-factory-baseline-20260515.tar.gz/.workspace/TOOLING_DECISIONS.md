# Tooling Decisions — Pass #2

**Date:** 2026-05-15 (updated after user confirmation + broader research)  
**Phase:** 3 (implementation prep)  
**Gate:** User approval required before any Axis-B tool is installed.  
**Governing principle:** Local dev only for V1. Paid/hosted tools deferred unless opted in explicitly.

---

## Axis A — Claude / Dev Environment Tooling

| Tool | Decision | Rationale |
|---|---|---|
| **uv** (already installed) | ✅ Already done | Installed in Phase 0 per BCR. |
| **Python venv** (via `uv venv`) | ✅ Adopt | Create `uv venv .venv` in workspace root. Use `uv pip install` for deps. |
| **Anthropic SDK** | ✅ Adopt — V1 primary | Primary LLM provider per Starter spec + manus-agnostic ModelRouter. |
| **hookify plugin** | ✅ Adopt | Pre-commit hooks for schema validation, lint, mypy. |
| **pyright-lsp plugin** | ✅ Adopt | Python type checking LSP; complements mypy --strict. |
| **fewer-permission-prompts skill** | ✅ Run after first 10–15 implementation Bash calls | Build allowlist from actual implementation transcripts. |
| **mcp-server-dev plugin** | ⏭ Skip | Not exposing pipeline agents as MCP servers in V1. |
| **ralph-loop plugin** | ⏭ Skip | Convergence Controller handles iterative loops natively. |
| **atomic-agents plugin** | ⏭ Skip | Using Anthropic SDK + Instructor directly. |
| **claude-code-setup plugin** | ✅ Re-read recommendations | Already installed (Pass 1). Treat as advisory. |

### MCP servers — additions beyond Pass 1

| MCP | Decision | Use |
|---|---|---|
| **memory** (MCP knowledge graph) | ✅ Adopt | Persistent world-state / character facts without a full vector DB. Good complement to WUPHF wiki for agent-readable facts. |
| **filesystem** (MCP) | ✅ Adopt | Controlled read/write access for sandboxed subagents (scene drafts, spec files). |
| **git** (MCP) | ✅ Adopt | Agents can read diffs, commit scene files, check version history. Needed for WUPHF's git-backed wiki promotion. |
| **brave-search** (MCP) | 🔄 Defer | Research/fact-checking during world-building. Useful but not V1-critical. Revisit when a research sub-agent is scoped. |

### Claude Managed Agents / API capabilities to exploit

These are **Anthropic-native** features that reduce or eliminate the need for third-party infrastructure:

| Capability | Decision | Notes |
|---|---|---|
| **Claude Agent SDK subagents** | ✅ Adopt as primary multi-agent pattern | Native context isolation per agent role (writer/editor/critic/continuity). Each subagent returns only a summary; avoids context blowout on 80K-word runs. Design the pipeline around this pattern. |
| **Claude Managed Agents persistent memory** | ✅ Adopt (public beta) | Agents accumulate knowledge across sessions as filesystem-backed, auditable, rollback-capable notes. Eliminates need for an external memory store for session-level facts (character continuity, voice profile state). Beta header: `managed-agents-2026-04-01`. |
| **"Dreaming" feature** | 🧪 Watch (research preview) | Agents review past sessions to self-improve. Direct overlap with EvoSkill's use case. May reduce or eliminate the need to run EvoSkill separately. |
| **Files API** | ✅ Adopt | Upload and persist world bible, voice profile, character sheets by file ID. Agents reference by ID instead of re-injecting large docs every call. |
| **Message Batches API** | ✅ Adopt | 50% cost reduction, 300K `max_tokens` per batch (Opus 4.6/Sonnet 4.6). Use for: bulk scene generation, multi-pass editing, eval sweeps, nightly EvoSkill pass. |

---

## Axis B — Bundle-Cited Tools

### Adopt for V1

| Tool | Source | Decision | Rationale | Install |
|---|---|---|---|---|
| **Anthropic SDK** (`anthropic`) | Starter + manus-agnostic | ✅ Adopt | Primary LLM provider. | `uv pip install anthropic` |
| **OpenAI SDK** (`openai`) | MBSE + manus-agnostic | ✅ Adopt (test tier + optional) | gpt-4.1-mini as cheap test-tier model. | `uv pip install openai` |
| **Instructor** (`instructor`) | Research finding | ✅ Adopt — HIGH PRIORITY | Production-proven pydantic wrapper for Anthropic (3M+ monthly downloads, 11K stars). Handles validation retries and partial extraction. Wrap every Claude call through Instructor for schema enforcement instead of raw `response_format`. Eliminates the entire class of schema-compliance bugs. | `uv pip install instructor` |
| **pydantic** (v2) | Starter + manus-agnostic | ✅ Adopt | Runtime schema validation. Schema-as-contract (DEC-000-7). | `uv pip install pydantic` |
| **jsonschema** | Starter | ✅ Adopt | JSON Schema Draft 2020-12 canonical validation. | `uv pip install jsonschema` |
| **datamodel-code-generator** | Starter | ✅ Adopt | Generates pydantic models from JSON Schema. | `uv pip install datamodel-code-generator` |
| **pyyaml** | Starter | ✅ Adopt | Profile files are YAML; Voice Profile schema is YAML. | `uv pip install pyyaml` |
| **pytest** | Starter | ✅ Adopt | Test runner. | `uv pip install pytest pytest-cov` |
| **mypy** | Starter | ✅ Adopt | `mypy --strict`. Pre-commit hook. | `uv pip install mypy` |
| **ruff** | Starter | ✅ Adopt | Lint + format. | `uv pip install ruff` |
| **pre-commit** | Starter | ✅ Adopt | Hook framework. | `uv pip install pre-commit` |
| **SQLite** | Starter | ✅ Adopt | Calibration data store, all ledger event logs. stdlib. | stdlib |
| **scikit-learn** | Starter V1 ML | ✅ Adopt | Threshold calibration (O17), voice drift detection (O5), voice clustering (O22), Bayesian gap priors (O1). | `uv pip install scikit-learn` |
| **scipy** | Starter V1 ML | ✅ Adopt | Bayesian work, z-score drift detection. | `uv pip install scipy` |
| **sentence-transformers** | Starter V1 ML O23 | ✅ Adopt | Offline embeddings for comp-title retrieval + voice clustering. Runs locally. | `uv pip install sentence-transformers` |
| **numpy** | Transitive dep | ✅ Adopt | Transitive dep of scikit-learn. | `uv pip install numpy` |
| **BookNLP** (`booknlp`) | Research finding | ✅ Adopt — prerequisite | Speaker attribution for per-character dialogue extraction. Required for all 12 character_metrics fields in BookMetricsLedger. Berkeley/Bamman, trained on LitBank corpus, handles full-novel text, local model, no API. | `uv pip install booknlp` |
| **spaCy** (`spacy`) | Research finding | ✅ Adopt | POS tagging (modal verbs: MD tag), dependency parsing (imperative detection), sentence segmentation. Prerequisite for question_rate, exclamatory_rate, imperative_rate, modal_verb_rate, avg_word_length_chars. | `uv pip install spacy && python -m spacy download en_core_web_sm` |
| **NLTK** | Research finding | ✅ Adopt | Pronoun rate tokenization (first/second person pronoun rate). Also used in scanner.py. | `uv pip install nltk` |
| **lexicalrichness** | Research finding | ✅ Adopt | MTLD (Measure of Textual Lexical Diversity) — length-corrected vocabulary richness metric. | `uv pip install lexicalrichness` |
| **textstat** | Research finding | ✅ Adopt | Flesch-Kincaid grade level, and other readability metrics. | `uv pip install textstat` |
| **vaderSentiment** | Research finding | ✅ Adopt | Deterministic rule-based sentiment scoring (compound per utterance). No API calls. | `uv pip install vaderSentiment` |
| **faststylometry** | Research finding | ✅ Adopt | Burrows' Delta / function-word frequency profiling. Basis for function_word_vector and pairwise character-voice distinctiveness. | `uv pip install faststylometry` |
| **Ollama** | Bunko + user decision | ✅ Adopt — test tier | Free local models for integration testing. ModelRouter test tier maps here. | `curl -fsSL https://ollama.com/install.sh \| sh` then `ollama pull phi3.5` |
| **Mem0** (`mem0ai`) | Research finding | ✅ Adopt | Universal memory layer (52K stars, April 2026 token-efficient update). Self-hosted, local MCP mode. Use for: voice profile accumulated state, character facts between sessions, world-bible retrieval. Works alongside Claude Managed Agents persistent memory — Mem0 for semantic retrieval, CMA for structured session notes. | `uv pip install mem0ai` |
| **LangGraph** | Research finding (ROMA fallback → promote) | ✅ Adopt as PRIMARY state machine orchestrator | Now production-grade (1.0, Oct 2025). Used in production at Uber, JP Morgan. Built-in checkpointing + durable state. Maps directly onto scene lifecycle (Unspecced→Specced→DirtyDraft→NeedsReview→Approved→Final) as graph nodes. Use LangGraph for the state machine; use ROMA for the recursive decomposition reasoning layer. | `uv pip install langgraph` |
| **DeepEval** (`deepeval`) | Research finding | ✅ Adopt | 50+ built-in evaluation metrics. Supports custom metrics via LLM-as-judge (build `VoiceConsistencyMetric` backed by Claude scoring against voice profile). Use for: automated scene quality gates in CI, regression detection after model changes. | `uv pip install deepeval` |
| **Paperclip** (`paperclipai/paperclip`) | Bunko spec — CONFIRMED REAL (65.6K stars, MIT, updated daily) | ✅ Adopt | Control plane: company per series, budget tracking (monthly caps per agent), approval workflows (pause/resume/terminate), immutable audit ledger, heartbeat scheduling. Self-hosted. Model each fiction series as a Paperclip "company." | Docker compose from repo |
| **WUPHF** (`nex-crm/wuphf`) | Bunko spec — CONFIRMED REAL (~1K stars, MIT, daily releases) | ✅ Adopt | Collaboration plane: git-backed wiki (series bible), agent notebooks (private working memory), channels (production rooms), activity stream. Single Go binary. Self-hosted. Promoted notebook → wiki for permanent facts matches our series-bible pattern. | Binary from releases page |
| **ROMA** (`sentient-agi/ROMA`) | Bunko spec — CONFIRMED REAL (5.1K stars, Apache 2.0) | ✅ Adopt (with LangGraph as fallback) | Execution plane: recursive Atomizer/Planner/Executor/Aggregator/Verifier loop. Purpose-built for hierarchical task decomposition (series→book→act→chapter→scene→beat). Beta (v0.2.0, Oct 2025, slower cadence). Use ROMA for the recursive reasoning layer; LangGraph for the state machine layer. | `pip install roma-dspy` |
| **EvoSkill** (`sentient-agi/EvoSkill`) | Bunko spec — CONFIRMED REAL (749 stars, Apache 2.0, maintained) | ✅ Adopt (with adaptation) | Skill evolution from production traces. Adaption needed: redefine "failure trace" to include scenes where downstream critics score below threshold. Per-series namespace in EvoSkill's git-branch versioning = per-series skill library. Note: Claude Managed Agents "Dreaming" may overlap — if Dreaming reaches GA, evaluate whether EvoSkill is still needed or can be simplified. | `pip install evoskill` (or clone and install) |

### Model tiering configuration (per user decision 2026-05-15)

| Tier | Models | When |
|---|---|---|
| `test` | Haiku 4.5, gpt-4.1-mini, Ollama phi3.5 | All LLM calls during pipeline development and integration testing |
| `production` | Sonnet 4.6 (drafter), Opus 4.7 (nuanced critics), Haiku 4.5 (mechanical critics) | Only when architecture is stable and prose quality testing begins |

---

### Defer to V2

| Tool | Source | Reason |
|---|---|---|
| **LiteLLM** | Bunko | ModelRouter + Instructor covers multi-provider routing. Adding LiteLLM creates redundant layers. |
| **vLLM** | Bunko | GPU inference for Drafter D. V2 — requires GPU + fine-tuned Drafter D to exist first. |
| **Unsloth** | Bunko | Phase 1 LoRA SFT. V2 — needs calibration corpus + validation baseline first. |
| **Axolotl** | Bunko | Phase 2–3 DPO/ORPO/KTO fine-tuning. V2. |
| **Together AI** | Bunko | Managed fine-tuning fallback. Paid. V2. |
| **Gemini 2.5 Pro** | Bunko | Drafter C (1M context). V2 — expensive; ensemble deferred. |
| **GPT-5** | Bunko | Drafter B ensemble. V2. |
| **Grok** | Bunko | Beta personas, BookTok signal. V2. |
| **Qwen 2.5 32B / Llama 3.3 70B** | Bunko | Drafter D base model. V2 — needs fine-tuning infra first. |
| **Sigstore / cosign** | Bunko | Authorship signing. V2 — validate pipeline first. |
| **TUF** | Bunko | Signed release metadata. V2. |
| **OML-1.0-Fingerprinting** | Bunko | LoRA fingerprinting. V2 — only with Drafter D. |
| **MarkLLM** | Bunko | Text watermarking. V2. |
| **Sentient-Enclaves** | Bunko | Confidential computing. Hosted, expensive. V2 if needed at all. |
| **Manus** | Bunko | Reception scraping. We use Claude Code, not Manus. |
| **Apify / Composio / Reddit API / X API** | Bunko | Reception tier data collection. V2. |
| **Temporal** | Research finding | Durable execution engine. V2 — only if run length exceeds a single process lifetime. LangGraph checkpointing sufficient for V1. |
| **CrewAI Flows** | Research finding | Overlaps with LangGraph + ROMA. Evaluate in V2 if LangGraph proves insufficient. |
| **Graphiti/Zep** | Research finding | Temporal knowledge graph. Heavy; only if character-fact provenance tracking requires per-chapter timestamps at query time. Mem0 + CMA persistent memory handles V1. |
| **Prefect** | Research finding | Batch workflow orchestration. Consider for nightly EvoSkill / eval sweep runs. V2. |
| **llm-stylometry** | Research finding | Cross-entropy authorship attribution for voice consistency. Research-level; build-it-yourself integration. V2 once production prose exists to evaluate. |
| **harbor** (Bunko eval) | Bunko | Build on DeepEval + pytest + fixture corpus for V1. harbor is V2 at production scale. |
| **Voice Discriminator** (Bunko) | Bunko | Local fine-tuned classifier. V2 — structural_analysis.py covers V1; full discriminator needs fine-tuning data. |
| **Outlines / XGrammar** | Research finding | Constrained decoding. Only for local inference models. Not applicable to Anthropic API path. |
| **Brave-search MCP** | Research finding | Deferred — useful for fact-checking subagent; not V1 critical. |
| **ML opportunities O3, O4, O6–O16, O18–O21, O24–O31** | Starter | 26 of 31 ML opportunities deferred per Starter's V1 scoping. |

---

## Summary — V1 install plan

Once user approves this table, before Phase 4 implementation begins:

```bash
# Virtual environment
uv venv .venv && source .venv/bin/activate

# Core LLM + schema enforcement
uv pip install anthropic openai instructor pydantic jsonschema datamodel-code-generator pyyaml

# Testing + quality
uv pip install pytest pytest-cov mypy ruff pre-commit deepeval

# Orchestration + state machine
uv pip install langgraph roma-dspy

# Memory
uv pip install mem0ai

# ML (V1 scope)
uv pip install scikit-learn scipy sentence-transformers numpy

# Pre-commit hooks
pre-commit install

# Ollama (test tier local models)
curl -fsSL https://ollama.com/install.sh | sh && ollama pull phi3.5

# Paperclip (control plane) — Docker
# WUPHF (collaboration) — binary from releases
# EvoSkill — pip install evoskill (or clone sentient-agi/EvoSkill)
# ROMA — pip install roma-dspy

# Character metrics + speaker attribution (BookNLP + supporting)
uv pip install spacy nltk lexicalrichness textstat vaderSentiment faststylometry booknlp
python -m spacy download en_core_web_sm
```

---

## Open questions (resolved)

✅ Paperclip / WUPHF / ROMA / EvoSkill — all confirmed real open-source tools.  
✅ EvoSkill — adopt with fiction-domain trace adaptation.  
✅ ROMA — adopt as recursive reasoning layer; LangGraph as state machine layer.