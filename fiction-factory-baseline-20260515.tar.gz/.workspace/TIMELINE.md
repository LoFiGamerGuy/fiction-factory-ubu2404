# Document Timeline — Three-Bundle Review

**Purpose:** Establish the production order of living documents so stakeholder positions are read in the order they were taken, not filesystem order. This drives Phase 2.2 reading order.

**Date of reconstruction:** 2026-05-14 (Phase 2.1.5)

---

## Bundle-level relative ordering

All three bundles share the same nominal date (2026-05-12) — the file mtimes reflect extraction date (2026-05-14), not creation date. Absolute ordering between bundles cannot be determined from date alone.

**Inferred relative ordering based on maturity and cross-references:**

| Rank | Bundle | Basis |
|---|---|---|
| 1 (earliest) | **MBSE** | Only bundle with working Python code; went through a full design → review → acceptance → closure → Phase 0A cycle within 2026-05-12. Represents a completed iteration. |
| 2 (concurrent or later) | **Bunko v0.1** | Spec-only, no code. References systems (Paperclip, WUPHF, ROMA) not present in MBSE, suggesting a parallel or subsequent design stream. |
| 3 (latest within Bunko) | **Bunko v0.2** | Explicitly supersedes v0.1 (2026-05-12). Reception Tier added. |
| Uncertain | **Starter** | Spec-only, no code. No cross-references to MBSE or Bunko. May be concurrent with either. Contains Ryan's name (`Working with the human — Ryan`) suggesting same author. |

**Synthesis implication:** Bunko v0.2 is the most recent Bunko document; Starter is the most architecturally complete spec (Universal Core ontology, pre-locked decisions, task backlog). MBSE has the only working code.

---

## MBSE bundle — internal chronological sequence

All events dated 2026-05-12. Ordering established from internal references and document narrative.

### Tier 1 — Design (no external input)
| Order | Document | Internal date | Notes |
|---|---|---|---|
| 1 | `MBSE_Fiction_Decomposition.md` / `Model-Based Systems Engineering (MBSE) Decomposition of a Fiction Series.md` | 2026-05-12 | Phase 1 — structural decomposition (two revisions) |
| 2 | `Fiction Factory: MBSE System Specification.md` | 2026-05-12 | Phase 2 — RTM, 23 requirements |
| 3 | `Fiction Factory: Requirements Traceability Matrix (RTM).md` | 2026-05-12 | Phase 2 — RTM output, 3 critical gaps identified |
| 4 | `Fiction Factory: Artifact Registry & Asset Database.md` | 2026-05-12 | Phase 2 — asset inventory |
| 5 | `Agent Segregation Design — mbse-fiction-factory.md` | 2026-05-12 | Phase 5 — segregation design (pending review; later SUPERSEDED) |
| 6 | `Agent_Segregation_Design_SUPERSEDED.md` | 2026-05-12 | Stub marking original design superseded |
| 7 | `00_MASTER_BRIEFING.md` | 2026-05-12 | Assembled at decision gate — "awaiting review before implementation" |

### Tier 2 — Review preparation
| Order | Document | Internal date | Notes |
|---|---|---|---|
| 8 | `Engineering Review Request — Fiction Factory MBSE System.md` | 2026-05-12 | Formal request for external review |
| 9 | `Craft_Review_Request.md` | 2026-05-12 | Craft SME review request |
| 10 | `The Ideal SME for the Fiction Factory MBSE Review.md` | 2026-05-12 | Reviewer selection criteria |
| 11 | `The Ideal Craft SME — Romance…` | 2026-05-12 | Romance SME persona spec |
| 12 | `The Ideal Craft SME — Literary Fiction or Thriller Track.md` | 2026-05-12 | Thriller SME persona spec |
| 13 | `Craft_SME_Persona_Romance.md` | 2026-05-12 | Instantiated Romance SME persona |
| 14 | `Craft_SME_Persona_Literary_or_Thriller.md` | 2026-05-12 | Instantiated Thriller/Literary SME persona |

### Tier 3 — Reviews received
| Order | Document | Internal date | Notes |
|---|---|---|---|
| 15 | `Craft Review #1 — Manus Analysis.md` | 2026-05-12 | Romance/commercial-fiction SME via Manus; "awaiting Craft Review #2" |
| 16 | `Fiction_Factory_Review_Dr_Smith.md` | 2026-05-12 | Dr. Smith independent technical review |
| 17 | `fiction_factory_formal_review_memo_2026-05-12.md` (in nested _Memo_Author zip) | 2026-05-12 | Formal Review Memo Author |
| 18 | `Craft_Review_Response_Romance_Vantage_2026-05-12.md` | 2026-05-12 | Romance Vantage SME response |
| 19 | `Craft_Review_Response_Thriller_Vantage_2026-05-12.md` | 2026-05-12 | Thriller/Literary Vantage SME response |
| 20 | `Craft_Review_Response_Claude_2026-05-12.md` | 2026-05-12 | Claude review response |
| 21 | `Craft Reviews Combined Analysis.md` | 2026-05-12 | Synthesis of all craft reviews |
| 22 | `Craft Review #2 — Preservation Note.md` | 2026-05-12 | Preserved as "successful failure mode" — no acceptance weight |

### Tier 4 — Plan of Record and acceptance
| Order | Document | Internal date | Notes |
|---|---|---|---|
| 23 | `Reviewer Response and Revised Plan of Record.md` | 2026-05-12 | **ACCEPTED** — supersedes Agent_Segregation_Design.md; key synthesis of all reviews |
| 24 | `Craft Reviews Acceptance — Plan of Record.md` | 2026-05-12 | **BINDING** for Phase 1 schema work; supersedes any prior genre-agnostic claims |

### Tier 5 — Closure and Phase 0A
| Order | Document | Internal date | Notes |
|---|---|---|---|
| 25 | `Closure Note — Dr. Smith.md` | 2026-05-12 | Formal closure with Dr. Smith |
| 26 | `Closure Note — Formal Review Memo Author.md` | 2026-05-12 | Formal closure with Memo Author |
| 27 | `BASELINE_REPORT.md` | 2026-05-12 | Pre-Phase-0A baseline check; confirmed bugs real; 6/16 modules import clean |
| 28 | `Phase 0A Status — Foundation Complete, Migration Pending.md` | 2026-05-12 | Phase 0A foundation complete; migration of existing agents pending |
| 29 | `RESUME — Fiction Factory Phase 0A Migration.md` | 2026-05-12 | Guidance for continuing Phase 0A migration in fresh session |
| 30 | `Bundle Manifest — Fiction Factory Phase 0A Handoff.md` | 2026-05-12 | Final deliverable index for handoff |

### Supersession map (what overrides what)
| Superseded | Current / Canonical |
|---|---|
| `Agent Segregation Design — mbse-fiction-factory.md` | `Reviewer Response and Revised Plan of Record.md` (per its status field) |
| `Agent_Segregation_Design_SUPERSEDED.md` | Same |
| Any prior genre-agnostic claims | `Craft Reviews Acceptance — Plan of Record.md` §1 positioning statement |

---

## Starter bundle — internal chronological sequence

No internal versioning dates. All docs appear to be authored in a single design pass.

| Order | Document | Notes |
|---|---|---|
| 1 | `DECISIONS.md` | 7 pre-locked standing decisions; no dated entries yet (empty "Decisions" section) |
| 2 | `docs/core-ontology-v3.md` | Entity definitions; "v3" = third revision of ontology (prior versions not present) |
| 3 | `docs/profile-axis-framework-v2.md` | "v2" = second revision; V1 pentad confirmed, Tier-1 candidates primed |
| 4 | `docs/ml-opportunity-analysis-v2.md` | "v2" — 31 opportunities; 5 V1 scope |
| 5 | `IMPLEMENTATION_PLAN.md` | 17-phase sequential plan; Phase 0 not yet started |
| 6 | `tasks/task-001-foundation.md` through `task-003-first-profiles.md` | Authored; task-001 through 003 represent first 3 phases |
| 7 | All other docs | Consistent with plan; CLAUDE.md, README, etc. are reference documents |

**Note:** "v3" and "v2" versioning indicates prior drafts of the ontology and framework existed elsewhere, but only the current versions are present in this bundle.

---

## Bunko bundle — internal chronological sequence

| Order | Document | Notes |
|---|---|---|
| 1 | `BUNKO-ARCH-001-v0.1.md` | 2026-05-12. First draft; 4 principles; no Reception Tier |
| 2 | `BUNKO-VOICE-PROFILE-SCHEMA-v0.1.yaml` | 2026-05-12. Voice profile schema (companion to v0.1/v0.2) |
| 3 | `BUNKO-ARCH-001-v0.2.md` | 2026-05-12. **Current**. Reception Tier added (§11); supersedes v0.1 |

---

## Reading order for Phase 2.2 (stakeholder docs)

Read in this order to follow the narrative arc of design decisions:

1. `Craft Review #1 — Manus Analysis.md` (Tier 3, first review)
2. `Fiction_Factory_Review_Dr_Smith.md` (Tier 3, technical review)
3. The Formal Review Memo (in nested Memo_Author zip)
4. `Craft_Review_Response_Claude_2026-05-12.md` (Tier 3, Claude response)
5. `Craft_Review_Response_Romance_Vantage_2026-05-12.md` (Tier 3, Romance SME)
6. `Craft_Review_Response_Thriller_Vantage_2026-05-12.md` (Tier 3, Thriller SME)
7. `Reviewer Response and Revised Plan of Record.md` (Tier 4 — KEY: first binding synthesis)
8. `Craft Reviews Acceptance — Plan of Record.md` (Tier 4 — binding genre positioning)
9. `Closure Note — Dr. Smith.md` (Tier 5)
10. `Closure Note — Formal Review Memo Author.md` (Tier 5)
