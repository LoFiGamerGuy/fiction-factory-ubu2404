# Manus Archive Triage — Summary (post-scrub)

Per [BCR manus-archive-triage](../../.claude/plans/in-this-folder-you-deep-toast.md#baseline-change-request--2026-05-14--manus-archive-triage).

The detailed per-file `MANUS_TRIAGE_REPORT.md` was scrubbed on 2026-05-14 per user directive: "remove any lingering memory or context related to those books or authors." This summary preserves the audit-trail facts without retaining project/author identifiers.

## Final disposition

| Bucket | Count | Disposition | Location |
|---|---|---|---|
| **A — project-agnostic** | 111 | Reviewed in Phase 2 | `.workspace/manus-agnostic/` |
| **B — templates + methodology with embedded examples** | 30 | Reviewed in Phase 2 with sanitization rule | `.workspace/manus-templates-needs-sanitization/` |
| **C — project-specific contamination** | 214 | **Deleted** | originally `.workspace/bundles/mbse/_nested/2359-…/` (15 MB) |
| Total processed | 355 | | |

## Verification

- 7 files initially unmatched by automatic regex were verified C by content inspection.
- 1 duplicate B entry cleaned up (em-dash vs hyphen variant of same filename).
- Disk counts at end of triage matched report counts: 111 / 30 / 214.

## Bucket A composition (high-level)

- ~67 Python files: pipeline + ~18 specialist agents (writer, editors, proofreader, ARC reader variants, drift detector, etc.) + utilities (validators, trackers, scorers, scanners, formatters)
- ~21 TSX/TS files: React dashboard shell (Pipeline*, App, Admin, Series, SeriesBible, ARC, etc.)
- ~9 architecture docs
- ~7 config/schema files

## Bucket B composition (high-level)

- 8 numbered KDP workflow templates
- ~12 methodology docs (voice analysis, ARC personas, KDP metadata, etc.)
- ~5 generic-named templates (chapter_index, continuity_tracker, etc.)
- 3 genre-specific methodology docs (romance / erotic romance / sub-genre)

## What Bucket C contained (de-identified)

Three+ separate book-or-platform projects' worth of operational content: full manuscripts in multiple revisions, all chapter content, named ARC reader personas + their reports, character bibles, series concepts, marketing copy, manuscript versioning artifacts, author response reports, project-specific Python scripts (one-shot fixes, backfills, sprint-runners), and pipeline-version test/diagnostic outputs.

## Source-of-truth note

The original Manus inner zip is still preserved inside the MBSE top-level outer zip (the committed baseline at workspace root). If a Bucket C item is ever needed, it can be retrieved by re-extracting the outer zip. The plan and CLAUDE.md document that this inner zip is intentionally not re-extracted.
