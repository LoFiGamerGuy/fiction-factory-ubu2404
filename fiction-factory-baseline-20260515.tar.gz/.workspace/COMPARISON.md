# Bundle Comparison Matrix

**Purpose:** Compare the three bundles across all dimensions from plan §2.3. Every cell cites the bundle's own definition (anti-vocabulary-collision rule). Manus-agnostic code treated as a fourth column where it adds information beyond the MBSE top-level.

**Date:** 2026-05-14 (Phase 2.3)  
**Bundles:** MBSE (`.workspace/bundles/mbse/`), Starter (`.workspace/bundles/starter/`), Bunko (`.workspace/bundles/bunko/`), Manus-Agnostic (`.workspace/manus-agnostic/`)

---

## 1. Scope / Target Genre

| | MBSE | Manus-Agnostic | Starter | Bunko |
|---|---|---|---|---|
| **Stated scope** | "Currently optimized for emotionally driven commercial fiction, with its initial ontology validated against contemporary and erotic romance. The architecture is intended to be genre-extensible, but each genre requires its own validated craft module." (`Craft Reviews Acceptance — Plan of Record.md` §1) | Same as MBSE top-level (same project); manus-agnostic appears to be the operational V3 of the same system | "V1 targets contemporary romance (US market), with architecture designed to generalize to other genres." (`README.md`). Universal Core is explicitly genre-agnostic; genre profiles parameterize genre-specific behavior. | "Architecture for automated writing and publication of multi-book novel series at quality indistinguishable from human-authored work." (`BUNKO-ARCH-001-v0.2.md` §0). Bunko-specific; "one instance per novel series" — series as the unit. |
| **Genre-agnostic claim** | Aspirational; craft reviews falsified the claim for current v1. Must add validated genre module per genre. | Same | Explicitly claimed for Universal Core; genre profiles provide per-genre adaptation. Sensitivity Profile as sacred threshold is genre-agnostic. | Not claimed. Bunko is a family of instances (one per series). Genre is implicit in VoiceProfile + DrAfter D LoRA. |
| **Initial validated genre** | Romance (contemporary / erotic) | Same | Contemporary romance (US KDP market) | Not specified (series-specific) |
| **Second-genre status** | Thriller v0.1 scaffold only; validation deferred | Same | Genre Profile parameter; any genre can define a profile | N/A (series-by-series) |

---

## 2. Architecture Style

| | MBSE | Manus-Agnostic | Starter | Bunko |
|---|---|---|---|---|
| **Paradigm** | MBSE-formal: hierarchical decomposition (SysML diagrams, RTM, ICDs), pipeline as a 7-step sequence, gate-driven | Refactored MBSE pipeline: job_runner + editorial_pipeline factored from monolithic orchestrator; ModelRouter abstraction over LLM providers | Profile-composed, schema-validated, fully autonomous between two human gates (spec + review). Convergence Controller (GO / REVISE / RE-PLAN / FORCE-RESOLVE). | Multi-plane: Control (Paperclip), Collaboration (WUPHF), Execution (ROMA). Ensemble drafting across heterogeneous models (A/B/C/D drafter). Reception loop. Three tiers: Strategy / Production / Adversarial. |
| **Agent topology** | 8 pipeline agents: SpecValidatorAgent → WriterAgent → EditorAgent → QualityAgent → ContinuityAgent → InjectorAgent → BookStructuralVerifier → PublisherAgent | Same 8 + 9 additional specialist agents: arc_reader_agent, arc_reader_packet_agent, drift_detector_agent, developmental_editor_agent, line_editor_agent, copy_editor_agent, proofreader_agent, genre_norm_editor_agent, revision_agent | Not implemented yet; plan specifies: Drafter (LLM), Critic Ensemble (7 critics), Reception Ensemble (reader personas), Continuity Guardians (Bible Steward + Loop Tracker), Convergence Controller | World Architect, Series Director, Outliner, Atomizer, Drafter A/B/C/D, Aggregator, Voice Keeper, Line Editor, Developmental Editor, Copy Editor, Proofreader, Editorial Critic, Beta Reader Council (7 personas), Voice Discriminator, Reception Analyst, Reader Cohort Modeler |
| **Orchestration** | `orchestrator.py` (682 lines): sequential pipeline; human-in-the-loop at dirty-draft checkpoint; `--validate-spec`, `--init-book`, `--job`, `--resume`, `--verify-book`, `--book-publish` commands | `orchestrator.py` (181 lines thin CLI) → `job_runner.py` (pipeline) + `editorial_pipeline.py` (agent calls) | Convergence Controller (fully autonomous inner loop); two human gates: spec authoring + post-run review. No inner-loop human gates. | Paperclip (control plane: approval, budgets, audit trail) + WUPHF (collaboration: wiki, channels) + ROMA (execution: recursive decomposition) |
| **Human-in-the-loop** | Yes: human review gate at dirty-draft checkpoint; series spec populated by human before run | Same | No: fully autonomous between spec and review. "No per-scene human gates and we do not intend to add any." (`CLAUDE.md`) | Limited: approval gates (Paperclip), but production loop is autonomous. Final: post-book publication review not specified. |

---

## 3. Schema Strategy

| | MBSE | Manus-Agnostic | Starter | Bunko |
|---|---|---|---|---|
| **Schema approach** | JSON: series_spec.json, book_spec.json, character_cards.json, scene_spec.json + 4 ICD files. JSON Schema under `schemas/v1/` (per Phase 0B plan; not yet implemented in current code — B4/B5 class of bugs). | Same JSON specs; `SceneJob` Pydantic model added for runtime. Not yet JSON Schema–backed canonically. | JSON Schema Draft 2020-12 as canonical; Pydantic models generated from schemas. "Schemas are the contract; every component validates input/output." (DEC-000-7, DECISIONS.md) | YAML voice profile schema (BUNKO-VOICE-PROFILE-SCHEMA-v0.1.yaml). Architecture docs define structure. No formal JSON Schema–backed pipeline specs. |
| **Primary schema entities** | series_spec, book_spec, character_cards, scene_spec, 4 ICD schemas | SceneJob (Pydantic), ContextBundle, VoiceProfile | voice_axes, structural_hierarchy, continuity_model, promise_ledger, ai_tell_catalog, specificity_heuristics, convergence, plus 7 profile schemas | VoiceProfile YAML: 15 sections (sentence metrics, lexical, syntactic, dialogue, sensory, pacing, metaphor, subtext, cadence, forbidden constructions, enforcement, calibration, corpus, relationships) |
| **Ontology depth** | Series → Book → Act → Sequence → Chapter → Scene → Beat → Paragraph → Sentence → Word (10 levels). Style/rhythm/grammar are interfaces between levels, not structural components. | Same | Series → Book → Part/Act → Chapter → Scene → Beat (6 levels). Richer entity model: Character, Location, Object, Concept, Faction, Timeline tracked in Bible. Promise Ledger tracked per-book. | Series → Book → Act → Chapter → Scene → Beat → Paragraph → Sentence (8 levels). Atomizer decomposes beats further. |
| **Profile / axis system** | Voice profile only; quality config; agent overlays (design in docs, not in code yet) | VoiceProfile data class (data-driven JSON config) | 5 primary profiles (Author × Genre × Audience × Goal × Sensitivity). 6 auxiliary profiles. Conflict precedence: Constraint > Sensitivity > Goal > Genre > Audience > Author > Universal. | Voice Profile per series + Reader Profile (reception tier). No multi-axis composition framework. |

---

## 4. Voice/Style Approach

| | MBSE | Manus-Agnostic | Starter | Bunko |
|---|---|---|---|---|
| **Voice representation** | `quantifiable_metrics.md`: no-fly list (regex scan), stylometric targets (word count, act proportions, scene count, em-dash density, burstiness), voice exemplar pool (2 per call, 200–400w window, 3-tier source hierarchy). VoiceExemplarManager spec in docs; not yet in code. | VoiceProfile dataclass: data-driven JSON with author_persona, voice_bible, voice_exemplars, genre_instructions, heat_level; replaces hardcoded AUTHOR_PERSONA string in MBSE | Author Profile (voice axis YAML): sentence-level metrics, lexical constraints, structural prose, punctuation, cadence, modality, POV craft. Measured on output; source prose discarded. No prose retention. | BUNKO-VOICE-PROFILE-SCHEMA-v0.1.yaml: 15 sections, per-paragraph enforcement, weighted scoring, forbidden constructions with regex, dialogue per-character deltas, sensory register, metaphor family management, calibration history |
| **No-fly / AI-tell defense** | `scanner.py`: NoFlyScanner (regex, phrase list in JSON). `structural_analysis.py`: structural AI-tell detection. | Same scanner; adds VoiceProfile-driven forbidden construction check | AI-Tell Catalog (§6 of ontology): pattern catalog with severity 1–5. Deterministic pattern checking. Four additions from MBSE craft reviews (triple restatement, abstract emotion-labeling, "It is X a Y", prose explaining itself). | `forbidden_constructions` section of VoiceProfile schema with severity (high/medium/low) and regex patterns. Voice Discriminator (local fine-tuned classifier: Qwen 2.5 7B base, labels human vs AI prose, scores 0–1 per paragraph) |
| **Voice drift protection** | ICD-03 §2.3: prose anchor (last 500w of previous scene) at high-priority prompt position. Exemplar pool curated against Register 2 (AI-tell register). | ContextManager: three-tier (scene/book/series) context assembly with explicit size limits | VoiceExemplarManager (plan): provenance tracking, collapse detector, hard invariant against auto-add of generated content. Drift anomaly detection (ML opportunity O5). | VoiceProfile calibration_history (auto-appended by Reader Cohort Modeler). VoiceKeeper agent enforces per-paragraph. Drift alert at 10% threshold. |
| **Multi-model/ensemble** | Single model: `gpt-4.1-mini` (OpenAI). No ensemble. | Single model per task via ModelRouter; multi-provider but not ensemble per scene. | Single model per component role (Sonnet for drafter, Opus for critics, Haiku for mechanical critics). Not ensemble per se — different models for different roles. | 4-model drafter ensemble (Drafter A/B/C/D: Sonnet, GPT-5, Gemini 2.5 Pro, fine-tuned local Qwen/Llama). Aggregator selects best scene-level output. |

---

## 5. Governance & Craft-Review Process

| | MBSE | Manus-Agnostic | Starter | Bunko |
|---|---|---|---|---|
| **Review track** | Two-track: (1) Engineering review (Dr. Smith + Formal Review Memo Author) → Reviewer Response (architecture decisions); (2) Craft review (Romance SME + Thriller SME) → Craft Reviews Acceptance (genre module architecture, schema changes). Both tracks converged on 2026-05-12. | Same project; post-Phase-0A iteration | DECISIONS.md (append-only, DEC-NNN format). 7 pre-locked standing decisions. No external review process documented. | harbor eval suite (held-out test sets, ratcheting probes). EvoSkill (skill extraction from traces). No documented human review process. |
| **Decision governance** | Plan of Record (`Reviewer Response and Revised Plan of Record.md`) is binding. Craft Reviews Acceptance is binding. "Heavier-weight, more robust from the start" is the posture. | Inherits MBSE governance | 7 pre-locked decisions. Append-only decision log. "Schemas are the contract." | Not specified. Architecture doc (v0.2) is binding. Build order is the plan. |
| **Release gate** | Permanent: line-editor-in-the-loop required before any book is marked release-ready. Human gate at spec and at release — NOT per-scene. | Same | No inner-loop gates. Human gates at: (1) pre-run spec, (2) post-run review. | Approval gates via Paperclip (output-lock, legal gate). Human review not explicitly specified per book. |

---

## 6. Code Maturity

| | MBSE top-level | Manus-Agnostic | Starter | Bunko |
|---|---|---|---|---|
| **Code exists?** | Yes | Yes | No (spec only) | No (spec only) |
| **Lines** | ~5,350 Python + ~2K TSX/TS | ~19,500 Python | 0 | 0 |
| **Files** | 42 .py + 8 .tsx | 69 .py + 21 .tsx/ts | 0 code | 0 code |
| **Maturity estimate** | ~60% | ~85% | 0% (pre-implementation) | 0% (pre-implementation) |
| **Key working components** | orchestrator.py (682 lines, comprehensive); editor_agent, quality_agent, scanner, structural_analysis all working | Same + ModelRouter (multi-provider), VoiceProfile (data-driven), ContextManager (3-tier), 9 additional specialist agents, cost tracking | n/a | n/a |
| **Key gaps / bugs** | generator.py: module-scope OpenAI client (blocks import without API key). Agent constructors inconsistent. InjectorAgent and PublisherAgent are stubs. No JSON Schema backing (B4/B5 class). VoiceExemplarManager not implemented. Agent views / Context Packs not implemented. | Largely resolves MBSE top-level bugs (lazy init, data-driven config). ContextPackBuilder / overlay system: in docs/design, implementation status unclear from sample read. | All of it (Phase 0 not started) | All of it (no code) |
| **LLM dependency** | OpenAI API only (gpt-4.1-mini hardcoded) | Multi-provider: OpenAI, Anthropic, xAI, Ollama, Manus via ModelRouter | Anthropic SDK specified (Sonnet drafter, Opus critics, Haiku mechanical) | Multi-provider: Anthropic (Opus 4.7, Sonnet 4.6, Haiku 4.5), OpenAI (GPT-5), Google (Gemini 2.5 Pro), Grok, local (Qwen/Llama via vLLM) |
| **Test coverage** | `--validate-spec` works. Smoke test harness (Phase 0A item S-0A-09) planned, unclear if implemented. | Unknown from sample read | 0% (no code yet; task-001 includes smoke test setup) | 0% (no code, harbor eval planned) |

---

## 7. Stated Phase / Readiness

| | MBSE | Manus-Agnostic | Starter | Bunko |
|---|---|---|---|---|
| **Stated phase** | Phase 0A partially complete (foundation done, agent migration pending). Phase 0B + Phase 1 (canonical schemas) planned. Phase 3 (agent views + context packs) planned. | Post-Phase-0A V3; appears to be a more complete iteration addressing MBSE's Phase 0A goals | Phase 0 not started (task-001 the first task). 17-phase plan, estimated 4–6 months to V1. | Build order step 1–6 (local dev stack) not started. Phases 1–3 (fine-tuning, harbor, reception) represent significant infra work. |
| **Blocking items before next phase** | Import bug in generator.py; agent constructor migration; canonical schemas (Phase 0B) | Unknown; likely some integration gaps in edge cases | Task-001 (repo scaffold): 2–4 hours. Nothing implemented yet. | Drafter D base model selection (Qwen vs Llama vs Mistral). Fair-use legal opinion (gates Phase 1 SFT). Paperclip/WUPHF/ROMA: custom infra, unclear if open-source. |
| **Production readiness estimate** | Months away; core loop works but infrastructure incomplete | Months away; significantly closer than MBSE top-level | 5–6 months to first production scene; relies entirely on clean-slate implementation | 1+ year to full Bunko stack; subset MVP possible in weeks without fine-tuning or reception tier |

---

## 8. Smallest Runnable Artifact

| | MBSE | Manus-Agnostic | Starter | Bunko |
|---|---|---|---|---|
| **Entry point** | `orchestrator.py` | `orchestrator.py` → `job_runner.py` | None yet | None yet |
| **Path to first scene** | (1) Populate 4 JSON spec files from templates; (2) `python3 orchestrator.py --validate-spec ...`; (3) Create scene job JSON; (4) `python3 orchestrator.py --job scene_job.json` (requires `OPENAI_API_KEY`). **Blocker**: must fix generator.py module-scope client first. | Same path but with `ANTHROPIC_API_KEY` or `OPENAI_API_KEY` per model_router.json config. Fewer import bugs. | Execute task-001 (repo scaffold, 2–4h) → task-002 (schemas, 4–6h) → Phase 6 (end-to-end scene generation). First executable scene: weeks away. | Implement Voice Keeper + single Drafter + Editorial Critic + WUPHF wiki stub + Paperclip stub. 1 chapter end-to-end. Estimated 4 weeks. No fine-tuning, no reception loop, no watermarking needed for MVP. |
| **Dependencies** | OpenAI API key; Python 3.9+; 4 JSON spec files; orchestrator.py + 10 agent files + 4 module files | Anthropic API key (or OpenAI); Python 3.9+; model_router.json; voice_profile.json | Anthropic API key; Python 3.11+; pyproject.toml (to be created in Phase 0) | Anthropic SDK (Opus 4.7, Sonnet 4.6); Python 3.x; basic WUPHF git wiki; no GPU needed for MVP |

---

## 9. Bundle-Cited Tooling Inventory

### Core runtime dependencies (required for V1)

| Tool | MBSE | Manus-Agnostic | Starter | Bunko |
|---|---|---|---|---|
| Python | 3.9+ | 3.9+ | 3.11+ (strict) | unspecified |
| Anthropic SDK | ✗ (OpenAI only) | ✓ (via ModelRouter) | ✓ (primary) | ✓ (Opus 4.7, Sonnet 4.6, Haiku 4.5) |
| OpenAI SDK | ✓ (gpt-4.1-mini, hardcoded) | ✓ (via ModelRouter) | Via embeddings API (optional) | ✓ (GPT-5 as Drafter B) |
| pydantic | Planned (Phase 0B) | ✓ (SceneJob) | ✓ (primary validation) | not specified |
| JSON Schema | Planned (Phase 0B) | Partial | ✓ (canonical; Draft 2020-12) | ✓ (YAML schema; same concepts) |
| pytest | Planned | Unknown | ✓ (core requirement) | harbor (own eval) |
| mypy + ruff | Planned | Unknown | ✓ (mypy --strict) | not specified |

### Deferred / heavy stack (V2+ or commercial)

| Tool | Bundle | Category | Local? | Cost |
|---|---|---|---|---|
| LiteLLM | Bunko | LLM routing gateway | Yes | free |
| vLLM | Bunko | Local inference serving for Drafter D | Yes | free + GPU |
| Unsloth | Bunko | Phase 1 fine-tuning (LoRA SFT) | Yes | free + GPU |
| Axolotl | Bunko | Phase 2–3 fine-tuning (DPO/ORPO/KTO) | Yes | free + GPU |
| Together AI | Bunko | Managed fine-tuning fallback | Hosted | $ |
| Manus | Bunko | Reception scraping, autonomous browse | Hosted | $ |
| Apify | Bunko | Commercial scraping fallback | Hosted | $$ |
| Composio Gmail | Bunko | Email reception ingestion | Hosted | $ |
| Paperclip | Bunko | Control plane (approvals, budgets, audit) | Unknown | Unknown |
| WUPHF | Bunko | Collaboration plane (wiki, channels) | Unknown | Unknown |
| ROMA | Bunko | Execution plane (recursive decomp) | Unknown | Unknown |
| Sigstore/cosign | Bunko | Cryptographic signing (authorship attestation) | Yes | free |
| TUF | Bunko | Signed release metadata | Yes | free |
| OML-1.0-Fingerprinting | Bunko | LoRA weight fingerprinting | Unknown | Unknown |
| MarkLLM | Bunko | Text watermarking (steganographic) | Yes | free |
| Sentient-Enclaves | Bunko | Confidential workloads | Hosted | $$ |
| AWS GPU node | Bunko | vLLM serving, fine-tuning | Hosted | $$ |
| scikit-learn | Starter | ML (regression, clustering) | Yes | free |
| scipy | Starter | Bayesian work, stats | Yes | free |
| sentence-transformers | Starter | Offline embeddings | Yes | free |
| SQLite | Starter | Calibration data store | Yes | free |
| EvoSkill | Bunko | Skill discovery from traces | Unknown | Unknown |
| harbor | Bunko | Eval suite (ratcheting probes) | Unknown | Unknown |
| Gemini 2.5 Pro | Bunko | World Architect, Drafter C (1M context) | API | $ |
| Grok | Bunko | Beta personas, BookTok signal | API | $ |
| Qwen 2.5 32B | Bunko | Drafter D base model | Self-hosted | free + GPU |
| Llama 3.3 70B | Bunko | Alt Drafter D base (multi-GPU) | Self-hosted | free + GPU |

### Key adoption decision: Paperclip / WUPHF / ROMA

These three tools are central to Bunko's architecture but their open-source status is unknown. If they are not open-source or publicly available, the Bunko "shared core + per-track adapters" implementation would need to substitute equivalents:
- Paperclip → project management tool (Linear, GitHub Projects, or custom)
- WUPHF → git-backed wiki (Obsidian, Notion, or plain markdown repo)
- ROMA → custom orchestration (likely Python, using Starter's Convergence Controller as a model)

**This is the largest uncertainty for Bunko-track implementation. Requires user input in Phase 3 Axis B review.**

---

## 10. Synthesis Alignment Summary

Based on the user's chosen provisional synthesis shape ("Shared core + per-track adapters"):

| Layer | Source | Key contributions |
|---|---|---|
| **Shared core** | Starter (Universal Core) | Ontology v3 (6-level structural hierarchy, Bible, Promise Ledger, AI-Tell Catalog, Convergence Controller). 7 pre-locked decisions. Profile-axis framework (5 primary × 6 auxiliary). Sensitivity Profile sacred/inviolable. Reproducibility first-class. Schema-as-contract (JSON Schema Draft 2020-12). |
| **Shared code foundation** | Manus-Agnostic | Most mature implementation (85%, 19.5K lines). ModelRouter (multi-provider Anthropic/OpenAI/xAI/Ollama). VoiceProfile (data-driven). ContextManager. 17 agents (including 9 specialist editorial). Orchestrator → job_runner refactor. Cost tracking. |
| **Genre Module architecture** | MBSE (from reviews) | Genre Module Architecture: stable core + swappable module per genre (scene-function vocabulary, ontology extensions, quality gates, self-audit rubric). Romance Module v1.0 defined. Thriller Module v0.1 scaffold. Overlay + Context Pack architecture (Dr. Smith + Memo Author). VoiceExemplarManager spec. |
| **Commercial/series track** | Bunko | Voice Profile schema (most detailed). 4-model ensemble drafter. Reception/audience feedback loop (§11). EvoSkill pattern accumulation. harbor eval. Series as primary unit. Voice Discriminator (local classifier). Drafter D (fine-tuned local model for target voice). |
| **Formal/literary track** | MBSE (Thriller scaffold) | Information-state modeling per character. Adversarial relationship modeling. Evidence lifecycle. Compressed rhythm. thriller_engine block per scene. (All from Thriller SME findings; Thriller Module v0.1 scaffold in MBSE.) |
| **Deferred to V2** | Bunko heavy stack | Paperclip/WUPHF/ROMA (if unavailable). Drafter D fine-tuning (Unsloth/Axolotl). Reception tier scraping (Manus/Apify). Sentient-Enclaves. AWS GPU. Signed releases (Sigstore/TUF/OML/MarkLLM). |
