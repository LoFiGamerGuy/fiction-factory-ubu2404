---
name: stakeholders
description: "Historical voices in the three bundles — Manus, Dr. Smith, SMEs — with their positions and the documents that record them. They informed the design; they are not gatekeepers."
metadata: 
  node_type: memory
  type: project
  originSessionId: 9f1a26c4-ac8d-4fa8-b9bc-804bd685cc7f
---

The user owns the final call. Stakeholder voices recorded here are **historical** and surface reasoning, not authority. Populated during Phase 2.2 by direct read of the closure / plan-of-record / SME persona docs.

## Stakeholder positions

| Stakeholder | Bundle | Position (one line) | Document | Status |
|---|---|---|---|---|
| Manus (Craft Review #1 — Romance analysis) | MBSE | "The system is romance-shaped but incompletely so. Validates ontology against romance craft; identifies specific missing schema fields." | `Craft Review #1 — Manus Analysis.md`, `Craft Reviews Acceptance — Plan of Record.md` | historical — findings accepted in full for Romance Module v1.0 |
| Claude (Craft Review #2) | MBSE | Declined the reviewer role. Preserved as "successful failure mode." Carries no acceptance weight. | `Craft_Review_Bundle_2026-05-12/_nested/Craft_Review_2_Raw_Response_Claude_Declined_Role.md` | historical — not accepted |
| Dr. Smith (independent technical review) | MBSE | "Copy-on-init agent segregation is the wrong architecture. Use overlay-aware SpecLoader. Full-auto operation is the right design target. Voice exemplar discipline must prevent collapse and auto-add of generated content." | `Fiction_Factory_Review_Dr_Smith.md`, `Closure Note — Dr. Smith.md` | historical — overlay architecture and VoiceExemplarManager spec accepted as binding |
| Formal Review Memo Author (engineering review) | MBSE | "14 blocking bugs, 13 major findings. Context Pack Generation (per-job materialized context packs with provenance.json) is the implementation mechanism for agent views. Start with lighter implementations. [Lighter-start advice explicitly rejected by project in favor of heavier-from-the-start.]" | `fiction_factory_formal_review_memo_2026-05-12.md` (in nested Memo_Author zip), `Closure Note — Formal Review Memo Author.md` | historical — bug findings and Context Pack concept accepted; lighter-start sequencing advice rejected |
| Romance SME (Vantage — composite "Margaux") | MBSE | "Specific romance schema gaps: HEA/HFN missing, heat_level conflates content/tonal, sex_scene_spec and consent_arc not modeled, tropes should drive required-scene slots. Four no-fly additions (triple restatement, abstract emotion-labeling, 'It is X a Y' construction, prose explaining itself)." | `Craft_Review_Response_Romance_Vantage_2026-05-12.md`, `Craft_SME_Persona_Romance.md` | historical — all findings accepted; no-fly additions binding |
| Thriller / Literary SME (Vantage — composite "Sigourney") | MBSE | "System is romance-derived, not genre-agnostic. Thriller requires: information-state modeling per character, adversarial relationship modeling, evidence lifecycle, reversed scene-purpose vocabulary, compressed rhythm signature. These are genre-architecture differences, not minor fixes." | `Craft_Review_Response_Thriller_Vantage_2026-05-12.md`, `Craft_SME_Persona_Literary_or_Thriller.md` | historical — findings accepted; Thriller Module v0.1 scaffold created; full validation deferred |

## Key engineering decisions from reviews

These are the architectural conclusions reached through the review process. They bear on synthesis.

### Adopted — Overlay + Context Pack architecture
- **Dr. Smith's contribution**: `SpecLoader` returns canonical spec with optional per-agent JSON-Patch overlays at read time. No copy-on-init. `--init-series` step deleted entirely.
- **Memo Author's contribution**: Per-job `ContextPackBuilder` materializes a small, self-contained, hash-stamped JSON context pack for one agent for one scene. Contains provenance: source files, source hashes, view schema version, generated_at.
- Together: two layers of one architecture replacing `Agent_Segregation_Design.md`.
- Documented in: `Agent Views and Context Packs — Architecture Reference.md`

### Adopted — Genre Module Architecture
- **Core insight from craft reviews**: The system is romance-derived, not genre-agnostic. Genre-agnosticism requires genre modules — each must supply its own scene-function vocabulary, ontology extensions, quality gates, and validation pass.
- Stable core pipeline + swappable Genre Module.
- Romance Module v1.0: validated.
- Thriller Module v0.1: scaffolded only; validation deferred.
- Literary fiction, sci-fi, fantasy, mystery: deferred entirely.
- Documented in: `Craft Reviews Acceptance — Plan of Record.md` §2.1

### Adopted — Architectural posture: heavier-weight from the start
- **Explicit rejection of Memo Author's lighter-start recommendation.**
- Reasoning: under full-auto operation every silent-failure path becomes a manuscript-corruption path. Robustness is the minimum viable surface.
- Applies to: dependency declaration, path management, agent constructors, job passing, spec validation, self-audit output, quality gate failure modes, continuity state writes.

### Adopted — Permanent line-editor-in-the-loop release gate
- No book marked release-ready by system alone. Human line-editor review is a permanent gate, not a Phase 1 expedient.

### Adopted — VoiceExemplarManager discipline
- 2 exemplars per call, 200–400 word window, 3-tier source hierarchy, uniform random rotation, beat-type stratification hook.
- Hard invariant: no generated content auto-added to exemplar pool.
- Collapse detector required.
- Voice exemplar pool must be screened against Register 2 (AI-tell register) before use.

### Parked — Speculative directions S1–S12 (except S4)
- Both reviewers recommended parking all speculative directions until system stabilizes.
- **Exception: S4 (full-auto operation)**. User confirmed this is near-term roadmap. Architecture posture engineered toward this target from day one.

## Conflicts and tensions

| Tension | Parties | Resolution |
|---|---|---|
| Lighter-start vs heavier-from-the-start | Memo Author (recommended lighter) vs project posture (adopted heavier) | Project explicitly rejected lighter-start; heavier posture adopted. Documented in `Project_Realism_Notes.md` §5. |
| Genre-agnosticism claim | Original MBSE design (claimed genre-agnostic) vs all craft reviewers (found romance-derived) | Resolved: "emotionally driven commercial fiction, validated against romance. Genre-extensible but requires per-genre validated module." Old genre-agnostic claim superseded. |
| Claude as craft reviewer | Review #2 sent to Claude; Claude declined | Resolved: Claude was the wrong reviewer type. Human-voice reviewers (romance specialist, thriller specialist) provided the substantive read. |

Related: [[project-three-bundles]], [[decisions]], [[glossary]].
