---
name: project-three-bundles
description: "Overall situation — three architecture bundles under synthesis review for an autonomous AI fiction-writing pipeline, with synthesis as default disposition."
metadata: 
  node_type: memory
  type: project
  originSessionId: 9f1a26c4-ac8d-4fa8-b9bc-804bd685cc7f
---

The workspace `/home/gosne/src/workspace/Systems Architecture/` holds three planning bundles for the same broad goal — an autonomous AI fiction-novel-writing pipeline — at different levels of maturity and from different angles.

**Bundles** (sizes and characters captured at Phase 0 extraction, 2026-05-14):

- **MBSE bundle** — `Using MBSE to Deconstruct and Spec a Fiction Novel.zip`, ~30 MB. 166 top-level files (72 md, 24 py, 12 tsx, 12 mmd, 12 png, 9 nested zips, 8 txt, 8 json, 3 skill, 2 ts) + 604 files across 9 nested zips. Has Phase 0A/4B milestones, Python source (`orchestrator.py`, `generator.py`, `base_agent.py`, `writer_agent.py`, `spec_loader.py`, `llm_client.py`), TSX UI (ActsView/BooksView/ChaptersView etc.), and SUPERSEDED markers.
- **Starter bundle** — `autonomous-book-pipeline-starter.zip`, ~75 KB, 18 files. CLAUDE.md, IMPLEMENTATION_PLAN.md, ontology v3, profile-axis framework, schemas, runbooks, task-001/002/003 backlog, v5 Mermaid diagram, HTML "aesthetic" architecture overview.
- **Bunko bundle** — `bunko_files.zip`, ~28 KB, 3 files. BUNKO-ARCH v0.1 + v0.2, voice-profile schema YAML. Names a large external tooling stack (Paperclip, WUPHF, ROMA, LiteLLM, vLLM, Unsloth, Axolotl, Together AI, Manus, Apify, Composio, Sigstore, MarkLLM, OML-1.0-Fingerprinting, etc.).

**Authorship:** all three are the user's own work — fully editable, no obligation to preserve any author's stated authority.

**Synthesis disposition:** synthesize by default; pick-best is an escape hatch if review reveals one bundle is materially superior on every axis. Specific shape (sequential collapse / shared-core+adapters / unified) decided at §2.4 of the plan.

**Plan of record:** `/home/gosne/.claude/plans/in-this-folder-you-deep-toast.md` — baseline as of 2026-05-14, governed by the change-control section in that file.

**Critical paths to read directly (no agent) when the time comes:**
- `.workspace/bundles/mbse/Reviewer Response and Revised Plan of Record.md`
- `.workspace/bundles/mbse/Craft Reviews Acceptance — Plan of Record.md`
- `.workspace/bundles/mbse/Closure Note — Formal Review Memo Author.md`
- `.workspace/bundles/mbse/Closure Note — Dr. Smith.md`
- `.workspace/bundles/mbse/orchestrator.py`, `base_agent.py`, `writer_agent.py`, `spec_loader.py`, `llm_client.py`
- `.workspace/bundles/starter/autonomous-book-pipeline-starter/CLAUDE.md`, `IMPLEMENTATION_PLAN.md`, `docs/core-ontology-v3.md`
- `.workspace/bundles/bunko/BUNKO-ARCH-001-v0.2.md`, `BUNKO-VOICE-PROFILE-SCHEMA-v0.1.yaml`

Related: [[glossary]], [[stakeholders]], [[decisions]].
