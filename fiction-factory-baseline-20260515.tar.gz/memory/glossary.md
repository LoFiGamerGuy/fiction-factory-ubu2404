---
name: glossary
description: "Reconciled terminology across the three bundles. Populated during Phase 2.1 triage; each row cites the bundle's own definition."
metadata: 
  node_type: memory
  type: reference
  originSessionId: 9f1a26c4-ac8d-4fa8-b9bc-804bd685cc7f
---

Per the plan's "Glossary collision resolution rule":
1. Pick the term that is the most domain-specific and least likely to collide elsewhere.
2. If tied, prefer the term used by the most-recent bundle in `.workspace/TIMELINE.md`.
3. If still tied, surface as a user-decision point at §2.4.
4. Record chosen canonical term and rejected synonyms here.

## Reconciled terminology

| Canonical term | MBSE term | Starter term | Bunko term | Definition | Source citation |
|---|---|---|---|---|---|
| **pipeline agent** | agent (WriterAgent, EditorAgent, etc.) | drafter / critic / guardian / controller / component | agent (role in tier structure) | A specialized LLM-powered component occupying a defined role in the production pipeline; receives typed input, produces typed output | MBSE: 00_MASTER_BRIEFING.md; Starter: core-ontology-v3.md §8; Bunko: v0.2 §3 |
| **pipeline** | pipeline (7-step: SpecValidator→Writer→Editor→Quality→Continuity/Inject→Verifier→Publisher) | generation pipeline / spec intake pipeline / voice extraction pipeline | pipeline (full recursive production sequence: series→book→act→chapter→scene→beat) | The ordered sequence of components transforming a book specification into publishable output | MBSE: orchestrator.py; Starter: IMPLEMENTATION_PLAN.md; Bunko: v0.2 §12 |
| **scene** | scene (Unspecced→Specced→Dirty Draft→Needs Review→Approved→Final lifecycle) | scene (goal + conflict + outcome + state delta + beats; has POV, location, time) | scene (narrative unit; Atomizer can further decompose it) | A narrative unit containing beats, with POV character, goal, conflict, outcome, and lifecycle states | MBSE: MBSE System Specification.md §2; Starter: core-ontology-v3.md; Bunko: v0.2 §2 |
| **beat** | beat (beat_type: confrontation/revelation/intimacy; smallest narrative unit in scene) | beat (atomic unit: function + intensity + POV + location + time + expected_reader_response) | beat (atomic unit; Outliner produces beat sheet; Atomizer may decompose further) | The smallest narrative unit — a single moment of action, decision, or revelation; multiple beats compose a scene | MBSE: scene_spec.json; Starter: core-ontology-v3.md; Bunko: v0.2 §3 |
| **voice profile** | voice profile (author prose signature: rhythm, vocabulary, no-fly list, defamiliarization, stylometrics) | Author Profile / voice profile (quantified authorial signature across nine axis categories; measured on output only — no prose retained) | voice profile (codified as measurable dimensions: sentence metrics, lexical, syntactic, dialogue, sensory, pacing, metaphor, subtext, cadence, forbidden constructions; per-paragraph enforcement) | Codified representation of an author's prose signature as measurable, enforceable dimensions | MBSE: quantifiable_metrics.md; Starter: core-ontology-v3.md §11; Bunko: v0.2 §5.1 + companion schema |
| **ontology** | ontology (hierarchical decomposition: Series→Book→Act→Sequence→Chapter→Scene→Beat→Paragraph→Sentence→Word, with style/rhythm/grammar as interfaces) | ontology (formal definitions of all entities with properties, operations, validation; Universal Core + Specialization Layers) | (not named explicitly; tier structure implies it) | Formal model of all entities, their structural hierarchy, properties, relationships, and invariants | MBSE: MBSE_Fiction_Decomposition.md; Starter: core-ontology-v3.md §1; Bunko: v0.2 §2 |
| **profile** | profile (voice profile; quality profile; agent overlay) | profile (authored YAML for one axis: Author / Genre / Audience / Goal / Sensitivity) | profile (voice profile OR reader profile from reception tier) | An authored configuration file defining values for one axis of variation; composed into a project spec | MBSE: Agent Views and Context Packs.md; Starter: core-ontology-v3.md §9–13; Bunko: v0.2 §5.1, §11.4 |
| **book spec / project spec** | spec (JSON document: series_spec.json, book_spec.json, character_cards.json, scene_spec.json; must be 100% complete before pipeline runs) | Project Spec (composed result of profile resolution; any-fidelity input → expanded and validated by Spec Intake Pipeline) | (not used as pipeline concept; "spec" = architecture document) | The runtime document that fully defines a book/scene for pipeline execution; produced by spec intake, consumed by generation | MBSE: Fiction Factory MBSE System Specification.md §5; Starter: core-ontology-v3.md §17 |
| **series** | series (Series spec → Book → Act → Sequence → Chapter → Scene → Beat → …; top of hierarchy) | series (deployment context; "Series Position" is auxiliary axis) | series (primary unit of production; one Bunko instance = one series; own voice profile + Drafter D LoRA) | A collection of books sharing characters, world, and narrative arc; the primary production unit | MBSE: MBSE_Fiction_Decomposition.md; Starter: PROJECT_STRUCTURE.md; Bunko: v0.2 §0 |
| **continuity model / bible** | continuity tracker (markdown state file); series arc tracker (cross-book) | Bible (Character, Location, Object, Concept, Faction, Timeline; operations: propose_delta, validate_delta, commit_delta, query) | WUPHF wiki (versioned git; series bible + continuity facts) | Canonical record of world state; checked before each scene commit to prevent contradictions | MBSE: series_arc_tracker.md; Starter: core-ontology-v3.md §4; Bunko: v0.2 §2 |
| **promise ledger** | (not present; RTM gap: "no series arc tracking" maps to this) | Promise Ledger (append-only: promise type + opened_at + must_resolve_by + resolution_state; no chapter ships with overdue promises) | (not present by name; EvoSkill tracks accumulated patterns) | Append-only record of narrative commitments (foreshadowing, setups) with mandatory resolution deadlines | Starter: core-ontology-v3.md §5 (MBSE gap; Bunko: absent) |
| **convergence / routing** | Quality Gate (routing: pass→Continuity, fail→Inject loop; max 3 iterations) | Convergence Controller (4 actions: GO / REVISE / RE-PLAN / FORCE-RESOLVE; never halts; Sensitivity violations → RE-PLAN only, cannot FORCE-RESOLVE) | Editorial Critic + Beta Reader Council → (implied routing; no named Convergence Controller) | The decision mechanism that evaluates quality signals and routes to next action: pass / revise / replan / force-advance | MBSE: orchestrator.py; Starter: core-ontology-v3.md §8; Bunko: v0.2 §3 |

## Open collisions (awaiting §2.4 adjudication)

| Collision | MBSE usage | Starter usage | Bunko usage | Recommended canonical term |
|---|---|---|---|---|
| **"agent"** (dual meaning) | pipeline component (WriterAgent, EditorAgent, etc.) | *also* CLI tool (Claude Code), different from pipeline "drafter/critic/controller" | pipeline role | Two distinct concepts: **pipeline agent** (production role) vs **CLI agent** (Claude Code). Recommend: always qualify. Starter distinguishes internally but uses same word. No vote needed — just clarify in code. |
| **"ARC reader"** | LLM persona simulating ARC (Advance Reader Copy) feedback; `arc_reader_personas.md` | "arc" = narrative arc only; no ARC reader concept | "ARC" = narrative arc; no ARC reader | MBSE-specific concept. Recommend: **ARC reader persona** for the MBSE concept; **narrative arc** for structural arc. Not a collision — different referents. |
| **"spec"** (three meanings) | JSON runtime document (series/book/character/scene_spec.json) | composed profile-resolution result (Project Spec) | architecture specification document | Recommend: **book spec** / **project spec** for runtime use; **architecture doc** for Bunko usage. MBSE and Starter agree conceptually (spec = pipeline input); just differ in format. |

Related: [[project-three-bundles]], [[decisions]].
