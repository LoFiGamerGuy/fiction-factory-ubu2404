# Memory Index — Systems Architecture / Fiction-Factory Bundle Review

- [Three-bundle situation](project_three_bundles.md) — overall context, bundle inventories, synthesis disposition, plan-of-record link.
- [Glossary](glossary.md) — reconciled terminology across the three bundles (populated during Phase 2.1 triage).
- [Stakeholders](stakeholders.md) — Manus, Dr. Smith, SMEs and their historical positions (populated during Phase 2.2).
- [Decisions](decisions.md) — append-only decision ledger; tracks approved BCRs and housekeeping notes.
